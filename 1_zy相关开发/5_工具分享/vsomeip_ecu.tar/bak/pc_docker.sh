#!/usr/bin/env bash
set -e

NAME="vsomeip_jtest"
IMAGE="vsomeip_env:latest"

WORKDIR_HOST="/home/jzm/workspace/vsomeip"
WORKDIR_CONT="/home/source"

usage() {
  echo "Usage: $0 [clean|recreate]"
  echo "  clean    : remove container $NAME (if exists)"
  echo "  recreate : remove container $NAME and create a new one"
}

clean() {
  if docker ps -a --format '{{.Names}}' | grep -qx "$NAME"; then
    echo "[clean] removing container: $NAME"
    docker rm -f "$NAME" >/dev/null
  else
    echo "[clean] container not found: $NAME"
  fi
}

prepare_xauth() {
  # Allow local root user inside container to access host X server
  xhost +local:root >/dev/null

  # Use a stable Xauthority file instead of mounting $XAUTHORITY directly.
  # Some desktop sessions use temporary files like:
  # /run/user/1000/.mutter-Xwaylandauth.xxxxxx
  # which may disappear or change after the container is created.
  XAUTH="/tmp/.docker.xauth"

  if [ -n "${XAUTHORITY:-}" ] && [ -f "$XAUTHORITY" ]; then
    cp "$XAUTHORITY" "$XAUTH"
  else
    echo "[warn] XAUTHORITY is empty or not a file, creating empty $XAUTH"
    : > "$XAUTH"
  fi

  chmod 600 "$XAUTH"

  export XAUTH
}

case "${1:-}" in
  clean)
    clean
    exit 0
    ;;
  recreate)
    clean
    ;;
  "")
    ;;
  *)
    usage
    exit 1
    ;;
esac

prepare_xauth

# If container is already running, enter it.
if docker ps --format '{{.Names}}' | grep -qx "$NAME"; then
  exec docker exec -it "$NAME" bash
fi

# If container exists but is stopped, start it and enter it.
# Note: this reuses old mount configuration. If GUI mount path changed,
# run: ./pc_docker.sh recreate
if docker ps -a --format '{{.Names}}' | grep -qx "$NAME"; then
  echo "[start] starting existing container: $NAME"
  docker start "$NAME" >/dev/null
  exec docker exec -it "$NAME" bash
fi

# Container does not exist: create and enter.
exec docker run -it \
  --name "$NAME" \
  --device=/dev/dri \
  --cap-add=SYS_PTRACE \
  --security-opt seccomp=unconfined \
  --net=host \
  -e DISPLAY="${DISPLAY:-:0}" \
  -e QT_X11_NO_MITSHM=1 \
  -e XAUTHORITY=/root/.Xauthority \
  -v /tmp/.X11-unix:/tmp/.X11-unix:rw \
  -v "$XAUTH":/root/.Xauthority:ro \
  -v /etc/localtime:/etc/localtime:ro \
  -v "$WORKDIR_HOST":"$WORKDIR_CONT" \
  -w "$WORKDIR_CONT" \
  -e GTEST_ROOT=/usr/src/googletest \
  "$IMAGE" \
  bash
