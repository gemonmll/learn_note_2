// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#pragma once

namespace vsomeip_v3 {

class remote_subscription;

typedef std::function<void(const std::shared_ptr<remote_subscription>& _subscription)> remote_subscription_callback_t;

} // namespace vsomeip_v3
