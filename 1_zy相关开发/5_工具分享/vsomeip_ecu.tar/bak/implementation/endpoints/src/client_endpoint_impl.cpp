// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#include <chrono>
#include <iomanip>
#include <sstream>
#include <thread>
#include <limits>

#include <boost/asio/buffer.hpp>
#include <boost/asio/dispatch.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/asio/ip/udp.hpp>

#include <vsomeip/defines.hpp>

#include "logger_ext.hpp"
#include "../include/abstract_socket_factory.hpp"
#include "../include/client_endpoint_impl.hpp"
#include "../include/boardnet_endpoint_host.hpp"
#include "../include/io_control_operation.hpp"
#include "../../utility/include/utility.hpp"
#include "../../utility/include/bithelper.hpp"

#define VSOMEIP_LOG_PREFIX "cei"

namespace vsomeip_v3 {

template<typename Protocol>
client_endpoint_impl<Protocol>::client_endpoint_impl(const std::shared_ptr<boardnet_endpoint_host>& _boardnet_endpoint_host,
                                                     const std::shared_ptr<boardnet_routing_host>& _routing_host,
                                                     const endpoint_type& _local, const endpoint_type& _remote,
                                                     boost::asio::io_context& _io, const std::shared_ptr<configuration>& _configuration) :
    endpoint_impl<Protocol>(_boardnet_endpoint_host, _routing_host, _io, _configuration), remote_{_remote}, flush_timer_{_io},
    connect_timer_{_io}, connect_timeout_{VSOMEIP_DEFAULT_CONNECT_TIMEOUT}, state_{cei_state_e::CLOSED}, reconnect_counter_{0},
    connecting_timer_{_io}, connecting_timeout_{VSOMEIP_DEFAULT_CONNECTING_TIMEOUT}, train_{std::make_shared<train>()},
    dispatch_timer_{_io}, has_last_departure_{false}, queue_size_{0}, was_not_connected_{false}, is_sending_{false}, strand_(_io) {
    this->local_ = _local;
    recreate_socket();
}

template<typename Protocol>
client_endpoint_impl<Protocol>::~client_endpoint_impl() { }

template<typename Protocol>
void client_endpoint_impl<Protocol>::recreate_socket() {
    auto& io = endpoint_impl<Protocol>::io_;
    auto socket_factory = abstract_socket_factory::get();
    if constexpr (std::is_same_v<Protocol, boost::asio::ip::tcp>) {
        socket_ = socket_factory->create_tcp_socket(io);
    } else if constexpr (std::is_same_v<Protocol, boost::asio::ip::udp>) {
        socket_ = socket_factory->create_udp_socket(io);
    }
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::is_client() const {

    return true;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::is_closed() const {
    return state_ == cei_state_e::CLOSED;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::is_established() const {

    return state_ == cei_state_e::ESTABLISHED;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::is_established_or_connected() const {

    return (state_ == cei_state_e::ESTABLISHED || state_ == cei_state_e::CONNECTED);
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::set_established(bool _established) {

    if (_established) {
        if (state_ != cei_state_e::CONNECTING) {
            std::scoped_lock its_lock(socket_mutex_);
            if (socket_->is_open()) {
                state_ = cei_state_e::ESTABLISHED;
            } else {
                state_ = cei_state_e::CLOSED;
            }
        }
    } else {
        state_ = cei_state_e::CLOSED;
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::set_connected(bool _connected) {

    if (_connected) {
        std::scoped_lock its_lock(socket_mutex_);
        if (socket_->is_open()) {
            state_ = cei_state_e::CONNECTED;
        } else {
            state_ = cei_state_e::CLOSED;
        }
    } else {
        state_ = cei_state_e::CLOSED;
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::stop(bool _due_to_error) {
    {
        std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
        endpoint_impl<Protocol>::sending_blocked_ = true;
        // delete unsent messages
        queue_.clear();
        queue_size_ = 0;
    }
    {
        std::scoped_lock its_lock(connect_timer_mutex_);
        connect_timer_.cancel();
    }
    connect_timeout_ = VSOMEIP_DEFAULT_CONNECT_TIMEOUT;

    // bind to strand as stop() might be called from different thread
    boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::close_socket, this->shared_from_this(), false, _due_to_error));
}

template<typename Protocol>
std::pair<message_buffer_ptr_t, uint32_t> client_endpoint_impl<Protocol>::get_front() {

    std::pair<message_buffer_ptr_t, uint32_t> its_entry;
    if (queue_.size())
        its_entry = queue_.front();

    return its_entry;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::send_to(const std::shared_ptr<endpoint_definition> _target, const byte_t* _data, uint32_t _size) {

    (void)_target;
    (void)_data;
    (void)_size;
    VSOMEIP_ERROR << "Clients endpoints must not be used to send to explicitly specified targets";
    return false;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::send_error(const std::shared_ptr<endpoint_definition> _target, const byte_t* _data, uint32_t _size) {

    (void)_target;
    (void)_data;
    (void)_size;
    VSOMEIP_ERROR << "Clients endpoints must not be used to send errors to explicitly specified targets";
    return false;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::send(const uint8_t* _data, uint32_t _size) {

    std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
    bool must_depart(false);
    auto its_now(std::chrono::steady_clock::now());

    if (endpoint_impl<Protocol>::sending_blocked_ || !check_queue_limit(_data, _size)) {
        return false;
    }

    if (!check_message_size(_size)) {
        return segment_message(_data, _size) == endpoint_impl<Protocol>::cms_ret_e::MSG_WAS_SPLIT;
    }

    // STEP 1: Cancel dispatch timer
    cancel_dispatch_timer();

    // STEP 3: Get configured timings
    const service_t its_service = bithelper::read_uint16_be(&_data[VSOMEIP_SERVICE_POS_MIN]);
    const service_t its_method = bithelper::read_uint16_be(&_data[VSOMEIP_METHOD_POS_MIN]);

    std::chrono::nanoseconds its_debouncing(0), its_retention(0);
    get_configured_times_from_endpoint(its_service, its_method, &its_debouncing, &its_retention);

    // STEP 4: Check if the passenger enters an empty train
    const std::pair<service_t, method_t> its_identifier = std::make_pair(its_service, its_method);
    if (train_->passengers_.empty()) {
        train_->departure_ = its_now + its_retention; // latest possible
    } else {
        // STEP 4.1: Check whether the current train already contains the message
        if (train_->passengers_.end() != train_->passengers_.find(its_identifier)) {
            must_depart = true;
        } else {
            // STEP 5: Check whether the current message fits into the current train
            if (train_->buffer_->size() + _size > endpoint_impl<Protocol>::max_message_size_) {
                must_depart = true;
            } else {
                // STEP 6: Check debouncing time
                if (its_debouncing > train_->minimal_max_retention_time_) {
                    // train's latest departure would already undershot new
                    // passenger's debounce time
                    must_depart = true;
                } else {
                    if (its_now + its_debouncing > train_->departure_) {
                        // train departs earlier as the new passenger's debounce
                        // time allows
                        must_depart = true;
                    } else {
                        // STEP 7: Check maximum retention time
                        if (its_retention < train_->minimal_debounce_time_) {
                            // train's earliest departure would already exceed
                            // the new passenger's retention time.
                            must_depart = true;
                        } else {
                            if (its_now + its_retention < train_->departure_) {
                                train_->departure_ = its_now + its_retention;
                            }
                        }
                    }
                }
            }
        }
    }

    // STEP 8: if necessary, send current buffer and create a new one
    if (must_depart) {
        // STEP 8.1: check if debounce time would be undershot here if the train
        // departs. Schedule departure of current train and create a new one.
        schedule_train();

        train_ = std::make_shared<train>();
        train_->departure_ = its_now + its_retention;
    }

    // STEP 9: insert current message buffer
    train_->buffer_->insert(train_->buffer_->end(), _data, _data + _size);
    train_->passengers_.insert(its_identifier);
    // STEP 9.1: update the trains minimal debounce time if necessary
    if (its_debouncing < train_->minimal_debounce_time_) {
        train_->minimal_debounce_time_ = its_debouncing;
    }
    // STEP 9.2: update the trains minimal maximum retention time if necessary
    if (its_retention < train_->minimal_max_retention_time_) {
        train_->minimal_max_retention_time_ = its_retention;
    }

    // STEP 10: restart dispatch timer with next departure time
    start_dispatch_timer(its_now);

    return true;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::tp_segmentation_enabled(service_t /*_service*/, instance_t /*_instance*/, method_t /*_method*/) const {

    return false;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::send_segments(const tp::tp_split_messages_t& _segments, std::uint32_t _separation_time) {

    auto its_now(std::chrono::steady_clock::now());

    if (_segments.size() == 0) {
        return;
    }

    const service_t its_service = bithelper::read_uint16_be(&(*(_segments[0]))[VSOMEIP_SERVICE_POS_MIN]);
    const service_t its_method = bithelper::read_uint16_be(&(*(_segments[0]))[VSOMEIP_METHOD_POS_MIN]);

    std::chrono::nanoseconds its_debouncing(0), its_retention(0);
    get_configured_times_from_endpoint(its_service, its_method, &its_debouncing, &its_retention);
    // update the trains minimal debounce time if necessary
    if (its_debouncing < train_->minimal_debounce_time_) {
        train_->minimal_debounce_time_ = its_debouncing;
    }
    // update the trains minimal maximum retention time if necessary
    if (its_retention < train_->minimal_max_retention_time_) {
        train_->minimal_max_retention_time_ = its_retention;
    }

    // We only need to respect the debouncing. There is no need to wait for further
    // messages as we will send several now anyway.
    if (!train_->passengers_.empty()) {
        schedule_train();
        train_ = std::make_shared<train>();
        train_->departure_ = its_now + its_retention;
    }

    for (const auto& s : _segments) {
        queue_.emplace_back(std::make_pair(s, _separation_time));
        queue_size_ += s->size();
    }

    if (!is_sending_ && !queue_.empty()) { // no writing in progress
        // ignore retention time and send immediately as the train is full anyway
        auto its_entry = get_front();
        if (its_entry.first) {
            is_sending_ = true;
            boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::send_queued, this->shared_from_this(), its_entry));
        }
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::schedule_train() {

    if (has_last_departure_) {
        if (last_departure_ + train_->minimal_debounce_time_ > train_->departure_) {
            train_->departure_ = last_departure_ + train_->minimal_debounce_time_;
        }
    }

    dispatched_trains_[train_->departure_].push_back(train_);
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::send(const std::vector<byte_t>& _cmd_header, const byte_t* _data, uint32_t _size) {
    (void)_cmd_header;
    (void)_data;
    (void)_size;
    return false;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::flush() {

    bool has_queued(true);
    bool is_current_train(true);

    std::scoped_lock<std::recursive_mutex> its_lock(mutex_);

    std::shared_ptr<train> its_train(train_);
    if (!dispatched_trains_.empty()) {

        auto its_dispatched = dispatched_trains_.begin();
        if (its_dispatched->first <= its_train->departure_) {

            is_current_train = false;
            its_train = its_dispatched->second.front();
            its_dispatched->second.pop_front();
            if (its_dispatched->second.empty()) {

                dispatched_trains_.erase(its_dispatched);
            }
        }
    }

    if (!its_train->buffer_->empty()) {

        queue_train(its_train);

        // Reset current train if necessary
        if (is_current_train) {
            its_train->reset();
        }
    } else {
        has_queued = false;
    }

    if (!is_current_train || !dispatched_trains_.empty()) {

        auto its_now(std::chrono::steady_clock::now());
        start_dispatch_timer(its_now);
    }

    return has_queued;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::connect_cbk(boost::system::error_code const& _error) {

    if (_error == boost::asio::error::operation_aborted || endpoint_impl<Protocol>::sending_blocked_) {
        VSOMEIP_WARNING_P << "Endpoint stopped, remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                          << to_string(state_.load());
        close_socket(false, false);
        return;
    }
    std::shared_ptr<boardnet_endpoint_host> its_host = this->endpoint_host_.lock();
    if (its_host) {
        if (_error && _error != boost::asio::error::already_connected) {
            VSOMEIP_WARNING_P << "Restarting socket due to " << _error.message() << " (" << _error.value()
                              << "), remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                              << to_string(state_.load());

            close_socket(true, true);

            its_host->on_disconnect(this->shared_from_this());

            if (get_max_allowed_reconnects() == MAX_RECONNECTS_UNLIMITED || get_max_allowed_reconnects() >= ++reconnect_counter_) {
                is_sending_ = false;
                was_not_connected_ = true;
                start_connect_timer();
            } else {
                max_allowed_reconnects_reached();
            }
            // After 30 attempts of 100ms (3s) increase the timer exponential
            // Double the timeout as long as the maximum allowed is larger
            if (connect_timeout_ < VSOMEIP_MAX_CONNECT_TIMEOUT && reconnect_counter_ > 30)
                connect_timeout_ = (connect_timeout_ << 1);
        } else {
            if (_error) {
                VSOMEIP_WARNING_P << "connect_cbk attempt (" << _error.value() << "):" << _error.message()
                                  << ", remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                                  << to_string(state_.load());
            }
            {
                std::scoped_lock its_lock(connect_timer_mutex_);
                connect_timer_.cancel();
            }
            connect_timeout_ = VSOMEIP_DEFAULT_CONNECT_TIMEOUT; // TODO: use config variable
            reconnect_counter_ = 0;
            {
                std::scoped_lock its_lock(mutex_);
                if (was_not_connected_) {
                    was_not_connected_ = false;
                    auto its_entry = get_front();
                    if (its_entry.first) {
                        is_sending_ = true;
                        boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::send_queued, this->shared_from_this(), its_entry));
                        VSOMEIP_WARNING_P << "Resume sending to: " << get_remote_information() << " endpoint > " << this
                                          << " socket state > " << to_string(state_.load());
                    }
                }
            }
            if (state_ != cei_state_e::ESTABLISHED) {
                its_host->on_connect(this->shared_from_this());
            }
            receive();
        }
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::cancel_and_connect_cbk(boost::system::error_code const& _error) {
    std::size_t operations_cancelled;
    {
        /* Need this for TCP endpoints for now because we have no
         direct control about the point in time the connect has finished */
        std::scoped_lock its_lock(connecting_timer_mutex_);
        connecting_timer_state_ = connecting_timer_state_e::FINISH_ERROR;
        operations_cancelled = connecting_timer_.cancel();
        if (!_error) {
            connecting_timer_state_ = connecting_timer_state_e::FINISH_SUCCESS;
        }
        connecting_timer_condition_.notify_all();
    }
    if (operations_cancelled != 0) {
        if (_error) {
            VSOMEIP_WARNING_P << "Cancelled " << operations_cancelled << " operations err: (" << _error.value()
                              << "): msg: " << _error.message() << ", remote: " << get_remote_information() << ", endpoint > " << this
                              << " socket state > " << to_string(state_.load());
        }
        connect_cbk(_error);
    } else {
        VSOMEIP_INFO_P << "Operations_cancelled is 0 endpoint > " << this << " socket state > " << to_string(state_.load());
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::wait_connect_cbk(boost::system::error_code const& _error) {

    if (!_error && !client_endpoint_impl<Protocol>::sending_blocked_) {
        auto self = this->shared_from_this();
        boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::connect, this->shared_from_this()));
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::wait_connecting_cbk(boost::system::error_code const& _error) {

    if (!_error && !client_endpoint_impl<Protocol>::sending_blocked_) {
        connect_cbk(boost::asio::error::timed_out);
    } else if (_error.value() != ECANCELED) {
        VSOMEIP_WARNING_P << "Not calling connect_cbk: sending_blocked_: " << client_endpoint_impl<Protocol>::sending_blocked_ << " ("
                          << _error.value() << "):" << _error.message() << ", remote: " << get_remote_information() << ", endpoint > "
                          << this << " socket state > " << to_string(state_.load());
    } else {
        VSOMEIP_INFO_P << "Remote > " << get_remote_information() << ", endpoint > " << this << " socket state > "
                       << to_string(state_.load());
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::send_cbk(boost::system::error_code const& _error, std::size_t _bytes,
                                              const message_buffer_ptr_t& _sent_msg) {

    (void)_bytes;

    if (!_error) {
        std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
        if (queue_.size() > 0) {
            queue_size_ -= queue_.front().first->size();
            queue_.pop_front();

            update_last_departure();

            if (queue_.empty())
                is_sending_ = false;
            else {
                auto its_entry = get_front();
                if (its_entry.first) {
                    send_queued(its_entry);
                } else {
                    VSOMEIP_INFO_P << "Not calling send_queued | endpoint > " << this << " socket state > " << to_string(state_.load());
                    is_sending_ = false;
                }
            }
        }
        return;
    } else if (_error == boost::asio::error::broken_pipe) {

        VSOMEIP_WARNING_P << "Received error: " << _error.message() << " (" << _error.value() << ") " << get_remote_information()
                          << " endpoint > " << this << " socket state > " << to_string(state_.load());

        if (!ensure_connected(_error)) {
            return;
        }

        bool stopping(false);
        {
            std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
            stopping = endpoint_impl<Protocol>::sending_blocked_;
            if (stopping) {
                queue_.clear();
                queue_size_ = 0;
            } else {
                service_t its_service(0);
                method_t its_method(0);
                client_t its_client(0);
                session_t its_session(0);
                if (_sent_msg && _sent_msg->size() > VSOMEIP_SESSION_POS_MAX) {
                    its_service = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_SERVICE_POS_MIN]);
                    its_method = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_METHOD_POS_MIN]);
                    its_client = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_CLIENT_POS_MIN]);
                    its_session = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_SESSION_POS_MIN]);
                }
                VSOMEIP_WARNING_P << "Received error: " << _error.message() << " (" << _error.value() << ") " << get_remote_information()
                                  << " " << queue_.size() << " " << queue_size_ << " (" << hex4(its_client) << "): [" << hex4(its_service)
                                  << "." << hex4(its_method) << "." << hex4(its_session) << "] endpoint > " << this << " socket state > "
                                  << to_string(state_.load());
            }
        }
        if (!stopping) {
            print_status();
        }
        was_not_connected_ = true;
        close_socket(true, true);
        boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::connect, this->shared_from_this()));
    } else if (_error == boost::asio::error::not_connected || _error == boost::asio::error::bad_descriptor
               || _error == boost::asio::error::no_permission || _error == boost::asio::error::not_socket) {

        VSOMEIP_WARNING_P << "Received error: " << _error.message() << " (" << _error.value() << ") " << get_remote_information()
                          << " endpoint > " << this << " socket state > " << to_string(state_.load());

        if (!ensure_connected(_error)) {
            return;
        }

        if (_error == boost::asio::error::no_permission) {
            std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
            queue_.clear();
            queue_size_ = 0;
        }
        was_not_connected_ = true;
        close_socket(true, true);
        boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::connect, this->shared_from_this()));
    } else if (_error == boost::asio::error::operation_aborted) {

        VSOMEIP_WARNING_P << "Received error: " << _error.message() << " (" << _error.value() << "), remote: " << get_remote_information()
                          << ", endpoint > " << this << " socket state > " << to_string(state_.load());

        if (!ensure_connected(_error)) {
            return;
        }
        // endpoint was stopped
        endpoint_impl<Protocol>::sending_blocked_ = true;
        close_socket(false, false);
    } else {
        service_t its_service(0);
        method_t its_method(0);
        client_t its_client(0);
        session_t its_session(0);
        if (_sent_msg && _sent_msg->size() > VSOMEIP_SESSION_POS_MAX) {
            its_service = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_SERVICE_POS_MIN]);
            its_method = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_METHOD_POS_MIN]);
            its_client = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_CLIENT_POS_MIN]);
            its_session = bithelper::read_uint16_be(&(*_sent_msg)[VSOMEIP_SESSION_POS_MIN]);
        }
        VSOMEIP_WARNING_P << "Received error: " << _error.message() << " (" << _error.value() << "), remote: " << get_remote_information()
                          << " " << queue_.size() << " " << queue_size_ << " (" << hex4(its_client) << "): [" << hex4(its_service) << "."
                          << hex4(its_method) << "." << hex4(its_session) << "] endpoint > " << this << " socket state > "
                          << to_string(state_.load());
        print_status();
    }

    std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
    was_not_connected_ = true;
    is_sending_ = false;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::flush_cbk(boost::system::error_code const& _error) {

    if (!_error) {
        (void)flush();
    }
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::close_socket(bool _recreate_socket, bool _due_to_error) {

#if defined(__linux__) || defined(__QNX__)
    boost::system::error_code its_error;
    if constexpr (std::is_same_v<Protocol, boost::asio::ip::tcp>) {
        io_control_operation<std::size_t> send_buffer_size_cmd(TIOCOUTQ);

        std::uint32_t retry_count(0);
        while (true) {
            {
                std::scoped_lock its_lock(socket_mutex_); // Do not block this mutex while waiting, to let other operations finish
                if (socket_ && socket_->is_open()) {
                    socket_->io_control(send_buffer_size_cmd, its_error);
                }
            }

            if (its_error) {
                VSOMEIP_WARNING_P << "Fail to read send_buffer_size (" << its_error.value() << "): " << its_error.message()
                                  << ", remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                                  << to_string(state_.load());
                break;
            }

            const auto send_buffer_size = send_buffer_size_cmd.get();
            if (send_buffer_size > 0) {
                // close_socket was called on error, do not wait to send remaining data
                if (_due_to_error) {
                    VSOMEIP_WARNING_P << "Error on socket, not waiting to send remaining data, remote: " << get_remote_information()
                                      << ", endpoint > " << this << " socket state > " << to_string(state_.load());
                    break;
                } else {
                    VSOMEIP_WARNING_P << "Waiting[" << retry_count << "] on close to send " << send_buffer_size
                                      << " bytes , remote: " << get_remote_information() << ", endpoint > " << this;
                    std::this_thread::sleep_for(std::chrono::milliseconds(VSOMEIP_TCP_CLOSE_SEND_BUFFER_CHECK_PERIOD));
                }
            } else {
                break;
            }
            ++retry_count;
            if (retry_count > VSOMEIP_TCP_CLOSE_SEND_BUFFER_RETRIES) {
                VSOMEIP_WARNING_P << "Max retries reached to send! will drop " << send_buffer_size
                                  << " bytes on close, remote: " << get_remote_information() << ", endpoint > " << this;
                break;
            }
        }
    }
#endif

    std::scoped_lock its_lock(socket_mutex_);
    close_socket_unlocked(_recreate_socket);
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::close_socket_unlocked(bool _recreate_socket) {

    if (socket_->is_open()) {
#if defined(__linux__) || defined(__QNX__)
        if (!socket_->can_read_fd_flags()) {
            VSOMEIP_ERROR_P << "Socket/handle closed already, errno " << errno << ", " << get_remote_information() << " endpoint > "
                            << this;
        }
#endif

        // NOTE: no `shutdown`, as it will cause a TCP FIN if the underlying protocol is TCP, whereas we want
        // only TCP RSTs (and therefore configure SO_LINGER accordingly)
        boost::system::error_code its_error;
        socket_->close(its_error);
        if (its_error) {
            VSOMEIP_WARNING_P << "Socket close error, (" << its_error.value() << "): " << its_error.message()
                              << ", remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                              << to_string(state_.load());
        }
    } else {
        VSOMEIP_WARNING_P << "Socket was not open, remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                          << to_string(state_.load());
    }

    state_ = cei_state_e::CLOSED;

    if (_recreate_socket) {
        recreate_socket();
        VSOMEIP_WARNING_P << "Socket has been reset, remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                          << to_string(state_.load());
    } else {
        VSOMEIP_INFO_P << "Not recreating socket, remote: " << get_remote_information() << ", endpoint > " << this << " socket state > "
                       << to_string(state_.load());
    }
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::get_remote_address(boost::asio::ip::address& _address) const {

    (void)_address;
    return false;
}

template<typename Protocol>
std::uint16_t client_endpoint_impl<Protocol>::get_remote_port() const {

    return 0;
}

template<typename Protocol>
std::uint16_t client_endpoint_impl<Protocol>::get_local_port() const {

    return 0;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::start_connect_timer() {

    std::scoped_lock its_lock(connect_timer_mutex_);
    connect_timer_.expires_after(std::chrono::milliseconds(connect_timeout_));
    connect_timer_.async_wait(
            std::bind(&client_endpoint_impl<Protocol>::wait_connect_cbk, this->shared_from_this(), std::placeholders::_1));
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::start_connecting_timer() {

    std::scoped_lock its_lock(connecting_timer_mutex_);
    connecting_timer_.expires_after(std::chrono::milliseconds(connecting_timeout_));
    connecting_timer_.async_wait(
            std::bind(&client_endpoint_impl<Protocol>::wait_connecting_cbk, this->shared_from_this(), std::placeholders::_1));
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::check_message_size(std::uint32_t _size) const {
    return !(endpoint_impl<Protocol>::max_message_size_ != MESSAGE_SIZE_UNLIMITED && _size > endpoint_impl<Protocol>::max_message_size_);
}

template<typename Protocol>
typename endpoint_impl<Protocol>::cms_ret_e client_endpoint_impl<Protocol>::segment_message(const std::uint8_t* const _data,
                                                                                            std::uint32_t _size) {

    if (endpoint_impl<Protocol>::is_supporting_someip_tp_ && _data != nullptr) {
        const service_t its_service = bithelper::read_uint16_be(&_data[VSOMEIP_SERVICE_POS_MIN]);
        const method_t its_method = bithelper::read_uint16_be(&_data[VSOMEIP_METHOD_POS_MIN]);
        instance_t its_instance = this->get_instance(its_service);

        if (its_instance != ANY_INSTANCE) {
            if (tp_segmentation_enabled(its_service, its_instance, its_method)) {
                std::uint16_t its_max_segment_length;
                std::uint32_t its_separation_time;
                this->configuration_->get_tp_configuration(its_service, its_instance, its_method, true, its_max_segment_length,
                                                           its_separation_time);
                send_segments(tp::tp::tp_split_message(_data, _size, its_max_segment_length), its_separation_time);
                return endpoint_impl<Protocol>::cms_ret_e::MSG_WAS_SPLIT;
            }
        }
    }
    VSOMEIP_ERROR_P << "Dropping to big message (" << _size
                    << " Bytes). Maximum allowed message size is: " << endpoint_impl<Protocol>::max_message_size_ << " Bytes.";
    return endpoint_impl<Protocol>::cms_ret_e::MSG_TOO_BIG;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::check_queue_limit(const uint8_t* _data, std::uint32_t _size) const {

    if (endpoint_impl<Protocol>::queue_limit_ != QUEUE_SIZE_UNLIMITED
        && (queue_size_ + _size > endpoint_impl<Protocol>::queue_limit_ || queue_size_ + _size < _size)) { // overflow protection
        service_t its_service(0);
        method_t its_method(0);
        client_t its_client(0);
        session_t its_session(0);
        if (_size >= VSOMEIP_SESSION_POS_MAX) {
            // this will yield wrong IDs for local communication as the commands
            // are prepended to the actual payload
            // it will print:
            // (lowbyte service ID + highbyte methoid)
            // [(Command + lowerbyte sender's client ID).
            //  highbyte sender's client ID + lowbyte command size.
            //  lowbyte methodid + highbyte vsomeip length]
            its_service = bithelper::read_uint16_be(&_data[VSOMEIP_SERVICE_POS_MIN]);
            its_method = bithelper::read_uint16_be(&_data[VSOMEIP_METHOD_POS_MIN]);
            its_client = bithelper::read_uint16_be(&_data[VSOMEIP_CLIENT_POS_MIN]);
            its_session = bithelper::read_uint16_be(&_data[VSOMEIP_SESSION_POS_MIN]);
        }
        VSOMEIP_ERROR_P << "Queue size limit (" << endpoint_impl<Protocol>::queue_limit_ << ") reached. Dropping message ("
                        << hex4(its_client) << "): [" << hex4(its_service) << "." << hex4(its_method) << "." << hex4(its_session) << "] "
                        << "queue_size: " << queue_size_ << " data size: " << _size;
        return false;
    }
    return true;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::queue_train(const std::shared_ptr<train>& _train) {

    queue_size_ += _train->buffer_->size();
    queue_.emplace_back(_train->buffer_, 0);

    if (!is_sending_ && !queue_.empty()) { // no writing in progress
        auto its_entry = get_front();
        if (its_entry.first) {
            is_sending_ = true;
            boost::asio::dispatch(strand_, std::bind(&client_endpoint_impl::send_queued, this->shared_from_this(), its_entry));
        }
    }
}

template<typename Protocol>
size_t client_endpoint_impl<Protocol>::get_queue_size() const {

    std::scoped_lock<std::recursive_mutex> its_lock(mutex_);
    return queue_size_;
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::start_dispatch_timer(const std::chrono::steady_clock::time_point& _now) {

    // Choose the next train
    std::shared_ptr<train> its_train(train_);
    if (!dispatched_trains_.empty()) {

        auto its_dispatched = dispatched_trains_.begin();
        if (its_dispatched->first < its_train->departure_) {

            its_train = its_dispatched->second.front();
        }
    }

    std::chrono::nanoseconds its_offset;
    if (its_train->departure_ > _now) {

        its_offset = std::chrono::duration_cast<std::chrono::nanoseconds>(its_train->departure_ - _now);
    } else { // already departure time

        its_offset = std::chrono::nanoseconds::zero();
    }

#if defined(__linux__) || defined(__QNX__)
    dispatch_timer_.expires_after(its_offset);
#else
    dispatch_timer_.expires_after(std::chrono::duration_cast<std::chrono::steady_clock::duration>(its_offset));
#endif
    dispatch_timer_.async_wait(std::bind(&client_endpoint_impl<Protocol>::flush_cbk, this->shared_from_this(), std::placeholders::_1));
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::cancel_dispatch_timer() {
    dispatch_timer_.cancel();
}

template<typename Protocol>
void client_endpoint_impl<Protocol>::update_last_departure() {

    last_departure_ = std::chrono::steady_clock::now();
    has_last_departure_ = true;
}

template<typename Protocol>
bool client_endpoint_impl<Protocol>::ensure_connected(const boost::system::error_code& _error) {
    bool result = true;
    if (!is_established_or_connected()) {
        VSOMEIP_WARNING_P << "Socket not yet connected (" << _error.message() << ") remote: " << get_remote_information() << ", endpoint > "
                          << this << " socket state > " << to_string(state_.load());
        was_not_connected_ = true;
        is_sending_ = false;
        result = false;
    }
    return result;
}

template<typename Protocol>
const char* client_endpoint_impl<Protocol>::to_string(cei_state_e state) {
    switch (state) {
    case cei_state_e::CLOSED:
        return "CLOSED";
    case cei_state_e::CONNECTING:
        return "CONNECTING";
    case cei_state_e::CONNECTED:
        return "CONNECTED";
    case cei_state_e::ESTABLISHED:
        return "ESTABLISHED";
    default:
        return "UNKNOWN";
    }
}

template class client_endpoint_impl<boost::asio::ip::tcp>;
template class client_endpoint_impl<boost::asio::ip::udp>;

} // namespace vsomeip_v3
