// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#if defined(__linux__)
#include <unistd.h>
#endif

#include "../include/endpoint_manager_impl.hpp"

#include "logger_ext.hpp"
#include "../include/local_server.hpp"
#include "../include/local_acceptor_uds_impl.hpp"
#include "../include/local_acceptor_tcp_impl.hpp"
#include "../include/udp_client_endpoint_impl.hpp"
#include "../include/udp_server_endpoint_impl.hpp"
#include "../include/tcp_client_endpoint_impl.hpp"
#include "../include/tcp_server_endpoint_impl.hpp"
#include "../include/boardnet_endpoint.hpp"
#include "../include/virtual_server_endpoint_impl.hpp"
#include "../include/endpoint_definition.hpp"
#include "../../protocol/include/config_command.hpp"
#include "../../routing/include/routing_manager_base.hpp"
#include "../../routing/include/routing_manager_impl.hpp"
#include "../../routing/include/routing_host.hpp"
#include "../../utility/include/utility.hpp"
#include "../../utility/include/bithelper.hpp"

#include <forward_list>
#include <iomanip>

#ifndef WITHOUT_SYSTEMD
#include <systemd/sd-daemon.h>
#define SYSTEMD_SOCKET_ACTIVATION 1
#endif

#if defined(__linux__)
#include <sys/syscall.h>
#endif

#define VSOMEIP_LOG_PREFIX "emi"

namespace vsomeip_v3 {

endpoint_manager_impl::endpoint_manager_impl(routing_manager_impl* const _rm, boost::asio::io_context& _io,
                                             const std::shared_ptr<configuration>& _configuration) :
    io_(_io), configuration_(_configuration), router_(_rm), is_local_routing_(configuration_->is_local_routing()),
    is_uds_preferred_(configuration_->is_uds_preferred()),
    auxiliary_context_(configuration_->get_io_thread_nice_level(router_->get_name())), is_processing_options_(true) { }

endpoint_manager_impl::~endpoint_manager_impl() { }

void endpoint_manager_impl::start() {
    options_thread_ = std::thread([this]() {
#if defined(__linux__) || defined(__QNX__)
        pthread_setname_np(pthread_self(), "m_multicast");
#endif
        utility::set_thread_niceness(configuration_->get_io_thread_nice_level(router_->get_name()));

        VSOMEIP_INFO << "emi::endpoint_manager_impl: Started thread m_multicast " << std::hex << std::this_thread::get_id()
#if defined(__linux__)
                     << ", tid " << std::dec << static_cast<int>(syscall(SYS_gettid))
#endif
                ;
        process_multicast_options();
        VSOMEIP_INFO << "emi::endpoint_manager_impl: Stopped thread m_multicast " << std::hex << std::this_thread::get_id()
#if defined(__linux__)
                     << ", tid " << std::dec << static_cast<int>(syscall(SYS_gettid))
#endif
                ;
    });

    auxiliary_context_.start();
}

void endpoint_manager_impl::stop() {
    VSOMEIP_INFO_P << "called";

    clear_routing_endpoints();

    // stop boardnet endpoints
    std::vector<std::shared_ptr<boardnet_endpoint>> endpoints;

    {
        std::scoped_lock its_lock{endpoint_mutex_};

        for (const auto& [its_address, ports] : client_endpoints_) {
            for (const auto& [its_port, protocols] : ports) {
                for (const auto& [its_protocol, partitions] : protocols) {
                    for (const auto& [its_partition, its_endpoint] : partitions) {
                        endpoints.push_back(its_endpoint);
                    }
                }
            }
        }

        for (const auto& [its_port, protocols] : server_endpoints_) {
            for (const auto& [its_protocol, its_endpoint] : protocols) {
                endpoints.push_back(its_endpoint);
            }
        }
    }

    for (std::shared_ptr<boardnet_endpoint>& endpoint : endpoints) {
        endpoint->stop(false);
    }

    // clear endpoints (and related state)
    {
        std::scoped_lock its_lock{endpoint_mutex_};

        client_endpoints_.clear();
        server_endpoints_.clear();
        service_instances_.clear();
        service_instances_multicast_.clear();
        used_client_ports_.clear();
        remote_services_.clear();
    }

    endpoints.clear();

    {
        std::scoped_lock its_guard(options_mutex_);
        is_processing_options_ = false;
        options_condition_.notify_one();
    }

    try {
        options_thread_.join();
        VSOMEIP_INFO_P << "Joined thread " << "m_multicast " << std::hex << std::this_thread::get_id();
    } catch (...) {
        // Ignore exception if thread already joined
    }

    auxiliary_context_.stop();
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::find_or_create_remote_client(service_t _service, instance_t _instance,
                                                                                       bool _reliable) {
    std::shared_ptr<boardnet_endpoint> its_endpoint;
    bool start_endpoint(false);
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        its_endpoint = find_remote_client(_service, _instance, _reliable);
        if (!its_endpoint) {
            its_endpoint = create_remote_client(_service, _instance, _reliable);
            start_endpoint = true;
        }
    }
    if (start_endpoint && its_endpoint && configuration_->is_someip(_service, _instance) && !router_->is_suspended()) {
        its_endpoint->start();
    }
    return its_endpoint;
}

void endpoint_manager_impl::find_or_create_remote_client(service_t _service, instance_t _instance) {
    std::shared_ptr<boardnet_endpoint> its_reliable_endpoint;
    std::shared_ptr<boardnet_endpoint> its_unreliable_endpoint;
    bool start_reliable_endpoint(false);
    bool start_unreliable_endpoint(false);
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        its_reliable_endpoint = find_remote_client(_service, _instance, true);
        if (!its_reliable_endpoint) {
            its_reliable_endpoint = create_remote_client(_service, _instance, true);
            start_reliable_endpoint = true;
        }
        its_unreliable_endpoint = find_remote_client(_service, _instance, false);
        if (!its_unreliable_endpoint) {
            its_unreliable_endpoint = create_remote_client(_service, _instance, false);
            start_unreliable_endpoint = true;
        }
    }
    const bool is_someip{configuration_->is_someip(_service, _instance)};
    const bool is_suspended{router_->is_suspended()};

    if (start_reliable_endpoint && its_reliable_endpoint && is_someip && !is_suspended) {
        its_reliable_endpoint->start();
    }
    if (start_unreliable_endpoint && its_unreliable_endpoint && is_someip && !is_suspended) {
        its_unreliable_endpoint->start();
    }
}

void endpoint_manager_impl::is_remote_service_known(service_t _service, instance_t _instance, major_version_t _major,
                                                    minor_version_t _minor, const boost::asio::ip::address& _reliable_address,
                                                    uint16_t _reliable_port, bool* _reliable_known,
                                                    const boost::asio::ip::address& _unreliable_address, uint16_t _unreliable_port,
                                                    bool* _unreliable_known) const {

    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    auto found_service = remote_service_info_.find(_service);
    if (found_service != remote_service_info_.end()) {
        auto found_instance = found_service->second.find(_instance);
        if (found_instance != found_service->second.end()) {
            std::shared_ptr<endpoint_definition> its_definition;
            if (_reliable_port != ILLEGAL_PORT) {
                auto found_reliable = found_instance->second.find(true);
                if (found_reliable != found_instance->second.end()) {
                    its_definition = found_reliable->second;
                    if (its_definition->get_address() == _reliable_address && its_definition->get_port() == _reliable_port) {
                        *_reliable_known = true;
                    } else {
                        VSOMEIP_WARNING << "Reliable service endpoint has changed: [" << hex4(_service) << "." << hex4(_instance) << "."
                                        << static_cast<std::uint32_t>(_major) << "." << _minor
                                        << "] old: " << its_definition->get_address().to_string() << ":" << its_definition->get_port()
                                        << " new: " << _reliable_address.to_string() << ":" << _reliable_port;
                    }
                }
            }
            if (_unreliable_port != ILLEGAL_PORT) {
                auto found_unreliable = found_instance->second.find(false);
                if (found_unreliable != found_instance->second.end()) {
                    its_definition = found_unreliable->second;
                    if (its_definition->get_address() == _unreliable_address && its_definition->get_port() == _unreliable_port) {
                        *_unreliable_known = true;
                    } else {
                        VSOMEIP_WARNING << "Unreliable service endpoint has changed: [" << hex4(_service) << "." << hex4(_instance) << "."
                                        << static_cast<std::uint32_t>(_major) << "." << _minor
                                        << "] old: " << its_definition->get_address().to_string() << ":" << its_definition->get_port()
                                        << " new: " << _unreliable_address.to_string() << ":" << _unreliable_port;
                    }
                }
            }
        }
    }
}

void endpoint_manager_impl::add_remote_service_info(service_t _service, instance_t _instance,
                                                    const std::shared_ptr<endpoint_definition>& _ep_definition) {

    std::shared_ptr<serviceinfo> its_info;
    std::shared_ptr<boardnet_endpoint> its_endpoint;
    bool must_report(false);
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        remote_service_info_[_service][_instance][_ep_definition->is_reliable()] = _ep_definition;

        its_endpoint = find_remote_client(_service, _instance, _ep_definition->is_reliable());
        must_report = (its_endpoint && its_endpoint->is_established_or_connected());
        if (must_report)
            its_info = router_->find_service(_service, _instance);
    }

    if (must_report)
        router_->service_endpoint_connected(_service, _instance, its_info->get_major(), its_info->get_minor(), its_endpoint);
}

void endpoint_manager_impl::add_remote_service_info(service_t _service, instance_t _instance,
                                                    const std::shared_ptr<endpoint_definition>& _ep_definition_reliable,
                                                    const std::shared_ptr<endpoint_definition>& _ep_definition_unreliable) {

    std::shared_ptr<serviceinfo> its_info;
    std::shared_ptr<boardnet_endpoint> its_reliable, its_unreliable;
    bool must_report(false);
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        remote_service_info_[_service][_instance][false] = _ep_definition_unreliable;
        remote_service_info_[_service][_instance][true] = _ep_definition_reliable;

        its_unreliable = find_remote_client(_service, _instance, false);
        its_reliable = find_remote_client(_service, _instance, true);

        must_report = (its_unreliable && its_unreliable->is_established_or_connected() && its_reliable
                       && its_reliable->is_established_or_connected());

        if (must_report)
            its_info = router_->find_service(_service, _instance);
    }

    if (must_report) {
        router_->service_endpoint_connected(_service, _instance, its_info->get_major(), its_info->get_minor(), its_unreliable);
        router_->service_endpoint_connected(_service, _instance, its_info->get_major(), its_info->get_minor(), its_reliable);
    }
}

void endpoint_manager_impl::clear_remote_service_info(service_t _service, instance_t _instance, bool _reliable) {
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    const auto found_service = remote_service_info_.find(_service);
    if (found_service != remote_service_info_.end()) {
        const auto found_instance = found_service->second.find(_instance);
        if (found_instance != found_service->second.end()) {
            if (found_instance->second.erase(_reliable)) {
                if (!found_instance->second.size()) {
                    found_service->second.erase(found_instance);
                    if (!found_service->second.size()) {
                        remote_service_info_.erase(found_service);
                    }
                }
            }
        }
    }
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::create_server_endpoint(uint16_t _port, bool _reliable, bool _start) {
    std::shared_ptr<boardnet_endpoint> its_server_endpoint;
    boost::system::error_code its_error;
    boost::asio::ip::address its_unicast{configuration_->get_unicast_address()};
    const std::string its_unicast_str{its_unicast.to_string()};

    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    if (_start) {
        if (_reliable) {
            bool its_magic_cookies_enabled = configuration_->has_enabled_magic_cookies(its_unicast_str, _port)
                    || configuration_->has_enabled_magic_cookies("local", _port);
            auto its_tmp{std::make_shared<tcp_server_endpoint_impl>(shared_from_this(), router_->shared_from_this(), io_, configuration_,
                                                                    auxiliary_context_, its_magic_cookies_enabled)};
            if (its_tmp) {
                boost::asio::ip::tcp::endpoint its_reliable(its_unicast, _port);
                its_tmp->init(its_reliable, its_error);
                if (!its_error) {
                    its_server_endpoint = its_tmp;
                }
            }
        } else {
            auto its_tmp{std::make_shared<udp_server_endpoint_impl>(shared_from_this(), router_->shared_from_this(), io_, configuration_)};
            if (its_tmp) {
                boost::asio::ip::udp::endpoint its_unreliable(its_unicast, _port);
                its_tmp->init(its_unreliable, its_error);
                if (!its_error) {
                    its_server_endpoint = its_tmp;
                }
            }
        }
    } else {
        its_server_endpoint = std::make_shared<virtual_server_endpoint_impl>(its_unicast_str, _port, _reliable, io_);
    }

    if (its_server_endpoint) {
        server_endpoints_[_port][_reliable] = its_server_endpoint;
        if (!router_->is_suspended()) {
            its_server_endpoint->start();
        }
    } else {
        VSOMEIP_ERROR_P << "Server endpoint creation failed. Reason: " << its_error.message() << " Port: " << _port << " (" << _reliable
                        << ")";
    }

    return its_server_endpoint;
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::find_server_endpoint(uint16_t _port, bool _reliable) const {
    std::shared_ptr<boardnet_endpoint> its_endpoint;
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    auto found_port = server_endpoints_.find(_port);
    if (found_port != server_endpoints_.end()) {
        auto found_endpoint = found_port->second.find(_reliable);
        if (found_endpoint != found_port->second.end()) {
            its_endpoint = found_endpoint->second;
        }
    }
    return its_endpoint;
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::find_or_create_server_endpoint(uint16_t _port, bool _reliable, bool _start,
                                                                                         service_t _service, instance_t _instance,
                                                                                         bool& _is_found, bool _is_multicast) {
    auto its_endpoint = find_server_endpoint(_port, _reliable);
    _is_found = false;
    if (!its_endpoint) {
        its_endpoint = create_server_endpoint(_port, _reliable, _start);
    } else {
        _is_found = true;
    }
    if (its_endpoint) {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        if (!_is_multicast) {
            service_instances_[_service][its_endpoint.get()] = _instance;
        }
    }
    return its_endpoint;
}

bool endpoint_manager_impl::remove_server_endpoint(uint16_t _port, bool _reliable) {

    std::shared_ptr<boardnet_endpoint> its_endpoint;
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        auto found_port = server_endpoints_.find(_port);
        if (found_port != server_endpoints_.end()) {
            auto found_reliable = found_port->second.find(_reliable);
            if (found_reliable != found_port->second.end()) {
                its_endpoint = found_reliable->second;
            }
        }
    }

    if (!is_used_endpoint(its_endpoint.get())) {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        auto found_port = server_endpoints_.find(_port);
        if (found_port != server_endpoints_.end()) {
            if (found_port->second.erase(_reliable)) {
                if (found_port->second.empty()) {
                    server_endpoints_.erase(found_port);
                }
            }
            return true;
        }
    }

    return false;
}

void endpoint_manager_impl::clear_client_endpoints(service_t _service, instance_t _instance, bool _reliable) {

    std::shared_ptr<boardnet_endpoint> its_endpoint;

    boost::asio::ip::address its_remote_address;
    port_t its_local_port(0);
    port_t its_remote_port(0);

    bool other_services_reachable_through_endpoint(false);

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        // Clear client endpoints for remote services (generic and specific ones)
        const auto found_service = remote_services_.find(_service);
        if (found_service != remote_services_.end()) {
            const auto found_instance = found_service->second.find(_instance);
            if (found_instance != found_service->second.end()) {
                const auto found_reliability = found_instance->second.find(_reliable);
                if (found_reliability != found_instance->second.end()) {
                    service_instances_[_service].erase(found_reliability->second.get());
                    its_endpoint = found_reliability->second;
                    found_instance->second.erase(found_reliability);
                    if (found_instance->second.empty()) {
                        found_service->second.erase(found_instance);
                        if (found_service->second.empty()) {
                            remote_services_.erase(found_service);
                        }
                    }
                }
            }
        }

        // Only stop and delete the endpoint if none of the services
        // reachable through it is online anymore.
        if (its_endpoint) {
            for (const auto& service : remote_services_) {
                for (const auto& instance : service.second) {
                    const auto found_reliability = instance.second.find(_reliable);
                    if (found_reliability != instance.second.end() && found_reliability->second == its_endpoint) {
                        other_services_reachable_through_endpoint = true;
                        break;
                    }
                }
                if (other_services_reachable_through_endpoint) {
                    break;
                }
            }

            if (!other_services_reachable_through_endpoint) {
                partition_id_t its_partition;

                its_partition = configuration_->get_partition_id(_service, _instance);

                if (_reliable) {
                    std::shared_ptr<tcp_client_endpoint_impl> its_tcp_client_endpoint =
                            std::dynamic_pointer_cast<tcp_client_endpoint_impl>(its_endpoint);
                    if (its_tcp_client_endpoint) {
                        its_local_port = its_tcp_client_endpoint->get_local_port();
                        its_remote_port = its_tcp_client_endpoint->get_remote_port();
                        its_tcp_client_endpoint->get_remote_address(its_remote_address);
                    }
                } else {
                    std::shared_ptr<udp_client_endpoint_impl> its_udp_client_endpoint =
                            std::dynamic_pointer_cast<udp_client_endpoint_impl>(its_endpoint);
                    if (its_udp_client_endpoint) {
                        its_local_port = its_udp_client_endpoint->get_local_port();
                        its_remote_port = its_udp_client_endpoint->get_remote_port();
                        its_udp_client_endpoint->get_remote_address(its_remote_address);
                    }
                }
                const auto found_ip = client_endpoints_.find(its_remote_address);
                if (found_ip != client_endpoints_.end()) {
                    const auto found_port = found_ip->second.find(its_remote_port);
                    if (found_port != found_ip->second.end()) {
                        auto found_reliable = found_port->second.find(_reliable);
                        if (found_reliable != found_port->second.end()) {
                            const auto found_partition = found_reliable->second.find(its_partition);
                            if (found_partition != found_reliable->second.end()) {
                                if (found_partition->second == its_endpoint) {
                                    found_reliable->second.erase(its_partition);
                                    // delete if necessary
                                    if (0 == found_reliable->second.size()) {
                                        found_port->second.erase(_reliable);
                                        if (0 == found_port->second.size()) {
                                            found_ip->second.erase(found_port);
                                            if (0 == found_ip->second.size()) {
                                                client_endpoints_.erase(found_ip);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    if (!other_services_reachable_through_endpoint && its_endpoint) {
        release_used_client_port(its_remote_address, its_remote_port, _reliable, its_local_port);

        its_endpoint->stop(false);
    }
}

void endpoint_manager_impl::find_or_create_multicast_endpoint(service_t _service, instance_t _instance,
                                                              const boost::asio::ip::address& _sender,
                                                              const boost::asio::ip::address& _address, uint16_t _port) {
    bool is_known_multicast(false);
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        const auto found_service = multicast_info_.find(_service);
        if (found_service != multicast_info_.end()) {
            const auto found_instance = found_service->second.find(_instance);
            if (found_instance != found_service->second.end()) {
                const auto& endpoint_def = found_instance->second;
                if (endpoint_def->get_address() == _address && endpoint_def->get_port() == _port) {
                    // Multicast info and endpoint already created before
                    // This can happen when more than one client subscribe on the same instance!
                    is_known_multicast = true;
                }
            }
        }
    }
    const bool is_someip = configuration_->is_someip(_service, _instance);
    bool _is_found(false);
    // Create multicast endpoint & join multicase group
    auto its_endpoint = find_or_create_server_endpoint(_port, false, is_someip, _service, _instance, _is_found, true);
    if (!_is_found) {
        // Only save multicast info if we created a new endpoint
        // to be able to delete the new endpoint
        // as soon as the instance stops offering its service
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        std::shared_ptr<endpoint_definition> endpoint_def = endpoint_definition::get(_address, _port, false, _service, _instance);
        multicast_info_[_service][_instance] = endpoint_def;
    }

    if (its_endpoint) {
        if (!is_known_multicast) {
            std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
            service_instances_multicast_[_service][_sender] = _instance;
        }

        auto its_udp_server_endpoint = std::dynamic_pointer_cast<udp_server_endpoint_impl>(its_endpoint);
        if (its_udp_server_endpoint)
            its_udp_server_endpoint->join(_address.to_string());
    } else {
        VSOMEIP_ERROR << "Could not find/create multicast endpoint!";
    }
}

void endpoint_manager_impl::clear_multicast_endpoints(service_t _service, instance_t _instance) {
    std::shared_ptr<boardnet_endpoint> its_multicast_endpoint;
    std::string its_address;

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        // Clear multicast info and endpoint and multicast instance (remote service)
        if (multicast_info_.find(_service) != multicast_info_.end()) {
            if (multicast_info_[_service].find(_instance) != multicast_info_[_service].end()) {
                its_address = multicast_info_[_service][_instance]->get_address().to_string();
                uint16_t its_port = multicast_info_[_service][_instance]->get_port();
                auto found_port = server_endpoints_.find(its_port);
                if (found_port != server_endpoints_.end()) {
                    auto found_unreliable = found_port->second.find(false);
                    if (found_unreliable != found_port->second.end()) {
                        its_multicast_endpoint = found_unreliable->second;
                        server_endpoints_[its_port].erase(false);
                    }
                    if (found_port->second.find(true) == found_port->second.end()) {
                        server_endpoints_.erase(its_port);
                    }
                }
                multicast_info_[_service].erase(_instance);
                if (0 >= multicast_info_[_service].size()) {
                    multicast_info_.erase(_service);
                }
                (void)remove_instance_multicast(_service, _instance);
            }
        }
    }
    if (its_multicast_endpoint) {
        auto its_udp_server_endpoint = std::dynamic_pointer_cast<udp_server_endpoint_impl>(its_multicast_endpoint);
        if (its_udp_server_endpoint)
            its_udp_server_endpoint->leave(its_address);

        if (!is_used_endpoint(its_multicast_endpoint.get()))
            its_multicast_endpoint->stop(false);
    }
}

bool endpoint_manager_impl::supports_selective(service_t _service, instance_t _instance) const {
    bool supports_selective(false);
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    const auto its_service = remote_service_info_.find(_service);
    if (its_service != remote_service_info_.end()) {
        const auto its_instance = its_service->second.find(_instance);
        if (its_instance != its_service->second.end()) {
            for (const auto& its_reliable : its_instance->second) {
                supports_selective |= configuration_->supports_selective_broadcasts(its_reliable.second->get_address());
            }
        }
    }
    return supports_selective;
}

void endpoint_manager_impl::print_status() const {
    {
        std::scoped_lock const its_lock{routing_endpoint_mtx_};
        VSOMEIP_INFO << "status local routing endpoints: " << routing_endpoints_.size();
        for (const auto& [_, ep] : routing_endpoints_) {
            ep->print_status();
        }
        VSOMEIP_INFO << "status pending local routing endpoints: " << pending_routing_endpoints_.size();
    }

    // udp and tcp client endpoints
    {
        client_endpoints_t its_client_endpoints;
        server_endpoints_t its_server_endpoints;
        {
            std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
            its_client_endpoints = client_endpoints_;
            its_server_endpoints = server_endpoints_;
        }
        VSOMEIP_INFO << "status start remote client endpoints:";
        std::uint32_t num_remote_client_endpoints(0);
        // normal endpoints
        for (const auto& its_address : its_client_endpoints) {
            for (const auto& its_port : its_address.second) {
                for (const auto& its_reliability : its_port.second) {
                    for (const auto& its_partition : its_reliability.second) {
                        its_partition.second->print_status();
                        num_remote_client_endpoints++;
                    }
                }
            }
        }
        VSOMEIP_INFO << "status end remote client endpoints: " << num_remote_client_endpoints;

        VSOMEIP_INFO << "status start server endpoints:";
        std::uint32_t num_server_endpoints(1);

        // server endpoints
        for (const auto& p : its_server_endpoints) {
            for (const auto& ru : p.second) {
                ru.second->print_status();
                num_server_endpoints++;
            }
        }
        VSOMEIP_INFO << "status end server endpoints:" << num_server_endpoints;
    }
}

bool endpoint_manager_impl::create_local_uds_acceptor(std::shared_ptr<local_acceptor>& _uds_acceptor, const std::string& _endpoint_path,
                                                      bool& _is_socket_activated) {
#ifdef SYSTEMD_SOCKET_ACTIVATION
    int its_socket{0};
    // systemd socket activation feature: `sd_listen_fds` returns optional file descriptors passed by the system manager
    int32_t num_fd = sd_listen_fds(0);
#endif

#if defined(__linux__) || defined(__QNX__)
#ifdef SYSTEMD_SOCKET_ACTIVATION
    if (num_fd > 1) {
        VSOMEIP_ERROR << "Too many file descriptors received by systemd socket activation! num_fd: " << num_fd;
    } else if (num_fd == 1) {
        its_socket = SD_LISTEN_FDS_START;
        VSOMEIP_INFO << "Using native socket created by systemd socket activation! fd: " << its_socket;
        if (is_local_routing_) {
            try {
                auto its_acceptor = std::make_shared<local_acceptor_uds_impl>(
                        io_, boost::asio::local::stream_protocol::endpoint(_endpoint_path), configuration_);
                if (its_acceptor) {
                    boost::system::error_code its_error;
                    its_acceptor->init(its_error, its_socket);
                    if (its_error) {
                        VSOMEIP_ERROR << "Routing endpoint creation failed. Client ID 0x" << hex4(VSOMEIP_ROUTING_CLIENT) << ": "
                                      << its_error.message();
                        return false;
                    }
                    _uds_acceptor = its_acceptor;
                }
            } catch (const std::exception& e) {
                VSOMEIP_ERROR_P << e.what();
                return false;
            }
        }
        _is_socket_activated = true;
        return true;
    }
#endif /* SYSTEMD_SOCKET_ACTIVATION */

    if (is_local_routing_ || is_uds_preferred_) {
        try {
            VSOMEIP_INFO << "Routing root @ " << _endpoint_path;
            auto its_acceptor = std::make_shared<local_acceptor_uds_impl>(
                    io_, boost::asio::local::stream_protocol::endpoint(_endpoint_path), configuration_);
            if (its_acceptor) {
                boost::system::error_code its_error;
                its_acceptor->init(its_error, std::nullopt);
                if (its_error) {
                    VSOMEIP_ERROR << "Local routing endpoint creation failed. Client ID 0x" << hex4(VSOMEIP_ROUTING_CLIENT) << ": "
                                  << its_error.message();
                    return false;
                }
                _uds_acceptor = its_acceptor;
            }
        } catch (const std::exception& e) {
            VSOMEIP_ERROR_P << e.what();
            return false;
        }
    }
    _is_socket_activated = false;
    return true;

#else
    // On non-Linux/QNX platforms, local routing uses TCP
    return true;
#endif // __linux__ || __QNX__
}

bool endpoint_manager_impl::create_fallback_tcp_acceptor(std::shared_ptr<local_acceptor>& _tcp_acceptor) const {
    (_tcp_acceptor) = nullptr;
#if !defined(__linux__) && !defined(__QNX__)
    try {
        port_t its_port = VSOMEIP_INTERNAL_BASE_PORT;
        VSOMEIP_INFO << "Routing root @ " << its_port;
        auto const its_address = boost::asio::ip::tcp::v4();
        auto its_acceptor = std::make_shared<local_acceptor_tcp_impl>(io_, configuration_);

        if (its_acceptor) {
            boost::system::error_code its_error;
            its_acceptor->init(boost::asio::ip::tcp::endpoint(its_address, its_port), its_error);
            if (its_error) {
                VSOMEIP_ERROR << "Local routing endpoint creation failed. Client ID 0x" << hex4(VSOMEIP_ROUTING_CLIENT) << ": "
                              << its_error.message();
                return false;
            }
            _tcp_acceptor = its_acceptor;
        }
    } catch (const std::exception& e) {
        VSOMEIP_ERROR_P << e.what();
        return false;
    }
#endif // !__linux__ && !__QNX__
    return true;
}

bool endpoint_manager_impl::create_local_tcp_acceptor(std::shared_ptr<local_acceptor>& _tcp_acceptor) const {
    try {
        auto its_address = configuration_->get_routing_host_address();
        auto its_port = configuration_->get_routing_host_port();

        VSOMEIP_INFO << "Routing root @ " << its_address.to_string() << ":" << its_port;

        auto its_acceptor = std::make_shared<local_acceptor_tcp_impl>(io_, configuration_);
        if (its_acceptor) {
            boost::system::error_code its_error;
            int its_retry{0};
            do {
                its_acceptor->init(boost::asio::ip::tcp::endpoint(its_address, its_port), its_error);
                if (its_error) {
                    VSOMEIP_ERROR_P << "Remote routing root endpoint creation failed (" << its_retry << ") Client 0x"
                                    << hex4(VSOMEIP_ROUTING_CLIENT) << ": " << its_error.message();
                    std::this_thread::sleep_for(std::chrono::milliseconds(VSOMEIP_ROUTING_ROOT_RECONNECT_INTERVAL));
                }
                its_retry++;
            } while (its_retry < VSOMEIP_ROUTING_ROOT_RECONNECT_RETRIES && its_error);

            if (its_error) {
                return false;
            }
            _tcp_acceptor = its_acceptor;
        }
    } catch (const std::exception& e) {
        VSOMEIP_ERROR_P << e.what();
        return false;
    }
    return true;
}

void endpoint_manager_impl::setup_root_server(std::shared_ptr<local_server>& _root, std::shared_ptr<local_acceptor> _acceptor,
                                              const std::shared_ptr<routing_host>& _host) {
    auto create_server = [this, _host](std::shared_ptr<local_acceptor> acceptor) {
        return std::make_shared<local_server>(
                io_, std::move(acceptor), configuration_, _host,
                [weak_self = weak_from_this(), this](auto _ep) {
                    if (auto self = weak_self.lock(); self) {
                        add_local_routing_endpoint(std::move(_ep));
                    }
                },
                true, get_client_host());
    };

    _root = create_server(_acceptor);
}

bool endpoint_manager_impl::create_routing_root(std::shared_ptr<local_server>& _root, const transport_protocol_e& _type,
                                                bool& _is_socket_activated, const std::shared_ptr<routing_host>& _host) {

    std::stringstream its_endpoint_path_ss;
    its_endpoint_path_ss << utility::get_base_path(configuration_->get_network()) << VSOMEIP_ROUTING_CLIENT;
    const std::string its_endpoint_path = its_endpoint_path_ss.str();

    std::shared_ptr<local_acceptor> acceptor;

    VSOMEIP_INFO << "Creating routing root with transport protocol: " << (_type == transport_protocol_e::UDS ? "UDS" : "TCP");

    if (configuration_->is_local_routing() || (is_uds_preferred_ && _type == transport_protocol_e::UDS)) {
#if defined(__linux__) || defined(__QNX__)
        if (!create_local_uds_acceptor(acceptor, its_endpoint_path, _is_socket_activated)) {
            return false;
        }
#else
        if (!create_fallback_tcp_acceptor(acceptor)) {
            return false;
        }
        _is_socket_activated = false;
#endif // __linux__ || __QNX__
    } else {
        if (!create_local_tcp_acceptor(acceptor)) {
            return false;
        }
        _is_socket_activated = false;
    }

    setup_root_server(_root, acceptor, _host);
    return true;
}

instance_t endpoint_manager_impl::find_instance(service_t _service, boardnet_endpoint* const _endpoint) const {
    instance_t its_instance(0xFFFF);
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    auto found_service = service_instances_.find(_service);
    if (found_service != service_instances_.end()) {
        auto found_endpoint = found_service->second.find(_endpoint);
        if (found_endpoint != found_service->second.end()) {
            its_instance = found_endpoint->second;
        }
    }
    return its_instance;
}

instance_t endpoint_manager_impl::find_instance_multicast(service_t _service, const boost::asio::ip::address& _sender) const {
    instance_t its_instance(0xFFFF);
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    auto found_service = service_instances_multicast_.find(_service);
    if (found_service != service_instances_multicast_.end()) {
        auto found_sender = found_service->second.find(_sender);
        if (found_sender != found_service->second.end()) {
            its_instance = found_sender->second;
        }
    }
    return its_instance;
}

bool endpoint_manager_impl::remove_instance(service_t _service, boardnet_endpoint* const _endpoint) {
    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        auto found_service = service_instances_.find(_service);
        if (found_service != service_instances_.end()) {
            if (found_service->second.erase(_endpoint)) {
                if (!found_service->second.size()) {
                    service_instances_.erase(found_service);
                }
            }
        }
    }
    return !is_used_endpoint(_endpoint);
}

bool endpoint_manager_impl::remove_instance_multicast(service_t _service, instance_t _instance) {
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    auto found_service = service_instances_multicast_.find(_service);
    if (found_service != service_instances_multicast_.end()) {
        for (auto& its_sender : found_service->second) {
            if (its_sender.second == _instance) {
                if (found_service->second.erase(its_sender.first)) {
                    if (!found_service->second.size()) {
                        service_instances_multicast_.erase(_service);
                    }
                }
                return true;
            }
        }
    }
    return false;
}

void endpoint_manager_impl::on_connect(std::shared_ptr<boardnet_endpoint> _endpoint) {
    // Is called when endpoint->connect succeeded!
    struct service_info {
        service_t service_id_;
        instance_t instance_id_;
        major_version_t major_;
        minor_version_t minor_;
        std::shared_ptr<boardnet_endpoint> endpoint_;
    };

    // Set to state CONNECTED as connection is not yet fully established in remote side POV
    // but endpoint is ready to send / receive. Set to ESTABLISHED after timer expires
    // to prevent inserting subscriptions twice or send out subscription before remote side
    // is finished with TCP 3 way handshake
    _endpoint->set_connected(true);

    std::forward_list<struct service_info> services_to_report_;
    {
        const bool endpoint_is_reliable = _endpoint->is_reliable();
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        for (auto& its_service : remote_services_) {
            for (auto& its_instance : its_service.second) {
                auto found_endpoint = its_instance.second.find(endpoint_is_reliable);
                if (found_endpoint != its_instance.second.end()) {
                    if (found_endpoint->second == _endpoint) {
                        std::shared_ptr<serviceinfo> its_info(router_->find_service(its_service.first, its_instance.first));
                        if (!its_info) {
                            _endpoint->set_established(true);
                            return;
                        }
                        // only report services offered via TCP+UDP when both
                        // endpoints are connected
                        const auto its_other_endpoint = its_info->get_endpoint(!endpoint_is_reliable);

                        if (!its_other_endpoint || (its_other_endpoint && its_other_endpoint->is_established_or_connected())) {
                            services_to_report_.push_front(
                                    {its_service.first, its_instance.first, its_info->get_major(), its_info->get_minor(), _endpoint});
                        }
                    }
                }
            }
        }
    }
    for (const auto& s : services_to_report_) {
        router_->service_endpoint_connected(s.service_id_, s.instance_id_, s.major_, s.minor_, s.endpoint_);
    }
    if (services_to_report_.empty()) {
        _endpoint->set_established(true);
    }
}

void endpoint_manager_impl::on_disconnect(std::shared_ptr<boardnet_endpoint> _endpoint) {
    // Is called when endpoint->connect fails!
    std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
    for (auto& its_service : remote_services_) {
        for (auto& its_instance : its_service.second) {
            const bool is_reliable = _endpoint->is_reliable();
            auto found_endpoint = its_instance.second.find(is_reliable);
            if (found_endpoint != its_instance.second.end()) {
                if (found_endpoint->second == _endpoint) {
                    std::shared_ptr<serviceinfo> its_info(router_->find_service(its_service.first, its_instance.first));
                    if (!its_info) {
                        return;
                    }
                    if (!is_reliable) {
                        router_->on_availability(its_service.first, its_instance.first, availability_state_e::AS_UNAVAILABLE,
                                                 its_info->get_major(), its_info->get_minor());
                    }
                    router_->service_endpoint_disconnected(its_service.first, its_instance.first, its_info->get_major(),
                                                           its_info->get_minor(), _endpoint);
                }
            }
        }
    }
}

bool endpoint_manager_impl::on_bind_error(std::shared_ptr<boardnet_endpoint> _endpoint, const boost::asio::ip::address& _remote_address,
                                          std::uint16_t _remote_port, uint16_t& _local_port) {

    std::scoped_lock its_ep_lock{endpoint_mutex_};
    for (auto& its_service : remote_services_) {
        for (auto& its_instance : its_service.second) {
            const bool is_reliable = _endpoint->is_reliable();
            auto found_endpoint = its_instance.second.find(is_reliable);
            if (found_endpoint != its_instance.second.end()) {
                if (found_endpoint->second == _endpoint) {
                    // get a new client port using service / instance / remote port
                    uint16_t its_old_local_port = _endpoint->get_local_port();
                    _local_port = ILLEGAL_PORT; // will be given as a new local port

                    std::map<bool, std::set<port_t>> its_used_client_ports;
                    get_used_client_ports(_remote_address, _remote_port, its_used_client_ports);
                    if (configuration_->get_client_port(its_service.first, its_instance.first, _remote_port, is_reliable,
                                                        its_used_client_ports, _local_port)) {
                        release_used_client_port(_remote_address, _remote_port, _endpoint->is_reliable(), its_old_local_port);
                        return true;
                    }
                }
            }
        }
    }
    return false;
}

void endpoint_manager_impl::on_error(const byte_t* _data, length_t _length, boardnet_endpoint* const _receiver,
                                     const boost::asio::ip::address& _remote_address, std::uint16_t _remote_port) {
    instance_t its_instance = 0;
    if (_length >= VSOMEIP_SERVICE_POS_MAX) {
        service_t its_service = bithelper::read_uint16_be(&_data[VSOMEIP_SERVICE_POS_MIN]);
        its_instance = find_instance(its_service, _receiver);
    }
    router_->send_error(return_code_e::E_MALFORMED_MESSAGE, _data, _length, its_instance, _receiver->is_reliable(), _receiver,
                        _remote_address, _remote_port);
}

void endpoint_manager_impl::get_used_client_ports(const boost::asio::ip::address& _remote_address, port_t _remote_port,
                                                  std::map<bool, std::set<port_t>>& _used_ports) {
    auto find_address = used_client_ports_.find(_remote_address);
    if (find_address != used_client_ports_.end()) {
        auto find_port = find_address->second.find(_remote_port);
        if (find_port != find_address->second.end())
            _used_ports = find_port->second;
    }
}

void endpoint_manager_impl::request_used_client_port(const boost::asio::ip::address& _remote_address, port_t _remote_port, bool _reliable,
                                                     port_t _local_port) {

    std::scoped_lock its_lock(endpoint_mutex_);
    used_client_ports_[_remote_address][_remote_port][_reliable].insert(_local_port);
}

void endpoint_manager_impl::release_used_client_port(const boost::asio::ip::address& _remote_address, port_t _remote_port, bool _reliable,
                                                     port_t _local_port) {

    std::scoped_lock its_lock(endpoint_mutex_);
    auto find_address = used_client_ports_.find(_remote_address);
    if (find_address != used_client_ports_.end()) {
        auto find_port = find_address->second.find(_remote_port);
        if (find_port != find_address->second.end()) {
            auto find_reliable = find_port->second.find(_reliable);
            if (find_reliable != find_port->second.end())
                find_reliable->second.erase(_local_port);
        }
    }
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::find_remote_client(service_t _service, instance_t _instance, bool _reliable) {

    std::shared_ptr<boardnet_endpoint> its_endpoint;
    auto found_service = remote_services_.find(_service);
    if (found_service != remote_services_.end()) {
        auto found_instance = found_service->second.find(_instance);
        if (found_instance != found_service->second.end()) {
            auto found_reliability = found_instance->second.find(_reliable);
            if (found_reliability != found_instance->second.end()) {
                its_endpoint = found_reliability->second;
            }
        }
    }
    if (its_endpoint) {
        return its_endpoint;
    }

    // Endpoint did not yet exist. Get the partition id to check
    // whether the client endpoint for the partition does exist.
    partition_id_t its_partition_id = configuration_->get_partition_id(_service, _instance);

    // If another service within the same partition is hosted on the
    // same server_endpoint reuse the existing client_endpoint.
    auto found_service_info = remote_service_info_.find(_service);
    if (found_service_info != remote_service_info_.end()) {
        auto found_instance = found_service_info->second.find(_instance);
        if (found_instance != found_service_info->second.end()) {
            auto found_reliable = found_instance->second.find(_reliable);
            if (found_reliable != found_instance->second.end()) {
                std::shared_ptr<endpoint_definition> its_ep_def = found_reliable->second;
                auto found_address = client_endpoints_.find(its_ep_def->get_address());
                if (found_address != client_endpoints_.end()) {
                    auto found_port = found_address->second.find(its_ep_def->get_remote_port());
                    if (found_port != found_address->second.end()) {
                        auto found_reliable2 = found_port->second.find(_reliable);
                        if (found_reliable2 != found_port->second.end()) {
                            auto found_partition = found_reliable2->second.find(its_partition_id);
                            if (found_partition != found_reliable2->second.end()) {
                                its_endpoint = found_partition->second;

                                // store the endpoint under this service/instance id
                                // as well - needed for later cleanup
                                remote_services_[_service][_instance][_reliable] = its_endpoint;
                                service_instances_[_service][its_endpoint.get()] = _instance;

                                // add endpoint to serviceinfo object
                                auto found_service_info_inner = router_->find_service(_service, _instance);
                                if (found_service_info_inner) {
                                    found_service_info_inner->set_endpoint(its_endpoint, _reliable);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    return its_endpoint;
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::create_remote_client(service_t _service, instance_t _instance, bool _reliable) {
    std::shared_ptr<boardnet_endpoint> its_endpoint;
    std::shared_ptr<endpoint_definition> its_endpoint_def;
    uint16_t its_local_port;

    boost::asio::ip::address its_remote_address;
    uint16_t its_remote_port = ILLEGAL_PORT;

    auto found_service = remote_service_info_.find(_service);
    if (found_service != remote_service_info_.end()) {
        auto found_instance = found_service->second.find(_instance);
        if (found_instance != found_service->second.end()) {
            auto found_reliability = found_instance->second.find(_reliable);
            if (found_reliability != found_instance->second.end()) {
                its_endpoint_def = found_reliability->second;
                its_remote_address = its_endpoint_def->get_address();
                its_remote_port = its_endpoint_def->get_port();
            }
        }
    }

    if (its_remote_port != ILLEGAL_PORT) {
        // if client port range for remote service port range is configured
        // and remote port is in range, determine unused client port
        std::map<bool, std::set<port_t>> its_used_client_ports;
        get_used_client_ports(its_remote_address, its_remote_port, its_used_client_ports);
        if (configuration_->get_client_port(_service, _instance, its_remote_port, _reliable, its_used_client_ports, its_local_port)) {
            if (its_endpoint_def) {
                its_endpoint = create_client_endpoint(its_remote_address, its_local_port, its_remote_port, _reliable);
            }

            if (its_endpoint) {
                request_used_client_port(its_remote_address, its_remote_port, _reliable, its_local_port);

                service_instances_[_service][its_endpoint.get()] = _instance;
                remote_services_[_service][_instance][_reliable] = its_endpoint;

                partition_id_t its_partition = configuration_->get_partition_id(_service, _instance);
                client_endpoints_[its_endpoint_def->get_address()][its_endpoint_def->get_port()][_reliable][its_partition] = its_endpoint;
                // Set the basic route to the service in the service info
                auto found_service_info = router_->find_service(_service, _instance);
                if (found_service_info) {
                    found_service_info->set_endpoint(its_endpoint, _reliable);
                }
                VSOMEIP_INFO_P << its_endpoint_def->get_address().to_string() << ":" << its_endpoint_def->get_port()
                               << " reliable: " << _reliable << " using local port: " << its_local_port;
            }
        }
    }
    return its_endpoint;
}

std::shared_ptr<boardnet_endpoint> endpoint_manager_impl::create_client_endpoint(const boost::asio::ip::address& _address,
                                                                                 uint16_t _local_port, uint16_t _remote_port,
                                                                                 bool _reliable) {

    std::shared_ptr<boardnet_endpoint> its_endpoint;
    boost::asio::ip::address its_unicast = configuration_->get_unicast_address();

    try {
        if (_reliable) {
            bool its_use_magic_cookies = configuration_->has_enabled_magic_cookies(_address.to_string(), _remote_port);
            its_endpoint = std::make_shared<tcp_client_endpoint_impl>(
                    shared_from_this(), router_->shared_from_this(), boost::asio::ip::tcp::endpoint(its_unicast, _local_port),
                    boost::asio::ip::tcp::endpoint(_address, _remote_port), io_, configuration_, its_use_magic_cookies);
        } else {
            its_endpoint = std::make_shared<udp_client_endpoint_impl>(
                    shared_from_this(), router_->shared_from_this(), boost::asio::ip::udp::endpoint(its_unicast, _local_port),
                    boost::asio::ip::udp::endpoint(_address, _remote_port), io_, configuration_);
        }
    } catch (...) {
        VSOMEIP_ERROR_P << "Client endpoint creation failed";
    }

    return its_endpoint;
}

void endpoint_manager_impl::log_client_states() const {
    std::stringstream its_log;
    client_endpoints_t its_client_endpoints;
    std::vector<std::pair<std::tuple<boost::asio::ip::address, uint16_t, bool>, size_t>> its_client_queue_sizes;

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        its_client_endpoints = client_endpoints_;
    }

    for (const auto& its_address : its_client_endpoints) {
        for (const auto& its_port : its_address.second) {
            for (const auto& its_reliability : its_port.second) {
                for (const auto& its_partition : its_reliability.second) {
                    size_t its_queue_size = its_partition.second->get_queue_size();
                    if (its_queue_size > VSOMEIP_DEFAULT_QUEUE_WARN_SIZE)
                        its_client_queue_sizes.push_back(
                                std::make_pair(std::make_tuple(its_address.first, its_port.first, its_reliability.first), its_queue_size));
                }
            }
        }
    }

    std::sort(its_client_queue_sizes.begin(), its_client_queue_sizes.end(),
              [](const std::pair<std::tuple<boost::asio::ip::address, uint16_t, bool>, size_t>& _a,
                 const std::pair<std::tuple<boost::asio::ip::address, uint16_t, bool>, size_t>& _b) { return (_a.second > _b.second); });

    // NOTE: limit is important, do *NOT* want an arbitrarily big string!
    size_t its_max(std::min(size_t(5), its_client_queue_sizes.size()));
    for (size_t i = 0; i < its_max; i++) {
        its_log << std::get<0>(its_client_queue_sizes[i].first).to_string() << ":" << std::get<1>(its_client_queue_sizes[i].first) << "("
                << (std::get<2>(its_client_queue_sizes[i].first) ? "tcp" : "udp") << "):" << its_client_queue_sizes[i].second;
        if (i < its_max - 1)
            its_log << ", ";
    }

    if (its_log.str().length() > 0)
        VSOMEIP_INFO << "ECQ: " << its_client_queue_sizes.size() << " [" << its_log.str() << "]";
}

void endpoint_manager_impl::log_server_states() const {
    std::stringstream its_log;
    server_endpoints_t its_server_endpoints;
    std::vector<std::pair<std::pair<uint16_t, bool>, size_t>> its_client_queue_sizes;

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        its_server_endpoints = server_endpoints_;
    }

    for (const auto& its_port : its_server_endpoints) {
        for (const auto& its_reliability : its_port.second) {
            size_t its_queue_size = its_reliability.second->get_queue_size();
            if (its_queue_size > VSOMEIP_DEFAULT_QUEUE_WARN_SIZE)
                its_client_queue_sizes.push_back(std::make_pair(std::make_pair(its_port.first, its_reliability.first), its_queue_size));
        }
    }

    std::sort(its_client_queue_sizes.begin(), its_client_queue_sizes.end(),
              [](const std::pair<std::pair<uint16_t, bool>, size_t>& _a, const std::pair<std::pair<uint16_t, bool>, size_t>& _b) {
                  return (_a.second > _b.second);
              });

    // NOTE: limit is important, do *NOT* want an arbitrarily big string!
    size_t its_max(std::min(size_t(5), its_client_queue_sizes.size()));
    for (size_t i = 0; i < its_max; i++) {
        its_log << its_client_queue_sizes[i].first.first << "(" << (its_client_queue_sizes[i].first.second ? "tcp" : "udp")
                << "):" << its_client_queue_sizes[i].second;
        if (i < its_max - 1)
            its_log << ", ";
    }

    if (its_log.str().length() > 0)
        VSOMEIP_INFO << "ESQ: " << its_client_queue_sizes.size() << " [" << its_log.str() << "]";
}

void endpoint_manager_impl::add_multicast_option(const multicast_option_t& _option) {

    std::scoped_lock its_guard(options_mutex_);
    options_queue_.push(_option);
    options_condition_.notify_one();
}

void endpoint_manager_impl::process_multicast_options() {
    constexpr unsigned MAX_REPEAT_DELAY_MS = 32;
    constexpr unsigned INITIAL_REPEAT_DELAY_MS = 1;
    unsigned repeat_delay_ms = INITIAL_REPEAT_DELAY_MS;

    std::unique_lock<std::mutex> its_lock(options_mutex_);
    while (is_processing_options_) {
        options_condition_.wait(its_lock, [this] { return !options_queue_.empty() || !is_processing_options_; });

        if (!is_processing_options_) {
            return;
        }

        auto its_front = options_queue_.front();
        options_queue_.pop();
        auto its_udp_server_endpoint = std::dynamic_pointer_cast<udp_server_endpoint_impl>(its_front.endpoint_);
        if (its_udp_server_endpoint) {
            // Unlock before setting the option as this might block
            its_lock.unlock();

            boost::system::error_code its_error;
            its_udp_server_endpoint->set_multicast_option(its_front.address_, its_front.is_join_, its_error);

            // Lock again after setting the option
            its_lock.lock();

            if (its_error) {
                VSOMEIP_ERROR_P << (its_front.is_join_ ? "joining " : "leaving ") << its_front.address_ << " (" << its_error.message()
                                << ")";

                if (its_front.is_join_) {
                    multicast_option_t its_leave_option{its_front.endpoint_, false, its_front.address_};

                    options_queue_.push(its_leave_option);
                    options_queue_.push(its_front);

                    its_lock.unlock();
                    std::this_thread::sleep_for(std::chrono::milliseconds(repeat_delay_ms));
                    its_lock.lock();

                    if ((repeat_delay_ms *= 2) > MAX_REPEAT_DELAY_MS) {
                        repeat_delay_ms = MAX_REPEAT_DELAY_MS;
                    }
                }
            } else {
                repeat_delay_ms = INITIAL_REPEAT_DELAY_MS;
            }
        }
    }
}

bool endpoint_manager_impl::is_used_endpoint(boardnet_endpoint* const _endpoint) const {

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);
        // Do we still use the endpoint to offer a service instance?
        for (const auto& si : service_instances_)
            if (si.second.find(_endpoint) != si.second.end())
                return true;
    }

    // Do we still use the endpoint to join a multicast address=
    auto its_udp_server_endpoint = dynamic_cast<udp_server_endpoint_impl*>(_endpoint);
    if (its_udp_server_endpoint)
        return its_udp_server_endpoint->is_joining();

    return false;
}

void endpoint_manager_impl::drop_from(const boost::asio::ip::address& _address) {
    std::scoped_lock const its_endpoint_lock{routing_endpoint_mtx_};
    for (auto const& [client, ep] : routing_endpoints_) {
        bool const drop = _address == ep->peer_endpoint().address();
        if (drop) {
            VSOMEIP_INFO_P << "dropping connection for client: " << hex4(client) << ", " << ep->name();
            // this is technically not correct, but it should be good enough for now.
            ep->trigger_error(); // ensure that we do all the clean-up
        }
    }
    // important to have the lock still acquired, because the endpoints error handler
    // might try to remove something and the pending endpoint should not be promoted due to this.
    for (auto itr = pending_routing_endpoints_.begin(); itr != pending_routing_endpoints_.end();) {
        client_t client = itr->first;
        std::shared_ptr<local_endpoint>& ep = itr->second;
        bool const drop = ep->peer_endpoint().address() == _address;

        if (drop) {
            VSOMEIP_INFO_P << "dropping pending connection for client " << hex4(client) << ", " << ep->name();
            // immediate, data loss is OK
            ep->stop(true);
            itr = pending_routing_endpoints_.erase(itr);
        } else {
            ++itr;
        }
    }
}

void endpoint_manager_impl::add_local_routing_endpoint(std::shared_ptr<local_endpoint> _ep) {
    auto const client = _ep->connected_client();
    {
        std::scoped_lock const its_endpoint_lock{routing_endpoint_mtx_};
        add_local_routing_endpoint_unlocked(client, _ep);
    }

    // _ep->peer_endpoint().port() - 1 because we need to pass the server port
    router_->on_register_application(client, _ep->peer_endpoint().address(), _ep->peer_endpoint().port() - 1);
}

std::unordered_set<client_t> endpoint_manager_impl::get_connected_clients() const {
    std::scoped_lock its_lock(routing_endpoint_mtx_);
    std::unordered_set<client_t> clients;
    for (const auto& [id, _] : routing_endpoints_) {
        clients.insert(id);
    }
    return clients;
}

void endpoint_manager_impl::add_local_routing_endpoint_unlocked(client_t _client, const std::shared_ptr<local_endpoint>& _ep) {
    if (auto const it = routing_endpoints_.find(_client); it != routing_endpoints_.end()) {
        VSOMEIP_WARNING_P << "Already existing endpoint found for client 0x" << hex4(_client)
                          << ". Enforcing a clean-up of endpoint:" << it->second->name() << " but queuing endpoint: " << _ep->name();
        if (auto const it2 = pending_routing_endpoints_.find(_client); it2 != pending_routing_endpoints_.end()) {
            VSOMEIP_WARNING_P << "Replacing existing pending for client 0x" << hex4(_client) << ", connection: " << it2->second->name();
            it2->second->stop(true);
        }
        pending_routing_endpoints_[_client] = _ep;
        it->second->trigger_error();
        return;
    }

    // Remove clients that occupy the same address
    if (auto const addr = _ep->peer_endpoint(); addr != boost::asio::ip::tcp::endpoint{}) {
        for (auto& [id, ep] : routing_endpoints_) {
            if (ep->peer_endpoint() == addr) {
                if (id != _client) {
                    // the other caase we did already take care above.
                    VSOMEIP_WARNING_P << "Deregistering old client " << hex4(id) << " due to new client " << hex4(_client) << " @ " << addr;
                    ep->trigger_error();
                }
                break;
            }
        }
    }

    router_->register_client_error_handler(_client, _ep);
    routing_endpoints_[_client] = _ep;
    _ep->start();
    VSOMEIP_INFO_P << "self 0x" << hex4(router_->get_client()) << ", client 0x" << hex4(_client) << ", connection > " << _ep->name();
}

void endpoint_manager_impl::flush_routing_endpoint_queues() {
    auto const eps = [this] {
        std::scoped_lock lock{routing_endpoint_mtx_};
        return routing_endpoints_;
    }();
    for (auto const& [_, ep] : eps) {
        ep->flush_queue();
    }
}

std::shared_ptr<local_endpoint> endpoint_manager_impl::find_routing_endpoint(client_t _client) const {
    std::scoped_lock const lock{routing_endpoint_mtx_};
    if (auto const it = routing_endpoints_.find(_client); it != routing_endpoints_.end()) {
        return it->second;
    }
    return nullptr;
}

void endpoint_manager_impl::remove_routing_endpoint(client_t _client) {
    VSOMEIP_INFO_P << "client 0x" << hex4(_client);
    std::scoped_lock const lock{routing_endpoint_mtx_};
    if (auto const it = routing_endpoints_.find(_client); it != routing_endpoints_.end()) {
        it->second->stop(true);
        VSOMEIP_INFO_P << "self 0x" << hex4(router_->get_client()) << " is closing connection to client 0x" << hex4(_client)
                       << " endpoint > " << it->second->name();
        routing_endpoints_.erase(it);
    }
    if (auto const it = pending_routing_endpoints_.find(_client); it != pending_routing_endpoints_.end()) {
        add_local_routing_endpoint_unlocked(_client, it->second);
        // safe to still use the iterator, because the adding of the endpoint can no longer fail
        // (because of the locked mtx), therefore the pending set remains untouched
        pending_routing_endpoints_.erase(it);
    }
}

void endpoint_manager_impl::clear_routing_endpoints() {
    VSOMEIP_INFO_P << " ";
    std::scoped_lock const lock{routing_endpoint_mtx_};
    for (auto const& [id, ep] : routing_endpoints_) {
        ep->register_error_handler(nullptr);
        ep->stop(false);
    }
    for (auto const& [id, ep] : pending_routing_endpoints_) {
        ep->stop(true); // never "started", but the socket needs to be stopped anyhow
    }
    routing_endpoints_.clear();
    pending_routing_endpoints_.clear();
}

void endpoint_manager_impl::suspend() {
    std::vector<std::weak_ptr<boardnet_endpoint>> weak_endpoints;

    {
        std::scoped_lock its_lock{endpoint_mutex_};

        for (const auto& [its_port, protocols] : server_endpoints_) {
            for (const auto& [its_protocol, its_endpoint] : protocols) {
                weak_endpoints.push_back(its_endpoint);
            }
        }
    }

    for (const auto& its_weak : weak_endpoints) {
        if (auto its_endpoint = its_weak.lock()) {
            its_endpoint->stop(false);
        }
    }
}

void endpoint_manager_impl::resume() {
    std::vector<std::tuple<boost::asio::ip::address, uint16_t, bool, partition_id_t>> clients;
    std::vector<std::tuple<uint16_t, bool>> servers;

    {
        std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);

        // restart client endpoints

        for (const auto& [its_address, ports] : client_endpoints_) {
            for (const auto& [its_port, protocols] : ports) {
                for (const auto& [its_protocol, partitions] : protocols) {
                    for (const auto& [its_partition, its_endpoint] : partitions) {
                        clients.push_back(std::make_tuple(its_address, its_port, its_protocol, its_partition));
                    }
                }
            }
        }

        // restart server endpoints

        for (const auto& [its_port, protocols] : server_endpoints_) {
            for (const auto& [its_protocol, its_endpoint] : protocols) {
                servers.push_back(std::make_tuple(its_port, its_protocol));
            }
        }
    }

    for (const auto& [its_address, its_port, its_protocol, its_partition] : clients) {
        std::shared_ptr<boardnet_endpoint> its_endpoint;

        {
            std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);

            const auto& ports = client_endpoints_.find(its_address);
            if (ports == client_endpoints_.end()) {
                continue;
            }

            const auto& protocols = ports->second.find(its_port);
            if (protocols == ports->second.end()) {
                continue;
            }

            const auto& partitions = protocols->second.find(its_protocol);
            if (partitions == protocols->second.end()) {
                continue;
            }

            const auto& endpoint = partitions->second.find(its_partition);
            if (endpoint == partitions->second.end()) {
                continue;
            }

            its_endpoint = endpoint->second;
        }

        // From here, there is the risk that this endpoint will be removed from
        // the client list because we don't have the lock on endpoint_mutex_.
        // The consequence is that the old client is restarted and will occupy
        // the endpoint used by another client.

        its_endpoint->restart();
    }

    for (const auto& [its_port, its_protocol] : servers) {
        std::shared_ptr<boardnet_endpoint> its_endpoint;

        {
            std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);

            const auto& ports = server_endpoints_.find(its_port);
            if (ports == server_endpoints_.end()) {
                continue;
            }

            const auto& endpoint = ports->second.find(its_protocol);
            if (endpoint == ports->second.end()) {
                continue;
            }

            its_endpoint = endpoint->second;
        }

        // Restart the server and then check that it is
        // still in the active list of servers.

        its_endpoint->restart();

        std::shared_ptr<boardnet_endpoint> its_check_endpoint;

        {
            std::scoped_lock<std::recursive_mutex> its_lock(endpoint_mutex_);

            const auto& ports = server_endpoints_.find(its_port);
            if (ports != server_endpoints_.end()) {
                const auto& endpoint = ports->second.find(its_protocol);
                if (endpoint != ports->second.end()) {
                    its_check_endpoint = endpoint->second;
                }
            }
        }

        if (its_check_endpoint != its_endpoint) {
            VSOMEIP_ERROR_P << "server has been removed from active list, stop it";
            its_endpoint->stop(true);
        }
    }
}
client_t endpoint_manager_impl::get_client() const {
    return router_->get_client();
}

std::string endpoint_manager_impl::get_client_host() const {
    return router_->get_client_host();
}

bool endpoint_manager_impl::get_guest(client_t _client, boost::asio::ip::address& _address, port_t& _port) const {
    if (auto const ep = find_routing_endpoint(_client); ep) {
        if (auto const peer = ep->peer_endpoint(); peer != boost::asio::ip::tcp::endpoint{}) {
            _address = peer.address();
            // _ep->peer_endpoint().port() - 1 because we need to pass the server port
            _port = peer.port() - 1;
            return true;
        }
    }
    return false;
}
} // namespace vsomeip_v3
