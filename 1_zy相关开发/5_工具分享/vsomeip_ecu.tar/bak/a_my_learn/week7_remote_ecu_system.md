# 第 7 周: 远端 ECU 通信系统搭建路径

目标: 用当前 vSomeIP 工程先搭一个本机可抓包的 SOME/IP client/server, 行为尽量接近远端车载 ECU; 后续平滑迁移到两台电脑通信, 再迁移到 VLAN 网卡和真实 ECU。

## 工程结构判断

- `interface/vsomeip`: 对应用暴露的 C++ API。client/server 只应该直接依赖这里, 比如 `application`, `runtime`, `message`, `payload`。
- `implementation/routing`: vSomeIP 的路由核心。它决定本机应用之间走本地 routing/IPC, 还是通过外部 UDP/TCP endpoint 上网。
- `implementation/endpoints`: UDP/TCP socket 收发。`device` 配置最终在这里通过 `SO_BINDTODEVICE` 绑定网卡。
- `implementation/service_discovery`: SOME/IP-SD 的 FindService, OfferService, SubscribeEventgroup 等逻辑。
- `implementation/configuration`: JSON 配置解析, 包括 `unicast`, `netmask`, `device`, `services`, `clients`, `routing`, `service-discovery`。
- `config`: 官方 sample JSON。适合看配置字段, 但里面的 IP 都需要改成当前机器或测试网络的 IP。
- `examples`: request/response 和 subscribe/notify 的最小示例。新增的 `examples/ecu_sim` 是面向远端 ECU 通信的整合版。
- `tools/wireshark_plugin`: vSomeIP Wireshark Lua dissector, 抓包分析时可辅助识别 SOME/IP/vSomeIP。
- `test/network_tests`: 很多双节点场景模板, 后面做两 PC 或 CI 网络测试时值得复用。

## 抓包心智模型

同一台 Linux 主机上启动两个普通 vSomeIP 进程时, 它们可能被当成本机应用, 经过 routing manager 和本地 IPC 通信。这样应用能通信, 但 Wireshark 在物理网卡上看不到真正的 SOME/IP request/response。

要模拟远端 ECU, 更可靠的方法是让 client 和 service 落在两个不同 IP 栈里:

1. 本机阶段: 两个 network namespace + veth pair。
2. 两机阶段: 两台电脑各跑一个 vSomeIP routing manager/application。
3. ECU 阶段: 电脑 NIC/VLAN 与真实 ECU 同网段, JSON 绑定到实际接口。

## 新增本机 ECU 模拟

位置:

- `examples/ecu_sim/ecu_sim_service.cpp`
- `examples/ecu_sim/ecu_sim_client.cpp`
- `examples/ecu_sim/config/ecu-service-veth.json`
- `examples/ecu_sim/config/ecu-client-veth.json`
- `examples/ecu_sim/run_local_netns.sh`
- `examples/ecu_sim/README.md`

协议面:

- Service ID: `0x1234`
- Instance ID: `0x5678`
- Method ID: `0x0421`
- Event ID: `0x8778`
- Eventgroup ID: `0x4465`
- SOME/IP-SD: `224.244.224.245:30490/udp`
- Service UDP port: `30509`
- Client UDP ports: `40000`, `40001`, `40002`
- Service TCP port: `30510`
- Client TCP ports: `41000`, `41001`, `41002`
- 本机默认 veth 网段: service `172.31.0.10/29`, client `172.31.0.11/29`。不要用 `/30` 搭配 `.10/.11`, 因为 `.11` 会成为广播地址。

测试工程可复用经验:

- `test/network_tests/conf/setup_test.sh.in` 会为测试创建独立 `VSOMEIP_BASE_PATH`, 避免多个 routing socket 在 `/tmp` 下互相影响。`examples/ecu_sim/run_local_netns.sh` 已采用同样思路, 分别使用 `/tmp/vsomeip-ecu-sim/service` 和 `/tmp/vsomeip-ecu-sim/client`。
- `client_id_tests` 和 `subscribe_notify_tests` 大量覆盖相同/不同 client id、相同/不同端口组合。我们的示例显式固定 application id 和 client 源端口, 方便抓包和对齐 ECU 规范。
- `routing_tests/external_local_routing_test_*` 展示了关闭 SD 的静态远端配置: client JSON 的 `services[].unicast` 指向远端服务 IP, `service-discovery.enable=false`。我们的 `ecu-*-static*.json` 就按这个模式补齐。
- `subscribe_notify_tests` 同时覆盖 UDP/TCP 和 local TCP routing。我们的 `PROTOCOL=tcp` 支持 method request/response 走 TCP, 事件仍保持 UDP 通知, 这是很多车载接口的常见组合。
- `big_payload_tests` 和 `someip_tp_tests` 表明大 UDP payload 需要 `someip-tp` 和 `max-payload-size-unreliable`; 后续真实 ECU 如果有大报文, 要按方法/事件 ID 增加这些配置。
- `e2e_tests` 和 `security_tests` 说明 E2E 与安全策略都是 JSON 配置驱动, 但应用 payload 也必须按 profile/CRC/数据 ID 的要求组织。当前示例暂不启用 E2E/security, 先把链路、端口、SD 和 VLAN 跑通。

运行:

```bash
examples/ecu_sim/run_local_netns.sh build
sudo examples/ecu_sim/run_local_netns.sh start
```

模式切换:

```bash
sudo env MODE=sd PROTOCOL=udp examples/ecu_sim/run_local_netns.sh start
sudo env MODE=sd PROTOCOL=tcp examples/ecu_sim/run_local_netns.sh start
sudo env MODE=static PROTOCOL=udp examples/ecu_sim/run_local_netns.sh start
sudo env MODE=static PROTOCOL=tcp examples/ecu_sim/run_local_netns.sh start
```

抓包:

```bash
sudo examples/ecu_sim/run_local_netns.sh capture
```

本机验证过程与指令意义:

```bash
cmake --build build --target examples -j"$(nproc)"
```

编译 `examples` 目标, 会生成 `build/examples/ecu_sim/ecu-sim-service` 和 `build/examples/ecu_sim/ecu-sim-client`。如果只想编译本示例, 也可以用 `examples/ecu_sim/run_local_netns.sh build`。

```bash
examples/ecu_sim/run_local_netns.sh validate
```

用 `jq` 检查 `examples/ecu_sim/config/*.json` 语法, 避免 vSomeIP 启动后才报配置错误。

```bash
sudo examples/ecu_sim/run_local_netns.sh setup
sudo ip netns exec vsomeip_cli ping -c 2 -W 1 172.31.0.10
sudo examples/ecu_sim/run_local_netns.sh clean
```

`setup` 创建两个 network namespace 和一对 veth: 服务端 `vsomeip_svc/vsecu0/172.31.0.10/29`, 客户端 `vsomeip_cli/vscli0/172.31.0.11/29`。`ping` 先验证二层/三层连通, `clean` 清理临时命名空间。这里使用 `/29`, 不使用 `/30`, 因为 `.11` 在 `172.31.0.8/30` 中是广播地址。

为了先打开 Wireshark 再抓到最早的 SD 报文, `setup/start` 默认会复用固定 namespace 和 veth, 不再删除已有接口。也就是说可以先运行:

```bash
sudo examples/ecu_sim/run_local_netns.sh setup
sudo -E ip netns exec vsomeip_cli wireshark -k -i vscli0
```

再在另一个终端运行 `start`。如果需要强制重建网络, 用 `sudo examples/ecu_sim/run_local_netns.sh reset`; 如果要彻底清理, 用 `sudo examples/ecu_sim/run_local_netns.sh clean`。

```bash
sudo env MODE=sd PROTOCOL=udp examples/ecu_sim/run_local_netns.sh start
```

启动服务端和客户端。`MODE=sd` 表示启用 SOME/IP-SD, 能看到 FindService、OfferService、SubscribeEventgroup、SubscribeAck; `PROTOCOL=udp` 表示 method request/response 走 UDP。脚本会给两端分别设置 `VSOMEIP_BASE_PATH`, 避免 routing socket 冲突, 并通过 JSON 的 `device` 把报文绑定到 `vsecu0`/`vscli0`。

另开终端抓包:

```bash
sudo env PCAP_PATH=/tmp/vsomeip-ecu-sim-sd-udp.pcap CAPTURE_COUNT=200 \
    examples/ecu_sim/run_local_netns.sh capture
```

`capture` 在客户端命名空间的 `vscli0` 上运行 `tcpdump`, 过滤 SD 端口 `30490`, 服务端 UDP 端口 `30509`, 客户端源端口 `40000-40002`, 以及 TCP 模式会用到的 `30510/41000-41002`。默认抓 200 个包自动退出, 避免外部信号被 AppArmor 的 `tcpdump` profile 拦截。

```bash
capinfos /tmp/vsomeip-ecu-sim-sd-udp.pcap
tcpdump -nn -r /tmp/vsomeip-ecu-sim-sd-udp.pcap | head -60
wireshark /tmp/vsomeip-ecu-sim-sd-udp.pcap
```

`capinfos` 确认 pcap 包数、链路类型和时间范围; `tcpdump -r` 快速检查源/目的 IP 和端口; `wireshark` 打开后用下面过滤器观察 SOME/IP 和 SD。

Wireshark 过滤:

```text
someip || someipsd
udp.port == 30490 || udp.port == 30509 || udp.port == 40000
tcp.port == 30510 || tcp.port == 41000
```

预期能看到:

- FindService / OfferService
- SubscribeEventgroup / SubscribeAck
- client -> service 的 SOME/IP request
- service -> client 的 SOME/IP response
- service -> client 的 event notification

静态模式下 SD 关闭, client 会关闭事件订阅, 只验证 request/response。事件订阅/SubscribeEventgroup 本质上依赖 SOME/IP-SD。

## 配置关键点

`unicast`: 当前节点在 SOME/IP 网络中的 IP。两机/真实 ECU 时必须是对应网卡 IP。

`netmask`: 当前 SOME/IP 网络的掩码。影响 vSomeIP 判断远端地址是否在同一网段。

`device`: 指定网卡名。设置后 endpoint 会绑定到这个接口, 便于强制报文走某张 NIC 或 VLAN 子接口。

`network`: 本机 UDS socket 命名前缀。一个 Linux 文件系统里跑多个 routing manager 时要区分, 否则 `/tmp` 下 socket 可能冲突。

`routing`: 当前节点的 routing manager 应用。每个 ECU/PC 节点通常有一个 routing manager。

`services`: 服务端声明自己提供的服务端口; 客户端在静态路由或关闭 SD 时也需要用它描述远端服务。

`clients`: 客户端源端口范围。为了抓包和对齐 ECU 规范, 建议显式配置。

`service-discovery`: 对齐远端 ECU 的 SD multicast IP, port, TTL, offer 周期和 initial delay。

`VSOMEIP_BASE_PATH`: routing socket 的根目录。测试脚本每次用临时目录隔离; 多个 ECU 模拟或多轮调试时也建议这样做。

`reliable` / `unreliable`: 分别对应 TCP/UDP。服务端配置开放端口; 客户端 `clients` 配置源端口池。

`someip-tp`: UDP 大报文分段。只有 ECU 规范要求大 UDP method/event payload 时再打开。

`e2e`: E2E profile 配置。仅配置 JSON 不够, payload 里的 CRC/counter/data ID 也要匹配规范。

## 两台电脑迁移

服务端电脑:

1. 拷贝 `ecu-service-veth.json`。
2. 改 `unicast` 为服务端电脑 SOME/IP 网卡 IP。
3. 改 `device` 为服务端网卡名, 如 `eno1`。
4. 保留服务端 UDP port `30509` 或改成 ECU 规范要求的端口。

客户端电脑:

1. 拷贝 `ecu-client-veth.json`。
2. 改 `unicast` 为客户端电脑 SOME/IP 网卡 IP。
3. 改 `device` 为客户端网卡名。
4. 如果关闭 SD 或需要静态远端地址, 把 `services[0].unicast` 改成服务端电脑 IP。
5. 保留或调整 `clients[0].unreliable` 源端口。

网络检查:

```bash
ip -brief addr
ip route
sudo ip route add 224.0.0.0/4 dev <iface>
sudo tcpdump -i <iface> -nn 'udp port 30490 or udp port 30509'
```

## VLAN 迁移

创建 VLAN 子接口:

```bash
sudo ip link add link eno1 name eno1.100 type vlan id 100
sudo ip addr add 192.168.100.10/24 dev eno1.100
sudo ip link set eno1.100 up
```

vSomeIP JSON:

```json
"unicast" : "192.168.100.10",
"device" : "eno1.100",
"netmask" : "255.255.255.0"
```

真实 ECU 场景下, VLAN ID, IP, netmask, SD multicast, service port, client source port 都要以 ECU/ARXML/网络矩阵为准。

## 常见问题

- 能通信但抓不到 request/response: 大概率还在走本机 routing/IPC, 用 namespace/veth 或两台电脑验证。
- SD 抓得到但 method 不通: 检查 `services` 的 unreliable/reliable port, client 源端口, 防火墙和服务 ID/实例 ID。
- 绑定网卡失败: `device` 会触发 `SO_BINDTODEVICE`, 调试阶段直接 root 跑; 产品化再考虑 capabilities。
- 真实 ECU 不响应: 先用 Wireshark 确认 FindService/OfferService 是否匹配, 再查 method ID, interface version, payload, E2E, SOME/IP-TP, 安全策略。
