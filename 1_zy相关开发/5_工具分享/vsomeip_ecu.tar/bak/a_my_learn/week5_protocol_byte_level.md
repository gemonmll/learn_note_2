# 第 5 周：协议字节级 - 外部 SOME/IP 与内部 vsomeip IPC

这一周的目标不是“背几个字段名”，而是把下面这句话真正看懂：

`本地 app <-> routing manager` 之间说的是 `VSOMEIP_*` 内部命令，
`设备 <-> 设备` 之间说的是外部 `SOME/IP` 报文。

如果你能把这两套协议从头部、长度字段、字节序、使用场景上彻底分开，第 5 周就算学到位了。

## 本周目标

学完这一周，你应该能清楚回答：

1. `message_header_impl.cpp` 处理的到底是哪一套头？
2. 为什么 `VSOMEIP_SOMEIP_HEADER_SIZE = 8`，但完整 SOME/IP 头又是 16 字节？
3. SOME/IP 的 `length` 字段到底表示什么？
4. `vsomeipProtocol.md` 里的 `0x10 / 0x18 / 0x19` 是什么含义？
5. 为什么 `ASSIGN_CLIENT` 单测里 `0x0042` 会被写成 `42 00`？
6. 为什么 `NOTIFY_ID (0x19)` 不是 SOME/IP 的 `message_type`？

## 一张图先建立模型

```text
本地应用
    |
    |  VSOMEIP_ASSIGN_CLIENT / VSOMEIP_SEND / VSOMEIP_NOTIFY ...
    v
routing manager / local endpoint
    |
    |  SOME/IP request / response / notification
    v
远端 ECU
```

先记住：

- `VSOMEIP_*` 命令是本地 IPC 协议
- `SOME/IP` 头是网络消息格式
- 有些内部命令的 payload 里，会再包一整段外部 SOME/IP 报文

这就是很多新手一开始会觉得“看起来长得像，但又不完全一样”的根本原因。

## 第一部分：外部 SOME/IP 头

### 1. 入口文件

建议先看这几个文件：

- `implementation/message/src/message_header_impl.cpp`
- `implementation/message/src/message_impl.cpp`
- `implementation/message/src/serializer.cpp`
- `implementation/message/src/deserializer.cpp`
- `interface/vsomeip/defines.hpp`

### 2. `message_header_impl` 序列化了什么

在 `implementation/message/src/message_header_impl.cpp:24-28` 里，外部 SOME/IP 头按下面顺序写入：

```text
service(2)
method(2)
length(4)
client(2)
session(2)
protocol_version(1)
interface_version(1)
message_type(1)
return_code(1)
```

总计正好 16 字节。

这正是我们平时说的“完整 SOME/IP 头”。

对应字段声明在：

- `implementation/message/include/message_header_impl.hpp:30-38`

### 3. 为什么代码里既有 8 字节头，又有 16 字节头

`interface/vsomeip/defines.hpp` 里有两个非常关键的常量：

- `VSOMEIP_SOMEIP_HEADER_SIZE = 8`
- `VSOMEIP_FULL_HEADER_SIZE = 16`

这两个都对，只是站的角度不同。

#### `VSOMEIP_SOMEIP_HEADER_SIZE = 8`

它对应前 8 字节：

```text
service(2) + method(2) + length(4)
```

很多地方只需要先拿到前 8 字节，就已经可以知道“这包消息完整长度应该是多少”。

#### `VSOMEIP_FULL_HEADER_SIZE = 16`

它对应完整头：

```text
service(2) + method(2) + length(4)
+ client(2) + session(2) + protocol(1) + interface(1) + type(1) + code(1)
```

所以你可以把它记成：

- 8 字节: 足够知道“包有多长”
- 16 字节: 完整 SOME/IP 头

### 4. SOME/IP 的 `length` 到底怎么算

这一点必须看源码，不然很容易混。

在 `implementation/message/src/message_header_impl.cpp:25` 里，序列化写入的不是 `header_.length_`，而是：

```cpp
owner_->get_length()
```

也就是说：

- 发包时，`length` 是动态从消息对象算出来的
- 它不是随便拿某个缓存字段原样发出去

而 `implementation/message/src/message_impl.cpp:20-22` 里：

```cpp
length_t message_impl::get_length() const {
    return (VSOMEIP_SOMEIP_HEADER_SIZE + (payload_ ? payload_->get_length() : 0));
}
```

这说明外部 SOME/IP 的 `length` 字段表示的是：

```text
后 8 字节头 + payload 长度
```

不是整包总长。

### 5. 用一个例子把 `length` 算明白

假设：

- payload 长度 = 3 字节

那么：

- `length = 8 + 3 = 11 = 0x0000000B`
- 外部 SOME/IP 整包长度 = `16 + 3 = 19`

也就是说：

```text
length 字段 = 11
实际抓包看到的总字节数 = 19
```

这正是 SOME/IP 里最容易算错的地方之一。

### 6. 外部 SOME/IP 的字节序

看这两处：

- `implementation/message/src/serializer.cpp:28-46`
- `implementation/message/src/deserializer.cpp:51-83`

可以确认：

- 16 位、32 位字段最终都按大端顺序写到缓冲区
- 反序列化时也按大端读取

所以外部 SOME/IP 这条线，你可以直接记成：

`网络线上的 SOME/IP -> 大端网络序`

### 7. 一个值得单独记住的小点

`message_header_impl::deserialize(...)` 会把报文里的 `length` 读到 `header_.length_`；
然后 `message_impl::deserialize(...)` 在
`implementation/message/src/message_impl.cpp:40`
里用：

```cpp
payload_->set_capacity(header_.length_ - VSOMEIP_SOMEIP_HEADER_SIZE);
```

这再次说明：

- 报文里的 `length` 包含后 8 字节头
- 真正 payload 长度要再减去 `8`

## 第二部分：内部 vsomeip IPC 命令

### 1. 入口文件

这部分建议看：

- `implementation/protocol/include/protocol.hpp`
- `implementation/protocol/include/command.hpp`
- `implementation/protocol/src/command.cpp`
- `documentation/vsomeipProtocol.md`

### 2. 内部命令公共头长什么样

`implementation/protocol/include/protocol.hpp:99-107` 定义了：

- `COMMAND_HEADER_SIZE = 9`
- `COMMAND_POSITION_ID = 0`
- `COMMAND_POSITION_VERSION = 1`
- `COMMAND_POSITION_CLIENT = 3`
- `COMMAND_POSITION_SIZE = 5`
- `COMMAND_POSITION_PAYLOAD = 9`

所以内部 IPC 公共头固定就是：

```text
command_id(1)
version(2)
client(2)
size(4)
```

总计 9 字节。

### 3. 这些命令号是什么

`implementation/protocol/include/protocol.hpp:17-56` 定义了所有内部命令号，例如：

- `ASSIGN_CLIENT_ID = 0x00`
- `OFFER_SERVICE_ID = 0x10`
- `SUBSCRIBE_ID = 0x12`
- `SEND_ID = 0x18`
- `NOTIFY_ID = 0x19`
- `NOTIFY_ONE_ID = 0x1A`

`documentation/vsomeipProtocol.md` 则给出了这些命令对应的本地协议格式说明。

请一定记住：

`vsomeipProtocol.md` 讲的是内部 IPC 协议，不是外部 SOME/IP 报文头。

### 4. 内部 IPC 的 `size` 字段怎么算

`implementation/protocol/src/command.cpp:13-22` 负责写公共头。

具体每条命令在自己的 `serialize(...)` 里先算总长度，再设置：

```cpp
size_ = its_size - COMMAND_HEADER_SIZE;
```

因此：

- 内部 IPC 的 `size`
- 表示的是“9 字节公共头之后的 payload 大小”

这和外部 SOME/IP 的 `length` 语义不一样。

要把它们分开记：

- SOME/IP `length` = 后 8 字节头 + payload
- IPC `size` = 9 字节命令头之后的 payload

### 5. 内部 IPC 的字节序

看：

- `implementation/protocol/src/command.cpp:18-21`
- `implementation/protocol/src/assign_client_command.cpp:38-53`
- `test/unit_tests/protocol_tests/ut_assign_client_command.cpp:15-29`

能看到一个非常重要的事实：

- 这里大量字段直接 `memcpy` 到缓冲区
- 单测明确按 little-endian 来校验

例如在 `ut_assign_client_command.cpp` 里：

- client `0x0042` 被序列化成 `42 00`
- version `IPC_VERSION = 3` 被序列化成 `03 00`
- port `31492 = 0x7B04` 被序列化成 `04 7B`

所以当前实现这套内部 IPC，你可以先按下面记：

`本地 vsomeip IPC -> 当前实现/单测体现为 little-endian`

## 第三部分：用 `ASSIGN_CLIENT` 读懂一条内部命令

### 1. 先看单测给出的完整字节

`test/unit_tests/protocol_tests/ut_assign_client_command.cpp:17-29`

```text
00
03 00
42 00
11 00 00 00
06 00 00 00
6d 79 5f 61 70 70
01
7f 00 00 02
04 7b
```

把它按字段拆开就是：

```text
00                -> ASSIGN_CLIENT_ID
03 00             -> IPC_VERSION = 3
42 00             -> client = 0x0042
11 00 00 00       -> size = 17
06 00 00 00       -> name_length = 6
6d 79 5f 61 70 70 -> "my_app"
01                -> has_address = true
7f 00 00 02       -> 127.0.0.2
04 7b             -> port = 31492
```

### 2. 注意文档和实现的差异

`documentation/vsomeipProtocol.md:43-51` 用比较简化的方式写成：

```text
Name
[Address]
[Port]
```

而真实实现 `implementation/protocol/src/assign_client_command.cpp:20-54` 里实际上还有：

- `name_length (4 字节)`
- `has_address (1 字节)`

所以当文档和实现看起来略有差异时：

- 文档用来建立宏观认识
- 实现和单测才是读字节级细节时的最终依据

### 3. 这条命令到底是干什么的

`ASSIGN_CLIENT` 是本地 app 和 routing manager 建立本地通信关系时的内部命令。

它的语义不是“给远端 ECU 发一个 SOME/IP request”，而是：

`我要在本机 routing 体系里申请/声明一个 client 身份`

所以：

- 它是本地 IPC
- 它不是外部 SOME/IP
- 抓网络包通常看不到它

## 第四部分：`SEND / NOTIFY / NOTIFY_ONE` 为什么更容易混

### 1. 因为它们是“内部命令”，但里面又装着“外部 SOME/IP 消息”

先看协议文档：

- `documentation/vsomeipProtocol.md:232-246`

再看实现：

- `implementation/protocol/include/send_command.hpp`
- `implementation/protocol/src/send_command.cpp`

`send_command` 的 payload 布局实际上是：

```text
instance(2)
reliable(1)
status(1)
target(2)
message(...)
```

也就是说：

```text
内部命令头(9)
+ instance/reliable/status/target
+ 一整段 SOME/IP message 字节
```

### 2. routing stub 怎么处理它

看：

- `implementation/routing/src/routing_manager_stub.cpp:389-457`

这里非常关键。

stub 在收到 `SEND_ID / NOTIFY_ID / NOTIFY_ONE_ID` 后，会：

1. 先按内部 IPC 命令去反序列化 `send_command`
2. 再从 `command.get_message()` 里拿出“被包进去的 SOME/IP 报文”
3. 再按 SOME/IP 的字段位置读取 `service / method / client / length`
4. 最后交给 `host_->on_message(...)` 或 `host_->on_notification(...)`

这意味着：

- 外层是内部 IPC 命令
- 内层是外部 SOME/IP 字节流

这就是两套协议在运行时真正“套在一起”的地方。

### 3. 为什么 `NOTIFY_ID (0x19)` 不是 SOME/IP 的 `message_type`

因为：

- `0x19` 这里是内部命令号，定义在 `protocol.hpp`
- SOME/IP 的 `message_type` 在外部头第 15 个字节位置，定义在 message header 里

它们属于两套完全不同的命名空间。

所以：

- 看到 `0x19`，先问自己“这里是不是在解析内部 IPC 命令头”
- 看到 `message_type` 字段，再去想 request/response/notification/error 这些外部 SOME/IP 语义

## 第五部分：把两套协议正面对比一次

| 维度 | 外部 SOME/IP | 内部 vsomeip IPC |
| --- | --- | --- |
| 用途 | 设备间网络通信 | 本地 app 与 routing manager 通信 |
| 典型入口 | `message_header_impl.cpp` | `command.cpp` / `vsomeipProtocol.md` |
| 固定头长度 | 16 字节完整头 | 9 字节公共头 |
| 常见“先读长度”的最小前缀 | 8 字节 | 9 字节 |
| 长度字段名 | `length` | `size` |
| 长度字段语义 | 后 8 字节头 + payload | 9 字节命令头后的 payload |
| 字节序 | 大端网络序 | 当前实现/单测体现为 little-endian |
| 首字段 | `service` | `command_id` |
| 是否直接上网络 | 是 | 否，主要是本地 IPC |
| 典型例子 | request / response / notification | `ASSIGN_CLIENT` / `OFFER_SERVICE` / `SEND` / `NOTIFY` |

## 第六部分：建议阅读顺序

### 第 1 步：先把外部 SOME/IP 头吃透

按这个顺序读：

1. `implementation/message/include/message_header_impl.hpp`
2. `implementation/message/src/message_header_impl.cpp`
3. `interface/vsomeip/defines.hpp`
4. `implementation/message/src/message_impl.cpp`
5. `implementation/message/src/serializer.cpp`
6. `implementation/message/src/deserializer.cpp`

这一轮读完，你至少要能回答：

- 16 字节头分别是什么
- `length` 为什么不是整包总长
- 代码里为什么还会频繁出现 `8`

### 第 2 步：再把内部 IPC 公共头吃透

按这个顺序读：

1. `implementation/protocol/include/protocol.hpp`
2. `implementation/protocol/include/command.hpp`
3. `implementation/protocol/src/command.cpp`
4. `documentation/vsomeipProtocol.md`

这一轮读完，你至少要能回答：

- `COMMAND_HEADER_SIZE` 为什么是 9
- `command_id / version / client / size` 分别在什么位置
- `size` 为什么和 SOME/IP 的 `length` 不是一个意思

### 第 3 步：拿 `ASSIGN_CLIENT` 做第一条字节级拆包练习

按这个顺序读：

1. `implementation/protocol/src/assign_client_command.cpp`
2. `test/unit_tests/protocol_tests/ut_assign_client_command.cpp`

这一轮读完，你至少要能自己把单测中的 26 个字节逐段标出来。

### 第 4 步：最后再读 `SEND / NOTIFY / NOTIFY_ONE`

按这个顺序读：

1. `implementation/protocol/include/send_command.hpp`
2. `implementation/protocol/src/send_command.cpp`
3. `implementation/routing/src/routing_manager_stub.cpp`

这一轮读完，你应该能彻底理解：

`内部命令 payload 里可以再塞一整段外部 SOME/IP message`

## 第七部分：本周最容易混淆的 8 个点

1. `vsomeipProtocol.md` 不是 SOME/IP 规范文档，而是 vSomeIP 内部 IPC 协议文档。
2. `NOTIFY_ID (0x19)` 不是 SOME/IP `message_type`。
3. `ASSIGN_CLIENT` 这种命令一般不会出现在网络抓包里。
4. `VSOMEIP_SOMEIP_HEADER_SIZE = 8` 不代表 SOME/IP 头只有 8 字节。
5. `VSOMEIP_FULL_HEADER_SIZE = 16` 才是完整 SOME/IP 头。
6. SOME/IP `length` 不是整包总字节数。
7. 内部 IPC `size` 也不是整包总字节数。
8. 内部 `SEND / NOTIFY` 经常会让你误以为“我已经在看 SOME/IP 头了”，其实你可能还在看外层 IPC 命令。

## 第八部分：本周自测题

下面这些问题建议你自己先写答案，再回头对源码。

### 基础题

1. `message_header_impl.cpp` 序列化出来的 16 字节里，前 8 字节和后 8 字节分别是什么？

2. 为什么 `message_impl::get_length()` 返回的是 `8 + payload_len`，而不是 `16 + payload_len`？

3. `VSOMEIP_SOMEIP_HEADER_SIZE` 和 `VSOMEIP_FULL_HEADER_SIZE` 为什么可以同时成立？

4. 外部 SOME/IP 和内部 IPC 哪一套是大端，哪一套在当前实现里体现为小端？

5. `vsomeipProtocol.md` 里的 `OFFER_SERVICE (0x10)` 为什么不是 SOME/IP 的 `message_type`？

### 进阶题

6. `ASSIGN_CLIENT` 单测里为什么会出现 `06 00 00 00` 这一段？它不是客户端 ID，也不是 size，它到底是什么？

7. `ASSIGN_CLIENT` 单测里 `04 7b` 为什么能表示端口 `31492`？

8. `SEND_ID / NOTIFY_ID / NOTIFY_ONE_ID` 为什么特别容易让人把内部 IPC 和外部 SOME/IP 混在一起？

9. `routing_manager_stub.cpp` 在处理 `SEND_ID` 时，为什么还要再次从 `message_data` 里读取 `service / method / client / length`？

10. 如果你抓到一段字节流，开头是：

```text
00 03 00 42 00 11 00 00 00 ...
```

你应该先把它当成哪套协议解析？为什么？

### 挑战题

11. 假设外部 SOME/IP payload 长度是 `0x0010`，那么：

- `length` 字段应该写多少？
- 整个 SOME/IP 报文总长度是多少？

12. 假设某条内部命令 payload 长 25 字节，那么它公共头里的 `size` 应该写多少？整条 IPC 命令总长度又是多少？

13. 如果你在 `NOTIFY_ID` 的内部 message 区里看到 `service / method / length / client / session ...`，请解释这说明了什么。

## 第九部分：做题时建议写出的答题要点

如果你想检查自己是不是真的理解了，可以要求自己在答案里至少出现这些关键词：

- “外部 SOME/IP”
- “内部 IPC”
- “大端”
- “小端”
- “16 字节完整头”
- “8 字节前缀”
- “length = 后 8 字节头 + payload”
- “size = 9 字节命令头之后的 payload”
- “内部命令里可嵌套 SOME/IP message”

## 第十部分：这一周结束时，你应该能自然说出这段话

“`message_header_impl.cpp` 处理的是外部 SOME/IP 头，不是内部 IPC 命令头。外部 SOME/IP 完整头是 16 字节，但代码里经常先用前 8 字节读取 `length` 来判断整包大小；这个 `length` 表示的是后 8 字节头加 payload，而不是整包总长。`vsomeipProtocol.md` 讲的是本地 app 和 routing manager 之间的内部 IPC 命令，公共头是 9 字节，包含 `command_id / version / client / size`。这套内部协议在当前实现和单测里体现为 little-endian。像 `SEND / NOTIFY / NOTIFY_ONE` 这种内部命令，其 payload 里还可能再包一整段外部 SOME/IP message，所以读源码时必须先分清当前自己站在哪一层协议上。” 

## 本周之后建议继续读

如果你这一周消化顺了，下一步很适合继续追：

- `routing_manager_client.cpp`
- `routing_manager_stub.cpp`
- `local_server.cpp`
- `local_endpoint.cpp`

重点继续追两条链：

1. 本地 app 是怎么把内部 IPC 命令发给 routing manager 的
2. routing manager 又是怎么把内部命令解开，再变成外部 SOME/IP 报文或本地分发动作的
