# 第 6 周：测试框架与抓包心智模型

这一周先不急着继续往 `routing`、`endpoints`、`security`、`e2e` 这些实现深处扎。

更重要的是先建立一个“我现在看到的现象，是在哪种测试环境里发生的”心智模型。

因为到了 vSomeIP 这一步，最容易迷路的原因通常不是源码太难，而是下面这些东西混在一起了：

- 你以为自己在看“真实网络”
- 实际上你在看 fake socket 的进程内仿真
- 你以为自己在看“两个 ECU”
- 实际上你在看“同一进程里模拟的两个 ECU”
- 你以为 Wireshark 抓到的是外部 SOME/IP
- 实际上抓到的是 app 和 routing manager 之间的内部 TCP 命令

所以第 6 周的核心不是学一个 API，而是建立三层视角：

1. fake socket 两 ECU 心智模型
2. 多进程 common test framework 心智模型
3. 内部 TCP 抓包与协议观察心智模型

只有这三层稳了，后面你再回头看 `routing`、`endpoints`、`security`、`e2e`，就不会一直问“这个行为到底发生在哪一层”。

## 本周目标

学完这一周，你应该能回答：

1. `fake_socket_tests` 和普通多进程 `network_tests` 有什么根本差别？
2. fake socket 里的“两 ECU”到底是真两个进程、真两个网卡，还是测试内模拟？
3. `ecu_setup`、`socket_manager`、`app` 分别扮演什么角色？
4. `test/common` 里的 manager、child、shared memory、scenario 是怎么配合的？
5. 什么时候该抓“内部 TCP”，什么时候根本抓不到？
6. 为什么理解测试框架之后，再回头看 `routing` 和 `endpoints` 会轻松很多？

## 第一部分：先把两类测试生态分开

这一周首先要把仓库里的两类测试分清：

### 1. `fake_socket_tests`

入口：

- `test/network_tests/fake_socket_tests/README.md`

特点：

- 所有 vsomeip app 都运行在同一个测试进程里
- 没有真实 OS 网络 I/O
- socket 被 fake/intercept
- 更像“路由、服务发现、重连、时序”的可控实验室

这类测试的目的不是证明“真实网卡能通”，而是：

- 低成本、可重复地验证协议时序
- 精准注入错误
- 在非常细粒度上观察 internal command 和连接行为

### 2. `test/common` 支撑的多进程测试

入口：

- `test/common/README.md`

特点：

- 真正拉起多个进程
- manager 进程负责编排
- child/service/client 进程按 scenario 协同步调
- 用共享内存做 barrier 和消息通道

这类测试更像：

- “系统级场景排演”
- “多个独立应用按顺序参与一段复杂流程”

### 3. 一句话区分

你可以先这样粗记：

- `fake_socket_tests` = 进程内、假 socket、强控制、强可观测
- `test/common + network_tests` = 多进程、真实进程生命周期、场景编排

## 第二部分：fake socket 的两 ECU 心智模型

### 1. 这不是真两台机器

`test/network_tests/fake_socket_tests/README.md` 一开头就点明了：

- 这些测试在一个进程里运行
- 用 fake socket 代替真实网络 I/O
- 目标是 deterministic、fast、unit-level

所以第一个必须牢牢记住的结论是：

`fake_socket_tests` 里的“两 ECU”是测试模型，不是真硬件环境。

它模拟的是：

- ECU A 上有 routing manager 和一些 app
- ECU B 上也有 routing manager 和一些 app
- 它们之间存在 boardnet 通信

但这整套东西都被 `socket_manager` 在进程内接管了。

### 2. 两 ECU 模型最该怎么想

建议你脑中先放这个图：

```text
ECU one
  router_one
  local app / guest app
        |
        |  fake local TCP / fake UDS
        |
     socket_manager
        |
        |  fake boardnet TCP / UDP
        |
ECU two
  router_two
  local app / guest app
```

关键不是“它有没有真网卡”，而是：

- 每个 ECU 仍然保留了“本地 routing”这层结构
- 每个 ECU 仍然保留了“boardnet 对外通信”这层结构
- 只是承载这些连接的 socket 都被 fake 掉了

### 3. `socket_manager` 是这套模型的核心

看：

- `test/network_tests/fake_socket_tests/helpers/socket_manager.hpp`

这个类的职责在注释里写得很直白：

1. 把 fake socket / acceptor 和 app 名字关联起来
2. 跟踪连接
3. 提供错误注入 API

你可以把它理解成：

`测试世界里的“总交换机 + 总监控台 + 故障注入器”`

它不仅知道谁和谁连上了，还能做很多真实网络里很难稳定复现的事情，例如：

- 等待某个 app 进入可连接状态
- 等待某条连接建立
- 断开某一侧连接
- 忽略连接
- 延迟消息处理
- 延迟 boardnet 发送
- 记录收到的内部命令
- 等待某个 `VSOMEIP_*` 命令出现

这也是 fake socket 测试特别适合学 `routing` 和 `endpoints` 的原因：

- 你能看到“连接何时建立”
- 你能控制“命令何时丢”
- 你能等待“某条 internal command 是否真的发出”

### 4. `base_fake_socket_fixture` 是统一测试底座

看：

- `test/network_tests/fake_socket_tests/helpers/base_fake_socket_fixture.hpp`

这个 fixture 做的事可以粗略记成：

- 把 fake socket factory 注入到待启动的 vsomeip app
- 为每个测试提供新的 `socket_manager`
- 提供一整套等待/断连/延迟/注入命令的 helper

所以当你看到：

```cpp
struct my_test : public base_fake_socket_fixture
```

脑中应该自动翻译成：

`这是一个建立在 fake 网络世界之上的测试。`

### 5. `ecu_setup` 代表“一台 ECU 的装配与生命周期”

看：

- `test/network_tests/fake_socket_tests/helpers/ecu_setup.hpp`

这个类型非常重要，因为它把“单个 ECU”这个概念具象化了。

它负责：

1. 准备配置文件
2. 设置每个 app 的 `VSOMEIP_CONFIGURATION_*`
3. 启动 routing manager 和 app
4. 维护 `apps_` 和 `router_`
5. teardown 时按顺序停 app

所以：

- `socket_manager` 管的是“测试世界里的连接和注入”
- `ecu_setup` 管的是“某一台 ECU 的配置和生命周期”

### 6. `app` 是单个 vsomeip 应用的测试包装

看：

- `test/network_tests/fake_socket_tests/helpers/app.hpp`

这个 wrapper 最有价值的地方不是“帮你少写几行代码”，而是它把测试视角统一了：

- offer / request / subscribe / send_request / send_event
- 自动记录 state、message、availability、subscription
- 让测试用例可以直接等待某个状态

所以你在 fake socket 测试里读到：

- `availability_record_`
- `subscription_record_`
- `message_record_`

不要把它只当日志工具，它们其实是“测试断言接口”的一部分。

### 7. 看一眼真实用法

最推荐的现成例子：

- `test/network_tests/fake_socket_tests/test_boardnet.cpp`

尤其是：

- `guest_offering` 这个 fixture
- `guests_provide_and_consume_interface` 这个测试

这段代码非常适合作为“两 ECU 心智模型”的最小闭环：

1. 构造两个 `ecu_setup`
2. 每个 ECU 添加 guest app
3. `prepare()`
4. `start_apps()`
5. 一个 guest offer 服务
6. 另一个 guest subscribe
7. 等 availability / subscription 成功

如果你能把这 7 步复述清楚，fake socket 两 ECU 的基本心智模型就稳了。

### 8. `sample_configurations.hpp` 和 `sample_interfaces.hpp` 是地形图

看：

- `test/network_tests/fake_socket_tests/sample_configurations.hpp`
- `test/network_tests/fake_socket_tests/sample_interfaces.hpp`

这两个文件的作用很像“测试地形图”：

- 哪个 ECU 用什么 IP
- 哪个 router 叫什么
- 哪个 service 在 boardnet 上 offer
- local transport 是 TCP 还是 UDS
- guest/host 怎么分

尤其 `sample_configurations.hpp` 里这几组配置很值得你记：

- `local::uds_config`
- `local::tcp_config`
- `boardnet::ecu_one_config`
- `boardnet::ecu_two_config`
- `hybrid::*`

它们基本覆盖了你后面读测试时最常见的拓扑。

## 第三部分：fake socket 测试到底适合学什么

### 1. 适合学协议时序

例如：

- 注册时先发哪些 internal command
- `ASSIGN_CLIENT / CONFIG / ROUTING_INFO / SUBSCRIBE_ACK` 顺序如何
- 重连后消息顺序是否稳定

这方面最适合看的例子是：

- `test/network_tests/fake_socket_tests/test_protocol_messages.cpp`

这个文件非常宝贵，因为它不是只验证“结果对不对”，而是直接验证：

- 某条连接上发了哪些 `protocol::id_e`
- 顺序是不是预期的顺序

它几乎是“第 5 周内部 IPC 协议”与“第 6 周测试视角”之间的桥。

### 2. 适合学故障注入

比如：

- 丢一次 `ASSIGN_CLIENT`
- 延迟 boardnet 发送
- 忽略 connect
- 主动断开连接

这类问题如果放到真实网络环境里，通常很难稳定复现；
但 fake socket 世界里，`socket_manager` 可以精确控制。

### 3. 适合学“现象如何映射到 routing/endpoints”

例如：

- “为什么 client 注册不上？”
- “为什么 router 接受连接了但没有 ACK？”
- “为什么 subscribe 发出去了却没收到 ACK？”
- “为什么断线恢复后第一条消息丢了？”

fake socket 测试不是最终生产环境，但它特别适合把这类问题先压缩成可控现象。

### 4. 不适合直接回答哪些问题

也要注意它的边界：

- 它不是实际网卡行为
- 它不是 kernel socket 真实时序
- 它不等于真实跨主机网络抖动
- 它默认不会产生你能直接用系统抓包工具抓到的真实包

一句话：

`fake_socket_tests` 适合学“协议和组件行为”，不适合把它误当成真实线上的最终网络证据。

## 第四部分：多进程 common framework 的心智模型

### 1. 先理解它解决的问题

看：

- `test/common/README.md`

这套框架解决的不是 fake socket 那种“进程内模拟”问题，而是：

`如何把多个独立测试进程按同一个剧本编排起来`

所以你可以把它想成：

- manager 是导演
- child/service/client 是演员
- shared memory 是场记板和同步器
- scenario 是剧本

### 2. 目录结构怎么读

`test/common/README.md` 里给了一个标准 FEATURE 目录结构：

- `*_test.md`
- `*_manager.cpp`
- `*_client.cpp`
- `*_service.cpp`
- `conf/`
- `docs/`

读这种测试时，建议顺序永远是：

1. 先看 `*_test.md`
2. 再看 `*_manager.cpp`
3. 再看 `*_common.hpp`
4. 最后看各个 child/service/client 的 scenario

不要一上来就钻进具体 app 代码，不然很容易不知道自己现在位于哪一幕。

### 3. `shared_memory_master_t / slave_t`

看：

- `test/common/include/common/interprocess.hpp`

这部分的关键认知是：

- manager 创建 shared memory master
- child 连接 shared memory slave
- 共享内存里既有 barrier，也有 per-process queue

所以它不只是“共享一个变量”，而是：

- 能做同步
- 能做消息传递

### 4. `barrier`

它的作用非常简单但非常关键：

`所有参与者都走到某一步了，大家才能继续`

这解决的是多进程测试里最烦的非确定性问题：

- 有人先跑太快
- 有人还没准备好
- manager 已经断言了，service 还没进入那一步

### 5. `bounded_channel`

它的作用更像：

`子进程把状态或结果回报给 manager`

这时 manager 就能做断言，例如：

- service 已初始化
- client 已发送请求
- 某步失败

### 6. `process_group_t`

看：

- `test/common/include/common/process.hpp`

它是“多进程拉起与回收”的统一壳。

它负责：

- 定义 process type
- 给每个类型配置 executable 和环境变量
- add_process / add_daemon
- start / stop / force_stop

所以：

- `fake_socket_tests` 里你经常和 `app`、`ecu_setup` 打交道
- `test/common` 里你经常和 `process_group_t`、manager/child 打交道

### 7. `test_scenario_t`

看：

- `test/common/include/common/scenario.hpp`

这是“剧本执行器”。

它把一段测试场景拆成多个有序 step，每个 step 执行后做 barrier 同步。

非常值得记住的一点是：

`scenario 不是一个自动推导出的全局真相，而是每个进程都要自己写一份与自己角色匹配的脚本。`

这就是为什么 `test/common/README.md` 专门提醒：

- scenario 是 per-process specific 的

### 8. 这套框架适合学什么

它特别适合：

- 多进程启动顺序
- manager/child 协作
- 复杂场景编排
- inter-ECU 容器化场景

如果 fake socket 更像“协议实验室”，
那 common framework 更像“舞台调度系统”。

## 第五部分：Wireshark plugin 到底是抓什么的

### 1. README 先告诉了你答案

看：

- `tools/wireshark_plugin/README.md`

第一句话就很关键：

`Wireshark dissector for vSomeip internal communication via TCP`

这说明它抓的是：

- vSomeIP 内部通信
- 经由 TCP

不是笼统地“所有 SOME/IP 报文”。

### 2. 它最适合看什么

结合第 5 周内容，这个 dissector 最适合看：

- `ASSIGN_CLIENT`
- `ASSIGN_CLIENT_ACK`
- `OFFER_SERVICE`
- `SUBSCRIBE`
- `SUBSCRIBE_ACK / NACK`
- `SEND`
- `NOTIFY`
- `NOTIFY_ONE`

因为这些正是内部命令。

从 `tools/wireshark_plugin/vsomeip-dissector.lua` 里也能看到：

- 它直接为这些命令号注册了解析 handler
- 对 `SEND / NOTIFY / NOTIFY_ONE` 还会继续按标准 SOME/IP 去解析内嵌 message

这点非常重要：

`它抓的是内部命令，但内部命令里又可能包着外部 SOME/IP message。`

### 3. 什么时候该用它

最适合的场景通常是：

- 你开启了 local TCP 模式
- app 和 routing manager 之间通过 TCP 通信
- 你想确认内部命令到底有没有发、顺序如何、参数是什么

比如你怀疑：

- app 根本没发 `ASSIGN_CLIENT`
- `SUBSCRIBE` 发了但 router 没回 ACK
- `NOTIFY_ONE` 在本地根本没走出去

这时抓内部 TCP 比只看日志更直接。

### 4. 什么时候不该指望它

下面这些场景要特别小心：

- fake socket tests
  因为没有真实 OS 网络 I/O，通常不能靠系统抓包看到真实 TCP 流
- UDS 本地通信
  这个 README 说的是 internal communication via TCP，不是 UDS 抓包万能钥匙
- 只想看 ECU 间外部 SOME/IP
  这时更应该看网络上的 SOME/IP 报文，而不是内部命令 dissector

一句话：

`这个 plugin 主要帮你看 app <-> router 的内部 TCP，不是所有层面都该用它。`

### 5. fake socket 与 Wireshark 的关系

这一点值得你单独记下来：

- fake socket 测试非常适合“观察 internal command”
- 但这种观察通常靠 `socket_manager` / `command_record`
- 不是靠 Wireshark

也就是说：

- 在 fake socket 世界，你更像在“读测试内部记录”
- 在真实 local TCP 世界，你才更像在“抓实际 TCP 流”

## 第六部分：第 6 周之后，怎么回头看 routing / endpoints / security / e2e

这一周学完后，再回头看源码，不要再按“模块名”硬啃，而要按“现象 -> 所属层”回去找。

### 1. 注册/连接问题

优先回看：

- `local_server.*`
- `local_endpoint.*`
- `routing_manager_client.*`
- `protocol/*assign_client*`

典型问题：

- client 为什么没拿到 client id
- router 为什么没 ACK
- local TCP / UDS 为什么没连上

### 2. service offer / request / availability 问题

优先回看：

- `routing_manager_impl.*`
- `routing_manager_stub.*`
- `service_discovery_impl.*`

典型问题：

- request_service 发出后 availability 为什么没起来
- SD 到底有没有发 offer/find

### 3. event / field / subscription 问题

优先回看：

- `event.cpp`
- `eventgroupinfo.cpp`
- `routing_manager_impl.*`
- `routing_manager_stub.*`

典型问题：

- subscribe 为何没 ACK
- field 初始值为何没补
- selective event 为何没定向到目标 client

### 4. policy / permission 问题

优先回看：

- `implementation/security/*`
- `CONFIG_ID` 相关路径
- 测试里涉及 security policy 更新的命令

典型问题：

- 为什么服务存在但访问被拒
- 为什么某个 request 被 policy 拦掉

### 5. E2E / CRC / status 问题

优先回看：

- `implementation/e2e_protection/*`
- 内部 `SEND / NOTIFY` 里的 status/CRC 传递路径

典型问题：

- 为什么消息到了但校验失败
- 为什么 status 字段不对

这时你就会发现：

理解测试框架的真正价值，不是会写测试，而是知道“哪个现象应该回到哪一层去查”。

## 第七部分：本周推荐阅读顺序

建议按这个顺序读：

1. `test/network_tests/fake_socket_tests/README.md`
2. `test/network_tests/fake_socket_tests/helpers/base_fake_socket_fixture.hpp`
3. `test/network_tests/fake_socket_tests/helpers/socket_manager.hpp`
4. `test/network_tests/fake_socket_tests/helpers/ecu_setup.hpp`
5. `test/network_tests/fake_socket_tests/helpers/app.hpp`
6. `test/network_tests/fake_socket_tests/sample_configurations.hpp`
7. `test/network_tests/fake_socket_tests/test_boardnet.cpp`
8. `test/network_tests/fake_socket_tests/test_protocol_messages.cpp`
9. `test/common/README.md`
10. `test/common/include/common/interprocess.hpp`
11. `test/common/include/common/process.hpp`
12. `test/common/include/common/scenario.hpp`
13. `tools/wireshark_plugin/README.md`
14. `tools/wireshark_plugin/vsomeip-dissector.lua`

这个顺序的目的不是“全看完”，而是逐步建立三层视角：

- fake ECU 模型
- 多进程 orchestration 模型
- 内部 TCP 观察模型

## 第八部分：本周最该分清的 10 组概念

1. fake socket 测试 vs 真实网络抓包
2. 进程内模拟的两 ECU vs 真两台机器
3. `socket_manager` vs `ecu_setup`
4. `ecu_setup` vs `app`
5. “启动 app” vs “进入 connectable”
6. internal command 记录 vs 外部 SOME/IP 报文
7. common framework 的 manager vs child
8. shared memory barrier vs bounded channel
9. `process_group_t` 的进程生命周期 vs app wrapper 的应用生命周期
10. 内部 TCP dissector vs 外部 SOME/IP dissector

## 第九部分：本周自测题

### 基础题

1. fake socket tests 为什么说是 deterministic、fast、unit-level？

2. `socket_manager` 为什么是 fake socket 世界里的核心？

3. `ecu_setup` 为什么可以被看成“一台 ECU 的装配器”？

4. `app` wrapper 记录 `availability_record_`、`subscription_record_`、`message_record_` 的意义分别是什么？

5. `base_fake_socket_fixture` 为什么不只是普通 GTest fixture？

### 进阶题

6. `test_boardnet.cpp` 里的两个 `ecu_setup` 为什么能表达“两 ECU”的结构，即使所有 app 都运行在测试进程内？

7. `test_protocol_messages.cpp` 为什么是连接第 5 周和第 6 周的关键文件？

8. `shared_memory_master_t` 和 `shared_memory_slave_t` 分别由谁创建、谁连接？

9. `barrier` 和 `bounded_channel` 解决的是同一个问题吗？如果不是，各自解决什么？

10. `test_scenario_t` 为什么说是“剧本执行器”，但又不是全局自动生成的剧本？

### 抓包题

11. 为什么 `vsomeip-dissector` 更适合看 app 和 routing manager 的内部 TCP，而不是笼统地看“所有 SOME/IP”？

12. 为什么在 fake socket tests 中，很多时候你应该优先看 `command_record` / `wait_for_command(...)`，而不是想着开 Wireshark？

13. `SEND / NOTIFY / NOTIFY_ONE` 为什么在 dissector 里特别有价值？

14. 如果你怀疑 `SUBSCRIBE_ACK` 根本没回到 client，本地又是 TCP routing，你会优先看哪层抓包/记录？

### 回看源码题

15. 如果你观察到“client 注册失败”，你应该优先回看哪几个模块？

16. 如果你观察到“availability 没起来”，你为什么应该优先回看 `routing` 和 `SD`，而不是一上来就怀疑 E2E？

17. 如果你观察到“消息到了但被拒”，你为什么会想到 security policy 路径？

18. 如果你观察到“消息到了但状态位/CRC 异常”，你为什么会想到 E2E？

## 第十部分：本周练习建议

### 练习 1：只做结构阅读

请你自己画一张图，把下面这些对象画出来并连线：

- `base_fake_socket_fixture`
- `socket_manager`
- `ecu_setup`
- `router`
- `app`
- boardnet
- guest/local transport

如果你能画出来，第 6 周已经过半。

### 练习 2：手读一个 fake boardnet 测试

推荐：

- `test/network_tests/fake_socket_tests/test_boardnet.cpp`

目标不是把所有测试看完，而是用自己的话复述：

1. 这里有哪些 ECU
2. 每个 ECU 上有哪些 app
3. 哪个 offer 服务
4. 哪个 subscribe
5. 断言是通过什么 recorder 做的

### 练习 3：手读一个 internal command 顺序测试

推荐：

- `test/network_tests/fake_socket_tests/test_protocol_messages.cpp`

重点回答：

1. 它记录的是哪条连接上的命令
2. 为什么同一个现象会分 `client_to_router`、`router_to_client`、`client_to_server` 等方向
3. 为什么这里特别适合验证 `ASSIGN_CLIENT`、`REQUEST_SERVICE`、`SUBSCRIBE_ACK`

### 练习 4：反向判断该用哪种观察手段

请你自己判断下面场景更适合用什么：

1. 想验证 `ASSIGN_CLIENT` 是否真的发出
2. 想验证 fake socket 世界里某条连接是否被断开
3. 想验证多进程场景下 manager 是否等到所有 child 完成某步
4. 想验证真实 local TCP 环境下内部命令顺序

如果你能正确说出：

- `wait_for_command`
- `socket_manager`
- `shared_memory/barrier/scenario`
- `wireshark dissector`

说明第 6 周的框架感已经建立起来了。

## 第十一部分：这一周结束时，你应该能自然说出这段话

“`fake_socket_tests` 不是用真实网卡做网络测试，而是在一个测试进程里用 fake socket 模拟多个 ECU、多个 router 和多个 app，因此它特别适合验证 internal command、连接时序和故障注入。`socket_manager` 是这个世界里的连接总控台，`ecu_setup` 则把一台 ECU 的配置和 app 生命周期封装起来。另一套 `test/common` 框架解决的是多进程场景编排问题，它用 shared memory、barrier、bounded channel、process group 和 scenario 来同步 manager 与 child。Wireshark plugin 主要用于观察 app 与 routing manager 之间的内部 TCP 通信，不是 fake socket 的首选观察手段，也不是所有 SOME/IP 抓包问题的通用答案。理解了这三套心智模型之后，再回头看 routing、endpoints、security 和 e2e，就更容易把现象放回正确的层次里分析。” 

## 第十二部分：第 7 周可以接什么

如果你愿意继续，第 7 周很适合从“测试现象”回到“实现路径”，建议选一条主线深追：

1. 注册与本地连接建立:
   `local_server` / `local_endpoint` / `assign_client`
2. request-service 与 availability:
   `routing_manager_impl` / `routing_manager_stub` / `service_discovery_impl`
3. subscribe 与 notify:
   `event` / `eventgroupinfo` / `routing_manager_impl`
4. security 与 E2E:
   `security` / `e2e_protection` / `SEND/NOTIFY status`

到那时你就不是“按目录看代码”，而是在“按现象回查路径”了。
