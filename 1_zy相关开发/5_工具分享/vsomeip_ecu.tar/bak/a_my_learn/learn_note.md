# vSomeIP 学习笔记

## 通用链接

- CommonAPI / SOME/IP 相关 wiki:
  https://github.com/COVESA/capicxx-core-tools/wiki

## 目录

- 第 5 周: [协议字节级 - 外部 SOME/IP 与内部 vsomeip IPC](week5_protocol_byte_level.md)
  主题: 外部 SOME/IP 头、内部 vsomeip IPC 命令、字节序、长度字段、ASSIGN_CLIENT、SEND/NOTIFY

- 第 6 周: [测试框架与抓包心智模型](week6_tests_and_internal_capture.md)
  主题: fake socket 两 ECU 模型、多进程测试框架、内部 TCP 抓包、回看 routing/endpoints/security/e2e 的阅读顺序

- 第 7 周: [远端 ECU 通信系统搭建路径](week7_remote_ecu_system.md)
  主题: vSomeIP 工程结构、指定网卡抓包、本机双 ECU 模拟、两机通信、VLAN 与真实 ECU 迁移
