# P301 真实 ECU 通信手顺

## 报文信息

已知真实报文中的关键参数：

```text
上位机 IP:      172.20.3.36
远端 ECU IP:   172.20.3.68
VLAN ID:       3
SD 组播:       239.255.3.1:30490/udp
ECU 事件端口:  30567/udp
上位机事件端口:30435/udp
```

本例订阅的服务：

```text
Service ID:    0x77fb
Instance ID:   0x0001
Major/Minor:   1.0
Eventgroup ID: 0x7001
TTL:           10s
```

事件 ID：

```text
0x8001 0x8002 0x8004 0x8005 0x8008 0x8010
0x9003 0x9006 0x9007 0x9009
```

## 网络模型

脚本只保留 `ipvlan` 方案：

```text
真实物理网卡 PHY_IF
  -> 宿主机 VLAN 子接口 faw_eno1.3
      -> namespace p301_upper 内 ipvlan: p301vlan3
          -> 172.20.3.36/24
```

`faw_eno1.3` 只作为 VLAN 3 承载接口，默认不配置业务 IP；业务 IP 配在 namespace 内，避免改宿主机原有 IP。

默认值：

```text
PHY_IF       enx00e04c0a2188
HOST_VLAN_IF faw_eno1.3
HOST_VLAN_MAC aa:bb:cc:dd:ee:23
NS           p301_upper
NS_IF        p301vlan3
VLAN_ID      3
SIM_IP       172.20.3.36
ECU_IP       172.20.3.68
```

如果机器上的真实物理网卡名字不同，启动命令里改 `PHY_IF=...`。

## 编译

```bash
cmake -S . -B build
cmake --build build --target p301-upper-client -j"$(nproc)"
examples/ecu_sim/run_p301_real_netns.sh validate
```

## 建立网络环境

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh setup
```

这个命令会：

```text
1. 创建或复用宿主机 VLAN 子接口 faw_eno1.3
2. 将 faw_eno1.3 的 MAC 设置为真实上位机 MAC aa:bb:cc:dd:ee:23
3. 创建或复用 namespace p301_upper
4. 在 namespace 内创建 ipvlan 接口 p301vlan3
5. 给 p301vlan3 配置 172.20.3.36/24
6. 添加组播路由和到 ECU 的直连路由
```

查看状态：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh status
```

也可以使用等价的环境命令名：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh setup-env
```

## Ping ECU

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh ping
```

如果 ping 不通，先确认：

```bash
ip -brief link show faw_eno1.3
sudo ip -n p301_upper -brief addr
sudo ip -n p301_upper route
```

再抓包确认 ARP/ICMP 是否到达物理线：

```bash
sudo env PHY_IF=enx00e04c0a2188 PCAP_PATH=/tmp/p301-phy.pcap \
  examples/ecu_sim/run_p301_real_netns.sh capture-phy
```

## 启动 SOME/IP 客户端

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh start
```

预期日志：

```text
ON_OFFER_SERVICE: [77fb.0001:1.0]
Service [77fb.0001] is available
Subscribed eventgroup [7001]
SUBSCRIBE ACK: [77fb.0001.7001.ffff]
```

如果 Wireshark 里一直看到 `[StopSubscribe][Subscribe]` 或 ECU 回 `[SubscribeNack]`，优先检查
SubscribeEventgroup entry 里的 service major version。P301 当前要求 `77fb.0001:1.0`：

```text
正常 Subscribe:     77fb 0001 0100 000a ... 7001
异常 Subscribe:     77fb 0001 0000 000a ... 7001
正常 SubscribeAck:  77fb 0001 0100 000a ... 7001
异常 SubscribeNack: 77fb 0001 0000 0000 ... 7001
```

字段拆开看是 `77fb 0001 01 00000a`：`01` 是 major version，`00000a` 是 TTL 10s。
异常包是 `77fb 0001 00 00000a`，major version 为 `0x00`，会被这个 ECU 拒绝。

## Wireshark 抓包

抓 namespace 内接口，能直接看到解 VLAN 后的 SOME/IP/SD：

```bash
sudo -E env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh wireshark
```

抓物理网卡，确认 VLAN 3 tag：

```bash
sudo -E env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh wireshark-phy
```

保存 pcap：

```bash
sudo env PHY_IF=enx00e04c0a2188 PCAP_PATH=/tmp/p301-ns.pcap \
  examples/ecu_sim/run_p301_real_netns.sh capture

sudo env PHY_IF=enx00e04c0a2188 PCAP_PATH=/tmp/p301-phy.pcap \
  examples/ecu_sim/run_p301_real_netns.sh capture-phy
```

常用显示过滤器：

```text
someip || someipsd
(someip || someipsd) && ip.addr == 172.20.3.68
someipsd && ip.addr == 239.255.3.1
someip && ip.src == 172.20.3.68 && udp.dstport == 30435
```

## 停止和清理

只停止 SOME/IP 客户端，保留网络环境：

```bash
sudo examples/ecu_sim/run_p301_real_netns.sh stop
```

安全清理本脚本创建的 namespace、`p301vlan3` 和临时文件；如果 `faw_eno1.3` 没有全局 IP，也会一并删除：

```bash
sudo examples/ecu_sim/run_p301_real_netns.sh clean
```

`clean-env` 是同一个动作的别名：

```bash
sudo examples/ecu_sim/run_p301_real_netns.sh clean-env
```

如果 `faw_eno1.3` 已经被手工配置了全局 IP，`clean/clean-env` 会保留它，避免误删宿主机业务配置。

如果你明确要删除物理网卡上的 VLAN 3 子接口，例如当前已有的 `eno1.3`，使用：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh delete-vlan
```

这个命令会先停止 `p301_upper` namespace 内的进程，删除 `p301_upper`，然后删除 `PHY_IF` 上 VLAN ID 等于 `VLAN_ID` 的所有 VLAN 子接口。

如果你明确要删除本机所有 VLAN ID 等于 3 的子接口，不管它挂在哪块物理网卡上，使用：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh delete-vlan-all
```

这个命令会删除类似 `eno1.3`、`faw_eno1.3` 这样的 VLAN 3 子接口。如果这些接口上有 `172.20.3.100/24` 这种宿主机 IP，删除后这个 IP 会消失。

如果你想“一键删除旧 VLAN3，并重新创建默认环境 faw_eno1.3 + p301_upper/p301vlan3”，使用：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh reset-env
```

`reset-env` 的效果相当于：

```text
delete-vlan
setup
```

## 注意

同一块物理网卡上同一个 VLAN ID 通常只能有一个 VLAN 子接口。如果已经存在别的 VLAN 3 子接口，创建 `faw_eno1.3` 可能失败。处理方式是删除旧的临时 VLAN 3 子接口，或者显式指定 `HOST_VLAN_IF` 为你要复用的接口名。

`8021q: VLAN device already exists` 的意思是：内核发现 `PHY_IF` 上已经有 VLAN ID 3 的子接口，例如当前机器上的 `eno1.3@enx00e04c0a2188`。这不是 SOME/IP 或 vSomeIP 错误，而是 Linux 802.1Q VLAN 设备的限制。

不一定必须清理。你有两个选择：

```bash
# 方案 1: 直接复用已有 VLAN 3 子接口，不改宿主机现有网卡
sudo env PHY_IF=enx00e04c0a2188 HOST_VLAN_IF=eno1.3 \
  examples/ecu_sim/run_p301_real_netns.sh setup

# 方案 2: 确认旧 VLAN 3 子接口不用后删除，再让脚本创建 faw_eno1.3
sudo env PHY_IF=enx00e04c0a2188 \
  examples/ecu_sim/run_p301_real_netns.sh reset-env
```

如果 `eno1.3` 上有宿主机业务 IP，例如 `172.20.3.100/24`，不要直接删除；先确认这不是你当前网络连接、抓包或调试正在使用的接口。

本次实际排查中，VLAN 和链路是通的：`172.20.3.36` 的 ICMP request 已经从 VLAN 3 发到 ECU，ECU 也回复了；但 ECU 把 reply 发给旧上位机 MAC `aa:bb:cc:dd:ee:23`。因此 P301 脚本默认把 `faw_eno1.3` 设置为这个 MAC，让 namespace 内的 ipvlan 也继承同一个 MAC。这样才能和 ECU 当前缓存/绑定的上位机身份一致。

如果你不想改 VLAN 子接口 MAC，可以显式设置：

```bash
sudo env PHY_IF=enx00e04c0a2188 HOST_VLAN_MAC=keep \
  examples/ecu_sim/run_p301_real_netns.sh setup
```

这种方式会保留 `faw_eno1.3` 当前 MAC，通常更适合通用网络测试；但对当前这台 P301 ECU，ping 很可能仍不通，因为 ECU 仍把 `172.20.3.36` 的回包发给旧上位机 MAC。
