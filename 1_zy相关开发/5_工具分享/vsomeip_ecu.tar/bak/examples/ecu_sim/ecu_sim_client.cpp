// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
#include <csignal>
#endif

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include <vsomeip/vsomeip.hpp>

#include "ecu_sim_ids.hpp"

namespace {

std::string hex_dump(const std::shared_ptr<vsomeip::payload>& _payload) {
    std::ostringstream its_stream;
    its_stream << std::hex << std::setfill('0');
    if (!_payload) {
        return "";
    }

    for (vsomeip::length_t i = 0; i < _payload->get_length(); ++i) {
        if (i != 0) {
            its_stream << ' ';
        }
        its_stream << std::setw(2) << static_cast<int>(_payload->get_data()[i]);
    }
    return its_stream.str();
}

void append_u32(std::vector<vsomeip::byte_t>& _data, std::uint32_t _value) {
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 24) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 16) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 8) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>(_value & 0xff));
}

const std::array<vsomeip::event_t, 4>& event_ids() {
    static const std::array<vsomeip::event_t, 4> its_events = {ECU_SIM_EVENT_ID, ECU_SIM_JSON_CYCLE_EVENT_FAST_ID,
                                                              ECU_SIM_JSON_CYCLE_EVENT_MEDIUM_ID, ECU_SIM_JSON_CYCLE_EVENT_SLOW_ID};
    return its_events;
}

} // namespace

class ecu_sim_client {
public:
    ecu_sim_client(std::uint32_t _request_cycle_ms, bool _use_tcp, bool _subscribe_events) :
        app_(vsomeip::runtime::get()->create_application("ecu-sim-client")), request_cycle_ms_(_request_cycle_ms), use_tcp_(_use_tcp),
        subscribe_events_(_subscribe_events), running_(true), available_(false), request_counter_(0) { }

    bool init() {
        if (!app_->init()) {
            std::cerr << "Couldn't initialize ecu-sim-client" << std::endl;
            return false;
        }

        app_->register_state_handler(std::bind(&ecu_sim_client::on_state, this, std::placeholders::_1));
        app_->register_availability_handler(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID,
                                            std::bind(&ecu_sim_client::on_availability, this, std::placeholders::_1,
                                                      std::placeholders::_2, std::placeholders::_3));
        app_->register_message_handler(vsomeip::ANY_SERVICE, ECU_SIM_INSTANCE_ID, vsomeip::ANY_METHOD,
                                       std::bind(&ecu_sim_client::on_message, this, std::placeholders::_1));

        std::cout << "Client protocol=" << (use_tcp_ ? "tcp" : "udp") << ", events=" << (subscribe_events_ ? "on" : "off")
                  << std::endl;

        if (subscribe_events_) {
            std::set<vsomeip::eventgroup_t> its_groups;
            its_groups.insert(ECU_SIM_EVENTGROUP_ID);
            for (const auto its_event : event_ids()) {
                app_->request_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, its_event, its_groups, vsomeip::event_type_e::ET_EVENT,
                                    vsomeip::reliability_type_e::RT_UNRELIABLE);
            }
            app_->subscribe(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_EVENTGROUP_ID);
        }
        sender_thread_ = std::thread(&ecu_sim_client::run_sender, this);
        return true;
    }

    void start() { app_->start(); }

    void stop() {
        running_ = false;
        {
            std::scoped_lock its_lock(mutex_);
            available_ = false;
        }
        condition_.notify_all();

        if (sender_thread_.joinable()) {
            sender_thread_.join();
        }

        app_->clear_all_handler();
        if (subscribe_events_) {
            app_->unsubscribe(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_EVENTGROUP_ID);
            for (const auto its_event : event_ids()) {
                app_->release_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, its_event);
            }
        }
        app_->release_service(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID);
        app_->stop();
    }

private:
    void on_state(vsomeip::state_type_e _state) {
        std::cout << "ecu-sim-client is "
                  << (_state == vsomeip::state_type_e::ST_REGISTERED ? "registered" : "deregistered") << std::endl;
        if (_state == vsomeip::state_type_e::ST_REGISTERED) {
            app_->request_service(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID);
        }
    }

    void on_availability(vsomeip::service_t _service, vsomeip::instance_t _instance, bool _is_available) {
        std::cout << "Service [" << std::hex << std::setfill('0') << std::setw(4) << _service << "." << std::setw(4) << _instance
                  << "] is " << (_is_available ? "available" : "not available") << std::endl;

        if (_service == ECU_SIM_SERVICE_ID && _instance == ECU_SIM_INSTANCE_ID) {
            {
                std::scoped_lock its_lock(mutex_);
                available_ = _is_available;
            }
            condition_.notify_all();
        }
    }

    void on_message(const std::shared_ptr<vsomeip::message>& _message) {
        const bool is_notification = _message->get_message_type() == vsomeip::message_type_e::MT_NOTIFICATION;
        const bool is_response = _message->get_message_type() == vsomeip::message_type_e::MT_RESPONSE;

        if (is_notification) {
            std::cout << "Notification event [" << std::hex << std::setfill('0') << std::setw(4) << _message->get_method()
                      << "] payload=" << hex_dump(_message->get_payload()) << std::endl;
            return;
        }

        if (is_response && _message->get_method() == ECU_SIM_METHOD_ID) {
            std::cout << "Response client/session [" << std::hex << std::setfill('0') << std::setw(4) << _message->get_client() << "/"
                      << std::setw(4) << _message->get_session() << "] payload=" << hex_dump(_message->get_payload()) << std::endl;
        }
    }

    void run_sender() {
        while (running_) {
            {
                std::unique_lock<std::mutex> its_lock(mutex_);
                condition_.wait(its_lock, [this] { return available_ || !running_; });
            }

            if (!running_) {
                break;
            }

            send_request();
            std::this_thread::sleep_for(std::chrono::milliseconds(request_cycle_ms_));
        }
    }

    void send_request() {
        const std::uint32_t its_counter = ++request_counter_;

        std::vector<vsomeip::byte_t> its_data;
        its_data.insert(its_data.end(), {'E', 'C', 'U', '_', 'R', 'E', 'Q'});
        append_u32(its_data, its_counter);
        its_data.push_back(0x10);
        its_data.push_back(0x22);
        its_data.push_back(0x33);

        auto its_payload = vsomeip::runtime::get()->create_payload();
        its_payload->set_data(its_data);

        auto its_request = vsomeip::runtime::get()->create_request(use_tcp_);
        its_request->set_service(ECU_SIM_SERVICE_ID);
        its_request->set_instance(ECU_SIM_INSTANCE_ID);
        its_request->set_method(ECU_SIM_METHOD_ID);
        its_request->set_reliable(use_tcp_);
        its_request->set_payload(its_payload);

        app_->send(its_request);
        std::cout << "Request #" << std::dec << its_counter << " sent payload=" << hex_dump(its_payload) << std::endl;
    }

    std::shared_ptr<vsomeip::application> app_;
    std::uint32_t request_cycle_ms_;
    bool use_tcp_;
    bool subscribe_events_;
    std::atomic<bool> running_;

    std::mutex mutex_;
    std::condition_variable condition_;
    bool available_;

    std::atomic<std::uint32_t> request_counter_;
    std::thread sender_thread_;
};

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
ecu_sim_client* its_client_ptr(nullptr);
void handle_signal(int _signal) {
    if (its_client_ptr != nullptr && (_signal == SIGINT || _signal == SIGTERM)) {
        its_client_ptr->stop();
    }
}
#endif

int main(int argc, char** argv) {
    std::uint32_t request_cycle_ms = 1000;
    bool use_tcp = false;
    bool subscribe_events = true;

    for (int i = 1; i < argc; ++i) {
        if (std::string("--cycle") == argv[i] && i + 1 < argc) {
            std::stringstream its_converter;
            its_converter << argv[++i];
            its_converter >> request_cycle_ms;
        } else if (std::string("--tcp") == argv[i]) {
            use_tcp = true;
        } else if (std::string("--udp") == argv[i]) {
            use_tcp = false;
        } else if (std::string("--no-subscribe") == argv[i]) {
            subscribe_events = false;
        }
    }

    ecu_sim_client its_client(request_cycle_ms, use_tcp, subscribe_events);
#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
    its_client_ptr = &its_client;
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
#endif

    if (!its_client.init()) {
        return 1;
    }

    its_client.start();
#ifdef VSOMEIP_ENABLE_SIGNAL_HANDLING
    its_client.stop();
#endif
    return 0;
}
