#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BUILD_DIR="${BUILD_DIR:-${ROOT_DIR}/build}"

SVC_NS="${SVC_NS:-vsomeip_svc}"
CLI_NS="${CLI_NS:-vsomeip_cli}"
SVC_IF="${SVC_IF:-vsecu0}"
CLI_IF="${CLI_IF:-vscli0}"
SVC_IP="${SVC_IP:-172.31.0.10}"
CLI_IP="${CLI_IP:-172.31.0.11}"
CIDR="${CIDR:-29}"
PCAP_PATH="${PCAP_PATH:-/tmp/vsomeip-ecu-sim.pcap}"
CAPTURE_COUNT="${CAPTURE_COUNT:-200}"
EVENT_CYCLE_MS="${EVENT_CYCLE_MS:-1000}"
REQUEST_CYCLE_MS="${REQUEST_CYCLE_MS:-1000}"
MODE="${MODE:-sd}"
PROTOCOL="${PROTOCOL:-udp}"
TMP_ROOT="${TMP_ROOT:-/tmp/vsomeip-ecu-sim}"
SVC_BASE="${SVC_BASE:-${TMP_ROOT}/service}"
CLI_BASE="${CLI_BASE:-${TMP_ROOT}/client}"

SERVICE_BIN="${BUILD_DIR}/examples/ecu_sim/ecu-sim-service"
CLIENT_BIN="${BUILD_DIR}/examples/ecu_sim/ecu-sim-client"
LD_PATH="${BUILD_DIR}:${BUILD_DIR}/test:${LD_LIBRARY_PATH:-}"

case "${MODE}-${PROTOCOL}" in
    sd-udp)
        SERVICE_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-service-veth.json"
        CLIENT_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-client-veth.json"
        CLIENT_PROTOCOL_ARGS=(--udp)
        ;;
    sd-tcp)
        SERVICE_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-service-tcp-veth.json"
        CLIENT_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-client-tcp-veth.json"
        CLIENT_PROTOCOL_ARGS=(--tcp)
        ;;
    static-udp)
        SERVICE_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-service-static-veth.json"
        CLIENT_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-client-static-veth.json"
        CLIENT_PROTOCOL_ARGS=(--udp --no-subscribe)
        ;;
    static-tcp)
        SERVICE_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-service-static-tcp-veth.json"
        CLIENT_CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/ecu-client-static-tcp-veth.json"
        CLIENT_PROTOCOL_ARGS=(--tcp --no-subscribe)
        ;;
    *)
        printf 'Unsupported MODE/PROTOCOL combination: MODE=%s PROTOCOL=%s\n' "${MODE}" "${PROTOCOL}" >&2
        printf 'Supported combinations: sd/udp, sd/tcp, static/udp, static/tcp\n' >&2
        exit 2
        ;;
esac

SERVICE_CONFIG="${SERVICE_CONFIG_SRC}"
CLIENT_CONFIG="${CLIENT_CONFIG_SRC}"

usage() {
    printf 'Usage: %s {build|validate|setup|reset|start|capture|wireshark|stop|clean|status}\n' "$0"
    printf 'Environment: MODE=sd|static PROTOCOL=udp|tcp EVENT_CYCLE_MS=1000 REQUEST_CYCLE_MS=1000 BUILD_DIR=... PCAP_PATH=... CAPTURE_COUNT=...\n'
}

need_root() {
    if [[ "${EUID}" -ne 0 ]]; then
        exec sudo -E bash "$0" "$@"
    fi
}

build() {
    cmake --build "${BUILD_DIR}" --target ecu-sim-service ecu-sim-client -j"$(nproc)"
}

validate() {
    if ! command -v jq >/dev/null 2>&1; then
        printf 'jq not found; skipping JSON validation\n'
        return 0
    fi

    jq empty "${ROOT_DIR}"/examples/ecu_sim/config/*.json
}

check_bins() {
    if [[ ! -x "${SERVICE_BIN}" || ! -x "${CLIENT_BIN}" ]]; then
        printf 'Missing binaries under %s. Run: %s build\n' "${BUILD_DIR}" "$0" >&2
        exit 1
    fi
}

render_runtime_configs() {
    SERVICE_CONFIG="${SVC_BASE}/$(basename "${SERVICE_CONFIG_SRC}")"
    CLIENT_CONFIG="${CLI_BASE}/$(basename "${CLIENT_CONFIG_SRC}")"

    sed \
        -e "s|172.31.0.10|${SVC_IP}|g" \
        -e "s|172.31.0.11|${CLI_IP}|g" \
        -e "s|\"device\" : \"vsecu0\"|\"device\" : \"${SVC_IF}\"|g" \
        -e "s|\"device\" : \"vscli0\"|\"device\" : \"${CLI_IF}\"|g" \
        "${SERVICE_CONFIG_SRC}" >"${SERVICE_CONFIG}"

    sed \
        -e "s|172.31.0.10|${SVC_IP}|g" \
        -e "s|172.31.0.11|${CLI_IP}|g" \
        -e "s|\"device\" : \"vsecu0\"|\"device\" : \"${SVC_IF}\"|g" \
        -e "s|\"device\" : \"vscli0\"|\"device\" : \"${CLI_IF}\"|g" \
        "${CLIENT_CONFIG_SRC}" >"${CLIENT_CONFIG}"
}

netns_exists() {
    ip netns list | awk '{print $1}' | grep -Fxq "$1"
}

link_exists_in_ns() {
    ip -n "$1" link show "$2" >/dev/null 2>&1
}

stop_vsomeip_apps() {
    local ns pid comm

    for ns in "${SVC_NS}" "${CLI_NS}"; do
        while read -r pid; do
            [[ -n "${pid}" ]] || continue
            comm="$(cat "/proc/${pid}/comm" 2>/dev/null || true)"
            case "${comm}" in
                ecu-sim-service|ecu-sim-client)
                    kill "${pid}" 2>/dev/null || true
                    ;;
            esac
        done < <(ip netns pids "${ns}" 2>/dev/null || true)
    done

    sleep 0.3

    for ns in "${SVC_NS}" "${CLI_NS}"; do
        while read -r pid; do
            [[ -n "${pid}" ]] || continue
            comm="$(cat "/proc/${pid}/comm" 2>/dev/null || true)"
            case "${comm}" in
                ecu-sim-service|ecu-sim-client)
                    kill -9 "${pid}" 2>/dev/null || true
                    ;;
            esac
        done < <(ip netns pids "${ns}" 2>/dev/null || true)
    done
}

stop_all_namespace_pids() {
    ip netns pids "${SVC_NS}" 2>/dev/null | xargs -r kill 2>/dev/null || true
    ip netns pids "${CLI_NS}" 2>/dev/null | xargs -r kill 2>/dev/null || true
}

print_namespace_pids() {
    local ns pid header_printed=0

    for ns in "${SVC_NS}" "${CLI_NS}"; do
        while read -r pid; do
            [[ -n "${pid}" ]] || continue
            if [[ "${header_printed}" -eq 0 ]]; then
                ps -o pid,comm,args -p "${pid}" 2>/dev/null || true
                header_printed=1
            else
                ps -o pid=,comm=,args= -p "${pid}" 2>/dev/null || true
            fi
        done < <(ip netns pids "${ns}" 2>/dev/null || true)
    done
}

setup() {
    need_root "$@"

    stop_vsomeip_apps
    mkdir -p "${SVC_BASE}" "${CLI_BASE}"

    if ! netns_exists "${SVC_NS}"; then
        ip netns add "${SVC_NS}"
    fi

    if ! netns_exists "${CLI_NS}"; then
        ip netns add "${CLI_NS}"
    fi

    if link_exists_in_ns "${SVC_NS}" "${SVC_IF}" && link_exists_in_ns "${CLI_NS}" "${CLI_IF}"; then
        printf 'Reusing namespaces: %s/%s and %s/%s\n' \
            "${SVC_NS}" "${SVC_IF}" "${CLI_NS}" "${CLI_IF}"
    elif ! link_exists_in_ns "${SVC_NS}" "${SVC_IF}" && ! link_exists_in_ns "${CLI_NS}" "${CLI_IF}"; then
        ip link add "${SVC_IF}" type veth peer name "${CLI_IF}"
        ip link set "${SVC_IF}" netns "${SVC_NS}"
        ip link set "${CLI_IF}" netns "${CLI_NS}"
    else
        printf 'Namespace/link state is inconsistent. Run: sudo %s reset\n' "$0" >&2
        exit 1
    fi

    ip -n "${SVC_NS}" addr replace "${SVC_IP}/${CIDR}" dev "${SVC_IF}"
    ip -n "${CLI_NS}" addr replace "${CLI_IP}/${CIDR}" dev "${CLI_IF}"
    ip -n "${SVC_NS}" link set lo up
    ip -n "${CLI_NS}" link set lo up
    ip -n "${SVC_NS}" link set "${SVC_IF}" up
    ip -n "${CLI_NS}" link set "${CLI_IF}" up
    ip -n "${SVC_NS}" route replace 224.0.0.0/4 dev "${SVC_IF}" 2>/dev/null || true
    ip -n "${CLI_NS}" route replace 224.0.0.0/4 dev "${CLI_IF}" 2>/dev/null || true

    printf 'Ready namespaces: %s(%s %s/%s) <-> %s(%s %s/%s)\n' \
        "${SVC_NS}" "${SVC_IF}" "${SVC_IP}" "${CIDR}" \
        "${CLI_NS}" "${CLI_IF}" "${CLI_IP}" "${CIDR}"
}

reset_network() {
    need_root "$@"

    stop_all_namespace_pids
    ip netns del "${SVC_NS}" 2>/dev/null || true
    ip netns del "${CLI_NS}" 2>/dev/null || true
    rm -rf "${TMP_ROOT}"
    setup "$@"
}

start() {
    need_root "$@"
    check_bins
    setup "$@"
    render_runtime_configs

    cleanup_on_exit() {
        stop_vsomeip_apps
    }
    trap cleanup_on_exit INT TERM EXIT

    ip netns exec "${SVC_NS}" env \
        LD_LIBRARY_PATH="${LD_PATH}" \
        VSOMEIP_BASE_PATH="${SVC_BASE}" \
        VSOMEIP_CONFIGURATION="${SERVICE_CONFIG}" \
        VSOMEIP_APPLICATION_NAME="ecu-sim-service" \
        "${SERVICE_BIN}" --cycle "${EVENT_CYCLE_MS}" &
    service_pid=$!

    sleep 1

    ip netns exec "${CLI_NS}" env \
        LD_LIBRARY_PATH="${LD_PATH}" \
        VSOMEIP_BASE_PATH="${CLI_BASE}" \
        VSOMEIP_CONFIGURATION="${CLIENT_CONFIG}" \
        VSOMEIP_APPLICATION_NAME="ecu-sim-client" \
        "${CLIENT_BIN}" --cycle "${REQUEST_CYCLE_MS}" "${CLIENT_PROTOCOL_ARGS[@]}" &
    client_pid=$!

    printf 'Mode: %s, protocol: %s\n' "${MODE}" "${PROTOCOL}"
    printf 'Service config: %s\nClient config: %s\n' "${SERVICE_CONFIG}" "${CLIENT_CONFIG}"
    printf 'Service PID: %s, client PID: %s\n' "${service_pid}" "${client_pid}"
    printf 'Capture with: sudo %s capture\n' "$0"
    wait "${service_pid}" "${client_pid}"
}

capture() {
    need_root "$@"
    rm -f "${PCAP_PATH}"
    local count_args=()
    if [[ "${CAPTURE_COUNT}" != "0" ]]; then
        count_args=(-c "${CAPTURE_COUNT}")
        printf 'Writing %s. Capture stops after %s packets.\n' "${PCAP_PATH}" "${CAPTURE_COUNT}"
    else
        printf 'Writing %s. Stop with Ctrl-C.\n' "${PCAP_PATH}"
    fi

    ip netns exec "${CLI_NS}" tcpdump -Z root -i "${CLI_IF}" -nn -s 0 "${count_args[@]}" -w "${PCAP_PATH}" \
        '(udp and (port 30490 or port 30509 or portrange 40000-40002)) or (tcp and (port 30510 or portrange 41000-41002))'
}

wireshark_capture() {
    need_root "$@"
    ip netns exec "${CLI_NS}" wireshark -k -i "${CLI_IF}" \
        -f 'udp port 30490 or udp port 30509 or udp portrange 40000-40002 or tcp port 30510 or tcp portrange 41000-41002'
}

status() {
    need_root "$@"
    ip netns list
    ip -n "${SVC_NS}" -brief addr 2>/dev/null || true
    ip -n "${CLI_NS}" -brief addr 2>/dev/null || true
    print_namespace_pids
    printf 'Mode: %s, protocol: %s\n' "${MODE}" "${PROTOCOL}"
    printf 'Service config: %s\nClient config: %s\n' "${SERVICE_CONFIG}" "${CLIENT_CONFIG}"
}

clean() {
    need_root "$@"
    stop_all_namespace_pids
    ip netns del "${SVC_NS}" 2>/dev/null || true
    ip netns del "${CLI_NS}" 2>/dev/null || true
    rm -rf "${TMP_ROOT}"
    rm -f /tmp/ecu_svc-* /tmp/ecu_cli-* /tmp/vsomeip-ecu-sim.pcap
}

case "${1:-}" in
    build)
        build
        ;;
    validate)
        validate
        ;;
    setup)
        setup "$@"
        ;;
    reset)
        reset_network "$@"
        ;;
    start)
        start "$@"
        ;;
    capture)
        capture "$@"
        ;;
    wireshark)
        wireshark_capture "$@"
        ;;
    stop)
        need_root "$@"
        stop_vsomeip_apps
        ;;
    clean)
        clean "$@"
        ;;
    status)
        status "$@"
        ;;
    *)
        usage
        exit 1
        ;;
esac
