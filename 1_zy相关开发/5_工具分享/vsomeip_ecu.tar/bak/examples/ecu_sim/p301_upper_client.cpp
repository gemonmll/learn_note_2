// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
#include <csignal>
#endif

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <set>
#include <sstream>
#include <thread>

#include <vsomeip/vsomeip.hpp>

namespace {

constexpr vsomeip::service_t P301_SERVICE_ID = 0x77fb;
constexpr vsomeip::instance_t P301_INSTANCE_ID = 0x0001;
constexpr vsomeip::major_version_t P301_MAJOR_VERSION = 0x01;
constexpr vsomeip::minor_version_t P301_MINOR_VERSION = 0x00000000;
constexpr vsomeip::eventgroup_t P301_EVENTGROUP_ID = 0x7001;

const std::array<vsomeip::event_t, 10>& p301_event_ids() {
    static const std::array<vsomeip::event_t, 10> its_events = {
            0x8001, 0x8002, 0x8004, 0x8005, 0x8008, 0x8010, 0x9003, 0x9006, 0x9007, 0x9009};
    return its_events;
}

std::string hex_dump(const std::shared_ptr<vsomeip::payload>& _payload) {
    std::ostringstream its_stream;
    its_stream << std::hex << std::setfill('0');
    if (!_payload) {
        return "";
    }

    for (vsomeip::length_t i = 0; i < _payload->get_length(); ++i) {
        if (i != 0) {
            its_stream << ' ';
        }
        its_stream << std::setw(2) << static_cast<int>(_payload->get_data()[i]);
    }
    return its_stream.str();
}

} // namespace

class p301_upper_client {
public:
    p301_upper_client() : app_(vsomeip::runtime::get()->create_application("p301-upper-client")), subscribed_(false) { }

    bool init() {
        if (!app_->init()) {
            std::cerr << "Couldn't initialize p301-upper-client" << std::endl;
            return false;
        }

        app_->register_state_handler(std::bind(&p301_upper_client::on_state, this, std::placeholders::_1));
        app_->register_availability_handler(P301_SERVICE_ID, P301_INSTANCE_ID,
                                            std::bind(&p301_upper_client::on_availability, this, std::placeholders::_1,
                                                      std::placeholders::_2, std::placeholders::_3),
                                            P301_MAJOR_VERSION, P301_MINOR_VERSION);
        app_->register_message_handler(vsomeip::ANY_SERVICE, P301_INSTANCE_ID, vsomeip::ANY_METHOD,
                                       std::bind(&p301_upper_client::on_message, this, std::placeholders::_1));

        std::set<vsomeip::eventgroup_t> its_groups;
        its_groups.insert(P301_EVENTGROUP_ID);
        for (const auto its_event : p301_event_ids()) {
            app_->request_event(P301_SERVICE_ID, P301_INSTANCE_ID, its_event, its_groups, vsomeip::event_type_e::ET_EVENT,
                                vsomeip::reliability_type_e::RT_UNRELIABLE);
        }

        std::cout << "P301 upper client prepared: service [77fb.0001:1.0], eventgroup [7001]" << std::endl;
        return true;
    }

    void start() { app_->start(); }

    void stop() {
        app_->clear_all_handler();
        if (subscribed_.exchange(false)) {
            app_->unsubscribe(P301_SERVICE_ID, P301_INSTANCE_ID, P301_EVENTGROUP_ID);
        }
        for (const auto its_event : p301_event_ids()) {
            app_->release_event(P301_SERVICE_ID, P301_INSTANCE_ID, its_event);
        }
        app_->release_service(P301_SERVICE_ID, P301_INSTANCE_ID);
        app_->stop();
    }

private:
    void on_state(vsomeip::state_type_e _state) {
        std::cout << "p301-upper-client is " << (_state == vsomeip::state_type_e::ST_REGISTERED ? "registered" : "deregistered")
                  << std::endl;
        if (_state == vsomeip::state_type_e::ST_REGISTERED) {
            app_->request_service(P301_SERVICE_ID, P301_INSTANCE_ID, P301_MAJOR_VERSION, P301_MINOR_VERSION);
        }
    }

    void on_availability(vsomeip::service_t _service, vsomeip::instance_t _instance, bool _is_available) {
        std::cout << "Service [" << std::hex << std::setfill('0') << std::setw(4) << _service << "." << std::setw(4) << _instance
                  << "] is " << (_is_available ? "available" : "not available") << std::endl;

        if (_service == P301_SERVICE_ID && _instance == P301_INSTANCE_ID) {
            if (_is_available && !subscribed_.exchange(true)) {
                app_->subscribe(P301_SERVICE_ID, P301_INSTANCE_ID, P301_EVENTGROUP_ID, P301_MAJOR_VERSION);
                std::cout << "Subscribed eventgroup [7001]" << std::endl;
            } else if (!_is_available) {
                subscribed_ = false;
            }
        }
    }

    void on_message(const std::shared_ptr<vsomeip::message>& _message) {
        if (_message->get_message_type() != vsomeip::message_type_e::MT_NOTIFICATION) {
            std::cout << "Message type [" << std::hex << static_cast<int>(_message->get_message_type()) << "] method ["
                      << std::setw(4) << _message->get_method() << "] payload=" << hex_dump(_message->get_payload()) << std::endl;
            return;
        }

        std::cout << "Notification [77fb.0001." << std::hex << std::setfill('0') << std::setw(4) << _message->get_method()
                  << "] client/session [" << std::setw(4) << _message->get_client() << "/" << std::setw(4) << _message->get_session()
                  << "] payload=" << hex_dump(_message->get_payload()) << std::endl;
    }

    std::shared_ptr<vsomeip::application> app_;
    std::atomic<bool> subscribed_;
};

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
p301_upper_client* its_client_ptr(nullptr);
void handle_signal(int _signal) {
    if (its_client_ptr != nullptr && (_signal == SIGINT || _signal == SIGTERM)) {
        its_client_ptr->stop();
    }
}
#endif

int main() {
#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
    std::signal(SIGINT, handle_signal);
    std::signal(SIGTERM, handle_signal);
#endif

    p301_upper_client its_client;
#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
    its_client_ptr = &its_client;
#endif

    if (!its_client.init()) {
        return 1;
    }

    its_client.start();
    return 0;
}
