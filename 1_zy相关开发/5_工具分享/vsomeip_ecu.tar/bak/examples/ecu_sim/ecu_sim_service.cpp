// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
#include <csignal>
#endif

#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

#include <vsomeip/vsomeip.hpp>

#include "ecu_sim_ids.hpp"

namespace {

std::string hex_dump(const std::shared_ptr<vsomeip::payload>& _payload) {
    std::ostringstream its_stream;
    its_stream << std::hex << std::setfill('0');
    if (!_payload) {
        return "";
    }

    for (vsomeip::length_t i = 0; i < _payload->get_length(); ++i) {
        if (i != 0) {
            its_stream << ' ';
        }
        its_stream << std::setw(2) << static_cast<int>(_payload->get_data()[i]);
    }
    return its_stream.str();
}

void append_u32(std::vector<vsomeip::byte_t>& _data, std::uint32_t _value) {
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 24) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 16) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>((_value >> 8) & 0xff));
    _data.push_back(static_cast<vsomeip::byte_t>(_value & 0xff));
}

const std::array<vsomeip::event_t, 3>& json_cycle_event_ids() {
    static const std::array<vsomeip::event_t, 3> its_events = {ECU_SIM_JSON_CYCLE_EVENT_FAST_ID, ECU_SIM_JSON_CYCLE_EVENT_MEDIUM_ID,
                                                              ECU_SIM_JSON_CYCLE_EVENT_SLOW_ID};
    return its_events;
}

std::vector<vsomeip::byte_t> make_json_cycle_payload(vsomeip::event_t _event) {
    std::vector<vsomeip::byte_t> its_data;
    its_data.insert(its_data.end(), {'J', 'S', 'O', 'N', '_', 'C', 'Y', 'C'});
    append_u32(its_data, _event);

    switch (_event) {
    case ECU_SIM_JSON_CYCLE_EVENT_FAST_ID:
        its_data.insert(its_data.end(), {'_', 'F', 'A', 'S', 'T'});
        break;
    case ECU_SIM_JSON_CYCLE_EVENT_MEDIUM_ID:
        its_data.insert(its_data.end(), {'_', 'M', 'E', 'D'});
        break;
    case ECU_SIM_JSON_CYCLE_EVENT_SLOW_ID:
        its_data.insert(its_data.end(), {'_', 'S', 'L', 'O', 'W'});
        break;
    default:
        its_data.insert(its_data.end(), {'_', 'U', 'N', 'K'});
        break;
    }

    return its_data;
}

} // namespace

class ecu_sim_service {
public:
    explicit ecu_sim_service(std::uint32_t _event_cycle_ms) :
        app_(vsomeip::runtime::get()->create_application("ecu-sim-service")), event_cycle_ms_(_event_cycle_ms), running_(true),
        offered_(false), json_cycle_payloads_seeded_(false), request_counter_(0), event_counter_(0) { }

    bool init() {
        if (!app_->init()) {
            std::cerr << "Couldn't initialize ecu-sim-service" << std::endl;
            return false;
        }

        app_->register_state_handler(std::bind(&ecu_sim_service::on_state, this, std::placeholders::_1));
        app_->register_message_handler(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_METHOD_ID,
                                       std::bind(&ecu_sim_service::on_request, this, std::placeholders::_1));

        std::set<vsomeip::eventgroup_t> its_groups;
        its_groups.insert(ECU_SIM_EVENTGROUP_ID);
        app_->offer_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_EVENT_ID, its_groups, vsomeip::event_type_e::ET_EVENT,
                          std::chrono::milliseconds::zero(), false, true, nullptr, vsomeip::reliability_type_e::RT_UNRELIABLE);
        for (const auto its_event : json_cycle_event_ids()) {
            app_->offer_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, its_event, its_groups, vsomeip::event_type_e::ET_EVENT,
                              std::chrono::milliseconds::zero(), false, true, nullptr, vsomeip::reliability_type_e::RT_UNRELIABLE);
        }

        event_thread_ = std::thread(&ecu_sim_service::run_event_loop, this);
        return true;
    }

    void start() { app_->start(); }

    void stop() {
        running_ = false;
        {
            std::scoped_lock its_lock(mutex_);
            offered_ = false;
        }
        condition_.notify_all();

        app_->clear_all_handler();
        app_->stop_offer_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_EVENT_ID);
        for (const auto its_event : json_cycle_event_ids()) {
            app_->stop_offer_event(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, its_event);
        }
        app_->stop_offer_service(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID);

        if (event_thread_.joinable()) {
            event_thread_.join();
        }
        app_->stop();
    }

private:
    void on_state(vsomeip::state_type_e _state) {
        std::cout << "ecu-sim-service is "
                  << (_state == vsomeip::state_type_e::ST_REGISTERED ? "registered" : "deregistered") << std::endl;

        if (_state == vsomeip::state_type_e::ST_REGISTERED) {
            app_->offer_service(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID);
            seed_json_cycle_payloads();
            {
                std::scoped_lock its_lock(mutex_);
                offered_ = true;
            }
            condition_.notify_all();
            std::cout << "Offering service [1234.5678], method [0421], eventgroup [4465]" << std::endl;
        }
    }

    void seed_json_cycle_payloads() {
        if (json_cycle_payloads_seeded_.exchange(true)) {
            return;
        }

        for (const auto its_event : json_cycle_event_ids()) {
            auto its_payload = vsomeip::runtime::get()->create_payload();
            its_payload->set_data(make_json_cycle_payload(its_event));
            app_->notify(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, its_event, its_payload);
            std::cout << "Seeded JSON-cycle event [" << std::hex << std::setfill('0') << std::setw(4) << its_event
                      << "] payload=" << hex_dump(its_payload) << std::endl;
        }
    }

    void on_request(const std::shared_ptr<vsomeip::message>& _request) {
        const std::uint32_t its_counter = ++request_counter_;

        std::cout << "Request #" << std::dec << its_counter << " from client/session [" << std::hex << std::setfill('0')
                  << std::setw(4) << _request->get_client() << "/" << std::setw(4) << _request->get_session() << "] payload="
                  << hex_dump(_request->get_payload()) << std::endl;

        std::vector<vsomeip::byte_t> its_data;
        its_data.insert(its_data.end(), {'E', 'C', 'U', '_', 'R', 'S', 'P'});
        append_u32(its_data, its_counter);

        const auto its_payload = _request->get_payload();
        const auto its_length = its_payload ? its_payload->get_length() : 0;
        its_data.push_back(static_cast<vsomeip::byte_t>((its_length >> 8) & 0xff));
        its_data.push_back(static_cast<vsomeip::byte_t>(its_length & 0xff));

        if (its_payload) {
            for (vsomeip::length_t i = 0; i < its_payload->get_length(); ++i) {
                its_data.push_back(its_payload->get_data()[i]);
            }
        }

        auto its_response = vsomeip::runtime::get()->create_response(_request);
        auto its_response_payload = vsomeip::runtime::get()->create_payload();
        its_response_payload->set_data(its_data);
        its_response->set_payload(its_response_payload);
        app_->send(its_response);
    }

    void run_event_loop() {
        while (running_) {
            {
                std::unique_lock<std::mutex> its_lock(mutex_);
                condition_.wait(its_lock, [this] { return offered_ || !running_; });
            }

            if (!running_) {
                break;
            }

            const std::uint32_t its_counter = ++event_counter_;
            std::vector<vsomeip::byte_t> its_data;
            its_data.insert(its_data.end(), {'E', 'C', 'U', '_', 'E', 'V', 'T'});
            append_u32(its_data, its_counter);
            its_data.push_back(static_cast<vsomeip::byte_t>(its_counter & 0xff));

            auto its_payload = vsomeip::runtime::get()->create_payload();
            its_payload->set_data(its_data);

            app_->notify(ECU_SIM_SERVICE_ID, ECU_SIM_INSTANCE_ID, ECU_SIM_EVENT_ID, its_payload);
            std::cout << "Published event #" << std::dec << its_counter << " payload=" << hex_dump(its_payload) << std::endl;

            std::this_thread::sleep_for(std::chrono::milliseconds(event_cycle_ms_));
        }
    }

    std::shared_ptr<vsomeip::application> app_;
    std::uint32_t event_cycle_ms_;
    std::atomic<bool> running_;

    std::mutex mutex_;
    std::condition_variable condition_;
    bool offered_;
    std::atomic<bool> json_cycle_payloads_seeded_;

    std::atomic<std::uint32_t> request_counter_;
    std::atomic<std::uint32_t> event_counter_;
    std::thread event_thread_;
};

#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
ecu_sim_service* its_service_ptr(nullptr);
void handle_signal(int _signal) {
    if (its_service_ptr != nullptr && (_signal == SIGINT || _signal == SIGTERM)) {
        its_service_ptr->stop();
    }
}
#endif

int main(int argc, char** argv) {
    std::uint32_t event_cycle_ms = 1000;

    for (int i = 1; i < argc; ++i) {
        if (std::string("--cycle") == argv[i] && i + 1 < argc) {
            std::stringstream its_converter;
            its_converter << argv[++i];
            its_converter >> event_cycle_ms;
        }
    }

    ecu_sim_service its_service(event_cycle_ms);
#ifndef VSOMEIP_ENABLE_SIGNAL_HANDLING
    its_service_ptr = &its_service;
    signal(SIGINT, handle_signal);
    signal(SIGTERM, handle_signal);
#endif

    if (!its_service.init()) {
        return 1;
    }

    its_service.start();
#ifdef VSOMEIP_ENABLE_SIGNAL_HANDLING
    its_service.stop();
#endif
    return 0;
}
