#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BUILD_DIR="${BUILD_DIR:-${ROOT_DIR}/build}"

NS="${NS:-p301_upper}"
PHY_IF="${PHY_IF:-enx00e04c0a2188}"
HOST_VLAN_IF="${HOST_VLAN_IF:-faw_eno1.3}"
HOST_VLAN_MAC="${HOST_VLAN_MAC:-aa:bb:cc:dd:ee:23}"
NS_IF="${NS_IF:-p301vlan3}"
VLAN_ID="${VLAN_ID:-3}"
SIM_IP="${SIM_IP:-172.20.3.36}"
ECU_IP="${ECU_IP:-172.20.3.68}"
CIDR="${CIDR:-24}"
NETMASK="${NETMASK:-255.255.255.0}"
SD_MULTICAST="${SD_MULTICAST:-239.255.3.1}"
TMP_ROOT="${TMP_ROOT:-/tmp/vsomeip-p301-real}"
BASE_PATH="${BASE_PATH:-${TMP_ROOT}/client}"
PCAP_PATH="${PCAP_PATH:-/tmp/vsomeip-p301-real.pcap}"
CAPTURE_COUNT="${CAPTURE_COUNT:-0}"

CLIENT_BIN="${BUILD_DIR}/examples/ecu_sim/p301-upper-client"
CONFIG_SRC="${ROOT_DIR}/examples/ecu_sim/config/p301-upper-client-vlan3.json"
CONFIG="${CONFIG_SRC}"
LD_PATH="${BUILD_DIR}:${BUILD_DIR}/test:${LD_LIBRARY_PATH:-}"

usage() {
    printf 'Usage: %s {build|validate|setup|setup-env|ping|start|capture|capture-phy|wireshark|wireshark-phy|stop|clean|clean-env|delete-vlan|delete-vlan-all|reset-env|status}\n' "$0"
    printf 'Environment: PHY_IF=enx00e04c0a2188 HOST_VLAN_IF=faw_eno1.3 HOST_VLAN_MAC=aa:bb:cc:dd:ee:23|keep VLAN_ID=3 SIM_IP=172.20.3.36 ECU_IP=172.20.3.68\n'
}

need_root() {
    if [[ "${EUID}" -ne 0 ]]; then
        exec sudo -E bash "$0" "$@"
    fi
}

build() {
    cmake --build "${BUILD_DIR}" --target p301-upper-client -j"$(nproc)"
}

validate() {
    if ! command -v jq >/dev/null 2>&1; then
        printf 'jq not found; skipping JSON validation\n'
        return 0
    fi
    jq empty "${CONFIG_SRC}"
}

check_bin() {
    if [[ ! -x "${CLIENT_BIN}" ]]; then
        printf 'Missing binary %s. Run: %s build\n' "${CLIENT_BIN}" "$0" >&2
        exit 1
    fi
}

netns_exists() {
    ip netns list | awk '{print $1}' | grep -Fxq "$1"
}

link_exists_in_ns() {
    ip -n "$1" link show "$2" >/dev/null 2>&1
}

link_is_ipvlan_in_ns() {
    ip -n "$1" -d link show "$2" 2>/dev/null | grep -q 'ipvlan'
}

existing_vlan_interfaces() {
    ip -d -o link show type vlan 2>/dev/null |
        awk -v phy="@${PHY_IF}:" -v vid=" id ${VLAN_ID} " '
            index($0, phy) && index($0, vid) {
                sub(/^[0-9]+: /, "", $0);
                split($0, name, ": ");
                split(name[1], base, "@");
                print base[1];
            }'
}

all_vlan_interfaces_by_id() {
    ip -d -o link show type vlan 2>/dev/null |
        awk -v vid=" id ${VLAN_ID} " '
            index($0, vid) {
                sub(/^[0-9]+: /, "", $0);
                split($0, name, ": ");
                split(name[1], base, "@");
                print base[1];
            }'
}

apply_host_vlan_mac() {
    [[ -n "${HOST_VLAN_MAC}" ]] || return 0
    case "${HOST_VLAN_MAC}" in
        keep|KEEP|none|NONE)
            return 0
            ;;
    esac

    local current_mac
    current_mac="$(cat "/sys/class/net/${HOST_VLAN_IF}/address" 2>/dev/null || true)"
    if [[ "${current_mac}" == "${HOST_VLAN_MAC}" ]]; then
        return 0
    fi

    if netns_exists "${NS}" && link_exists_in_ns "${NS}" "${NS_IF}"; then
        ip -n "${NS}" link set "${NS_IF}" down 2>/dev/null || true
    fi

    ip link set "${HOST_VLAN_IF}" down
    ip link set "${HOST_VLAN_IF}" address "${HOST_VLAN_MAC}"
    ip link set "${HOST_VLAN_IF}" up
}

stop_client() {
    local pid comm
    while read -r pid; do
        [[ -n "${pid}" ]] || continue
        comm="$(cat "/proc/${pid}/comm" 2>/dev/null || true)"
        if [[ "${comm}" == "p301-upper-client" ]]; then
            kill "${pid}" 2>/dev/null || true
        fi
    done < <(ip netns pids "${NS}" 2>/dev/null || true)
}

stop_all_namespace_pids() {
    ip netns pids "${NS}" 2>/dev/null | xargs -r kill 2>/dev/null || true
}

ensure_host_vlan() {
    if ip link show "${HOST_VLAN_IF}" >/dev/null 2>&1; then
        apply_host_vlan_mac
        ip link set "${HOST_VLAN_IF}" up
        return 0
    fi

    if ! ip link show "${PHY_IF}" >/dev/null 2>&1; then
        printf 'Physical interface %s does not exist. Set PHY_IF to the real NIC.\n' "${PHY_IF}" >&2
        exit 1
    fi

    if ! ip link add link "${PHY_IF}" name "${HOST_VLAN_IF}" type vlan id "${VLAN_ID}" 2>/tmp/p301-vlan-add.err; then
        local existing
        existing="$(existing_vlan_interfaces | tr '\n' ' ')"
        printf 'Cannot create VLAN interface %s on %s with VLAN ID %s.\n' "${HOST_VLAN_IF}" "${PHY_IF}" "${VLAN_ID}" >&2
        printf 'Kernel message: %s\n' "$(cat /tmp/p301-vlan-add.err)" >&2
        if [[ -n "${existing}" ]]; then
            printf 'Existing VLAN-%s interface(s) on %s: %s\n' "${VLAN_ID}" "${PHY_IF}" "${existing}" >&2
            printf 'You can reuse one with: HOST_VLAN_IF=<existing-if> %s setup\n' "$0" >&2
            printf 'Only delete/rename the existing interface if you really want the default name %s.\n' "${HOST_VLAN_IF}" >&2
        else
            printf 'Clean or rename any existing VLAN-%s interface on %s, or set HOST_VLAN_IF to the interface you want to use.\n' \
                "${VLAN_ID}" "${PHY_IF}" >&2
        fi
        exit 1
    fi

    apply_host_vlan_mac
    ip link set "${HOST_VLAN_IF}" up
}

render_runtime_config() {
    mkdir -p "${BASE_PATH}"
    CONFIG="${BASE_PATH}/$(basename "${CONFIG_SRC}")"
    sed \
        -e "s|172.20.3.36|${SIM_IP}|g" \
        -e "s|172.20.3.68|${ECU_IP}|g" \
        -e "s|255.255.255.0|${NETMASK}|g" \
        -e "s|\"device\" : \"p301vlan3\"|\"device\" : \"${NS_IF}\"|g" \
        -e "s|239.255.3.1|${SD_MULTICAST}|g" \
        "${CONFIG_SRC}" >"${CONFIG}"
}

setup() {
    need_root "$@"
    stop_client
    mkdir -p "${BASE_PATH}"
    ensure_host_vlan

    if ! netns_exists "${NS}"; then
        ip netns add "${NS}"
    fi

    if link_exists_in_ns "${NS}" "${NS_IF}"; then
        if ! link_is_ipvlan_in_ns "${NS}" "${NS_IF}"; then
            printf 'Namespace %s already has %s, but it is not an ipvlan interface. Run "%s clean" first.\n' \
                "${NS}" "${NS_IF}" "$0" >&2
            exit 1
        fi
        printf 'Reusing namespace %s and ipvlan %s\n' "${NS}" "${NS_IF}"
    else
        ip link add "${NS_IF}" link "${HOST_VLAN_IF}" type ipvlan mode l2
        ip link set "${NS_IF}" netns "${NS}"
    fi

    ip -n "${NS}" addr replace "${SIM_IP}/${CIDR}" dev "${NS_IF}"
    ip -n "${NS}" link set lo up
    ip -n "${NS}" link set "${NS_IF}" up
    ip -n "${NS}" route replace 224.0.0.0/4 dev "${NS_IF}" 2>/dev/null || true
    ip -n "${NS}" route replace "${ECU_IP}/32" dev "${NS_IF}" 2>/dev/null || true

    printf 'Ready: %s(%s %s/%s) -> ipvlan -> %s(VLAN %s on %s, MAC %s), ECU %s, SD %s\n' \
        "${NS}" "${NS_IF}" "${SIM_IP}" "${CIDR}" \
        "${HOST_VLAN_IF}" "${VLAN_ID}" "${PHY_IF}" "$(cat "/sys/class/net/${HOST_VLAN_IF}/address")" "${ECU_IP}" "${SD_MULTICAST}"
}

ping_ecu() {
    need_root "$@"
    setup "$@"
    ip netns exec "${NS}" ping -c "${PING_COUNT:-4}" -W "${PING_WAIT:-2}" -I "${NS_IF}" "${ECU_IP}"
}

start() {
    need_root "$@"
    check_bin
    setup "$@"
    render_runtime_config

    trap stop_client INT TERM EXIT
    ip netns exec "${NS}" env \
        LD_LIBRARY_PATH="${LD_PATH}" \
        VSOMEIP_BASE_PATH="${BASE_PATH}" \
        VSOMEIP_CONFIGURATION="${CONFIG}" \
        VSOMEIP_APPLICATION_NAME="p301-upper-client" \
        "${CLIENT_BIN}"
}

capture() {
    need_root "$@"
    rm -f "${PCAP_PATH}"
    local count_args=()
    if [[ "${CAPTURE_COUNT}" != "0" ]]; then
        count_args=(-c "${CAPTURE_COUNT}")
    fi
    ip netns exec "${NS}" tcpdump -Z root -i "${NS_IF}" -nn -s 0 "${count_args[@]}" -w "${PCAP_PATH}" \
        "(host ${ECU_IP} or host ${SD_MULTICAST} or igmp or arp) and (udp or igmp or arp)"
}

capture_phy() {
    need_root "$@"
    rm -f "${PCAP_PATH}"
    local count_args=()
    if [[ "${CAPTURE_COUNT}" != "0" ]]; then
        count_args=(-c "${CAPTURE_COUNT}")
    fi
    tcpdump -Z root -i "${PHY_IF}" -nn -e -s 0 "${count_args[@]}" -w "${PCAP_PATH}" \
        "vlan ${VLAN_ID} and (host ${ECU_IP} or host ${SD_MULTICAST} or igmp or arp)"
}

wireshark_capture() {
    need_root "$@"
    ip netns exec "${NS}" wireshark -k -i "${NS_IF}" \
        -f "host ${ECU_IP} or host ${SD_MULTICAST} or igmp or arp"
}

wireshark_phy_capture() {
    need_root "$@"
    wireshark -k -i "${PHY_IF}" \
        -f "vlan ${VLAN_ID} and (host ${ECU_IP} or host ${SD_MULTICAST} or igmp or arp)"
}

status() {
    need_root "$@"
    ip netns list
    local existing
    existing="$(existing_vlan_interfaces | tr '\n' ' ')"
    if [[ -n "${existing}" ]]; then
        printf 'Existing VLAN-%s interface(s) on %s: %s\n' "${VLAN_ID}" "${PHY_IF}" "${existing}"
    else
        printf 'No VLAN-%s interface found on %s\n' "${VLAN_ID}" "${PHY_IF}"
    fi
    ip -brief link show "${HOST_VLAN_IF}" 2>/dev/null || true
    printf 'Expected host VLAN MAC: %s\n' "${HOST_VLAN_MAC}"
    ip -n "${NS}" -brief addr 2>/dev/null || true
    ip -n "${NS}" -d link show "${NS_IF}" 2>/dev/null || true
    ip -n "${NS}" route 2>/dev/null || true
    ip netns pids "${NS}" 2>/dev/null | xargs -r ps -o pid,comm,args -p 2>/dev/null || true
}

clean_host_vlan_if_unused() {
    if ! ip link show "${HOST_VLAN_IF}" >/dev/null 2>&1; then
        return 0
    fi
    if ip -o addr show dev "${HOST_VLAN_IF}" scope global | grep -q .; then
        printf 'Keeping %s because it has a global IP address.\n' "${HOST_VLAN_IF}"
        return 0
    fi
    ip link del "${HOST_VLAN_IF}" 2>/dev/null || true
}

clean() {
    need_root "$@"
    stop_all_namespace_pids
    ip netns del "${NS}" 2>/dev/null || true
    clean_host_vlan_if_unused
    rm -rf "${TMP_ROOT}"
    rm -f "${PCAP_PATH}" /tmp/p301-vlan-add.err
}

delete_vlan() {
    need_root "$@"
    stop_all_namespace_pids
    ip netns del "${NS}" 2>/dev/null || true

    local iface deleted=0 ips
    while read -r iface; do
        [[ -n "${iface}" ]] || continue
        ips="$(ip -o addr show dev "${iface}" scope global 2>/dev/null | awk '{print $4}' | paste -sd ',' -)"
        if [[ -n "${ips}" ]]; then
            printf 'Deleting VLAN-%s interface %s on %s. It has global IP(s): %s\n' \
                "${VLAN_ID}" "${iface}" "${PHY_IF}" "${ips}"
        else
            printf 'Deleting VLAN-%s interface %s on %s.\n' "${VLAN_ID}" "${iface}" "${PHY_IF}"
        fi
        ip link del "${iface}" 2>/dev/null || true
        deleted=1
    done < <(existing_vlan_interfaces)

    if [[ "${deleted}" -eq 0 ]]; then
        printf 'No VLAN-%s interface found on %s.\n' "${VLAN_ID}" "${PHY_IF}"
    fi

    rm -rf "${TMP_ROOT}"
    rm -f "${PCAP_PATH}" /tmp/p301-vlan-add.err
}

delete_vlan_all() {
    need_root "$@"
    stop_all_namespace_pids
    ip netns del "${NS}" 2>/dev/null || true

    local iface deleted=0 ips
    while read -r iface; do
        [[ -n "${iface}" ]] || continue
        ips="$(ip -o addr show dev "${iface}" scope global 2>/dev/null | awk '{print $4}' | paste -sd ',' -)"
        if [[ -n "${ips}" ]]; then
            printf 'Deleting VLAN-%s interface %s. It has global IP(s): %s\n' "${VLAN_ID}" "${iface}" "${ips}"
        else
            printf 'Deleting VLAN-%s interface %s.\n' "${VLAN_ID}" "${iface}"
        fi
        ip link del "${iface}" 2>/dev/null || true
        deleted=1
    done < <(all_vlan_interfaces_by_id)

    if [[ "${deleted}" -eq 0 ]]; then
        printf 'No VLAN-%s interface found.\n' "${VLAN_ID}"
    fi

    rm -rf "${TMP_ROOT}"
    rm -f "${PCAP_PATH}" /tmp/p301-vlan-add.err
}

reset_env() {
    need_root "$@"
    delete_vlan "$@"
    setup "$@"
}

case "${1:-}" in
    build)
        build
        ;;
    validate)
        validate
        ;;
    setup)
        setup "$@"
        ;;
    setup-env)
        setup "$@"
        ;;
    ping)
        ping_ecu "$@"
        ;;
    start)
        start "$@"
        ;;
    capture)
        capture "$@"
        ;;
    capture-phy)
        capture_phy "$@"
        ;;
    wireshark)
        wireshark_capture "$@"
        ;;
    wireshark-phy)
        wireshark_phy_capture "$@"
        ;;
    stop)
        need_root "$@"
        stop_client
        ;;
    clean)
        clean "$@"
        ;;
    clean-env)
        clean "$@"
        ;;
    delete-vlan)
        delete_vlan "$@"
        ;;
    delete-vlan-all)
        delete_vlan_all "$@"
        ;;
    reset-env)
        reset_env "$@"
        ;;
    status)
        status "$@"
        ;;
    *)
        usage
        exit 1
        ;;
esac
