// Copyright (C) 2014-2026 Bayerische Motoren Werke Aktiengesellschaft (BMW AG)
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#pragma once

#define ECU_SIM_SERVICE_ID    0x1234
#define ECU_SIM_INSTANCE_ID   0x5678
#define ECU_SIM_METHOD_ID     0x0421
#define ECU_SIM_EVENT_ID      0x8778
#define ECU_SIM_EVENTGROUP_ID 0x4465

#define ECU_SIM_JSON_CYCLE_EVENT_FAST_ID   0x8781
#define ECU_SIM_JSON_CYCLE_EVENT_MEDIUM_ID 0x8782
#define ECU_SIM_JSON_CYCLE_EVENT_SLOW_ID   0x8783
