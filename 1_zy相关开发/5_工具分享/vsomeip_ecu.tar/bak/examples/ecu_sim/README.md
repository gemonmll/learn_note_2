# ECU SOME/IP 示例

这个目录保留两类测试：

```text
1. 本机两个 ECU 节点模拟:
   ecu-sim-service + ecu-sim-client + run_local_netns.sh

2. 真实 P301 ECU 通信:
   p301-upper-client + run_p301_real_netns.sh
```

## 文件说明

```text
ecu_sim_service.cpp                  本机 service 节点
ecu_sim_client.cpp                   本机 client 节点
ecu_sim_ids.hpp                      本机示例的 service/method/event ID
p301_upper_client.cpp                P301 上位机 client

config/ecu-service-veth.json         本机 SD + UDP service 配置
config/ecu-client-veth.json          本机 SD + UDP client 配置
config/ecu-service-tcp-veth.json     本机 SD + TCP service 配置
config/ecu-client-tcp-veth.json      本机 SD + TCP client 配置
config/ecu-service-static-veth.json  本机 static + UDP service 配置
config/ecu-client-static-veth.json   本机 static + UDP client 配置
config/ecu-service-static-tcp-veth.json  本机 static + TCP service 配置
config/ecu-client-static-tcp-veth.json   本机 static + TCP client 配置
config/p301-upper-client-vlan3.json  P301 上位机配置

run_local_netns.sh                   本机双 namespace 测试脚本
run_p301_real_netns.sh               真实网卡 + VLAN + ipvlan 测试脚本
P301_REAL_ECU.md                     P301 真实 ECU 操作手顺
```

## 编译

在工程根目录执行：

```bash
cmake -S . -B build
cmake --build build --target ecu-sim-service ecu-sim-client p301-upper-client -j"$(nproc)"
```

检查 JSON：

```bash
examples/ecu_sim/run_local_netns.sh validate
examples/ecu_sim/run_p301_real_netns.sh validate
```

## 本机模拟两个 ECU

网络模型：

```text
vsomeip_svc/vsecu0  172.31.0.10/29
        |
      veth
        |
vsomeip_cli/vscli0  172.31.0.11/29
```

建立或复用网络环境：

```bash
sudo examples/ecu_sim/run_local_netns.sh setup
sudo examples/ecu_sim/run_local_netns.sh status
```

先打开 Wireshark 抓客户端侧：

```bash
sudo -E examples/ecu_sim/run_local_netns.sh wireshark
```

另开一个终端启动服务端和客户端。默认是 `MODE=sd PROTOCOL=udp`：

```bash
sudo examples/ecu_sim/run_local_netns.sh start
```

本机脚本保留四种模式：

```bash
# SD 开启，method request/response 走 UDP，event 订阅/通知开启
sudo env MODE=sd PROTOCOL=udp examples/ecu_sim/run_local_netns.sh start

# SD 开启，method request/response 走 TCP，event 订阅/通知仍走 UDP
sudo env MODE=sd PROTOCOL=tcp examples/ecu_sim/run_local_netns.sh start

# SD 关闭，静态配置，method 走 UDP
sudo env MODE=static PROTOCOL=udp examples/ecu_sim/run_local_netns.sh start

# SD 关闭，静态配置，method 走 TCP
sudo env MODE=static PROTOCOL=tcp examples/ecu_sim/run_local_netns.sh start
```

`static` 模式不做 eventgroup 订阅，因为 SOME/IP eventgroup 订阅由 SOME/IP-SD 承载。

保存 pcap：

```bash
sudo env PCAP_PATH=/tmp/vsomeip-ecu-sim.pcap CAPTURE_COUNT=200 \
  examples/ecu_sim/run_local_netns.sh capture
```

停止应用但保留 namespace：

```bash
sudo examples/ecu_sim/run_local_netns.sh stop
```

删除 namespace、veth 和临时文件：

```bash
sudo examples/ecu_sim/run_local_netns.sh clean
```

常用显示过滤器：

```text
someip || someipsd
udp.port == 30490 || udp.port == 30509 || udp.port == 40000
tcp.port == 30510 || tcp.port == 41000
```

关键 ID 和端口：

```text
Service ID:       0x1234
Instance ID:      0x5678
Method ID:        0x0421
Eventgroup ID:    0x4465
SD multicast:     224.244.224.245:30490/udp
Service UDP port: 30509
Service TCP port: 30510
Client UDP port:  40000-40002
Client TCP port:  41000-41002
```

事件说明：

```text
0x8778  应用线程按 EVENT_CYCLE_MS 周期调用 notify()
0x8781  JSON cycle=500ms
0x8782  JSON cycle=1000ms
0x8783  JSON cycle=2500ms
```

## 真实 P301 ECU

P301 使用真实物理网卡、VLAN 3 和 namespace 内 ipvlan。详细步骤见：

```text
examples/ecu_sim/P301_REAL_ECU.md
```

最常用命令：

```bash
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh setup
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh ping
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh start
```

P301 脚本默认创建或复用宿主机 VLAN 子接口 `faw_eno1.3`，不会给它配置业务 IP；业务 IP `172.20.3.36/24` 配在 namespace 内的 `p301vlan3` 上。
脚本还会把 `faw_eno1.3` 的 MAC 设置为真实抓包里的上位机 MAC `aa:bb:cc:dd:ee:23`，因为当前 ECU 会把 `172.20.3.36` 的回包发给这个 MAC。
P301 服务版本需要按真实报文使用 `77fb.0001:1.0`，否则 ECU 会对 `0x7001` 订阅回 `SubscribeNack`，Wireshark 里会反复出现 `StopSubscribe`。
如果要保留当前 VLAN 子接口 MAC，运行时加 `HOST_VLAN_MAC=keep`。

环境管理命令：

```bash
# 创建或复用 faw_eno1.3 + p301_upper/p301vlan3
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh setup-env

# 安全清理 namespace 和本脚本创建的 faw_eno1.3
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh clean-env

# 明确删除物理网卡上的 VLAN 3 子接口，例如 eno1.3
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh delete-vlan

# 删除本机所有 VLAN ID 为 3 的子接口
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh delete-vlan-all

# 删除旧 VLAN 3 并重建默认环境
sudo env PHY_IF=enx00e04c0a2188 examples/ecu_sim/run_p301_real_netns.sh reset-env
```
